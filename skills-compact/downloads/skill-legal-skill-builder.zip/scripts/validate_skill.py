#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_skill.py - השער המכני של בונה הסקילים: האם הסקיל שנבנה ייטען.

זוהי **שכבה 1** של השער התלת-שכבתי שבראש references/quality-checklist.md.
כרטיס זיהוי שבור אינו מייצר הודעת שגיאה - הסקיל פשוט אינו מופיע - ולכן
הבדיקה היא השוואת מחרוזות מכנית ולא שיקול דעת של המודל.

שימוש:
    python validate_skill.py <נתיב>

<נתיב> יכול להיות אחד משלושה:
    * תיקיית סקיל (למשל ~/.claude/skills/demand-letter-builder)
    * קובץ SKILL.md בתוך תיקיית סקיל
    * ארכיון .zip של סקיל בודד למסירה ידנית

מה נבדק, וכל בדיקה היא כשל חוסם:
    1. פרונטמטר תקין - השורה הראשונה `---` בדיוק, וסוגר `---`.
    2. פרסור מחמיר של הפרונטמטר בספרייה התקנית: כל שורה בצורה `מפתח: ערך`,
       בלי טאב בהזחה, בלי שבירת שורה בתוך ערך, בלי נקודתיים-ורווח בערך
       לא-מצוטט, ובמרכאות מאוזנות. `name` ו-`description` חובה; מפתחות
       נוספים (למשל argument-hint) מותרים ונרשמים כהערה.
    3. `name` - kebab-case באנגלית קטנה, עד 64 תווים.
    4. **זהות שם המכולה לשדה name, תו בתו** - שם התיקייה, או שם תיקיית
       השורש בארכיון. זו נקודת הכשל שאין עליה הודעת שגיאה בשום מקום אחר.
    5. `description` - שורה אחת, עד 1024 תווים (תקרת מפרט Agent Skills).
       מעל 200 תווים נרשם כהערה בלבד: זו תקרת ההעלאה הידנית ל-claude.ai,
       ואינה חלה על פלאגין או על ספריית סקילים. **אין לאחד את המספרים.**
    6. תווים אסורים - מקף שאינו U+002D בכל קובץ md של הסקיל (מדיניות המקף
       הקצר), וסימני כיווניות בתוך הפרונטמטר.
    7. קיום כל קובץ שמופנים אליו בקישור Markdown מתוך קובצי הסקיל.
    8. מבנה ארכיון (בקלט .zip בלבד): תיקייה אחת בשם הסקיל בשורש הארכיון,
       ו-SKILL.md בתוכה. קבצים בשורש הארכיון הם מבנה שגוי.
    9. סקריפט שמתקין חבילה בזמן ריצה - איסור מוחלט בחבילה (ספרייה תקנית
       בלבד). שורה שמנסחת את האיסור עצמו פטורה, כמו בלינט המקף.

נרשם כהערה שאינה מכשילה (`מידע:`): היעדר שורת גרסה, היעדר אחד מסעיפי
החובה, ידע מתיישן שאין לצידו טבלת אימות, שם מוצר בגוף הסקיל שעלול לשמש
תנאי הסתעפות, היעדר שלושת מצבי הדיווח של שורת "מה ירד", היעדר
`references/spec.md`, ו-SKILL.md שחרג בהרבה מתקרת ה-~200 שורות. אלה בדיקות
טקסטואליות שיש להן חיוביים כוזבים, ולכן אינן מפילות את השער - אבל הן
נאמרות ואינן נבלעות.

**שלושת מצבי הדיווח של השער - ואין רביעי:** `הורץ מכנית` (הסקריפט רץ) ·
`נבדק לפי המפרט` (אין שפת הרצה, והמפרט שבצ'קליסט בוצע בשפה הזמינה) ·
`לא נבדק מכנית` (בוצעה דגימה ידנית בלבד, או שלא בוצע דבר). המצב השלישי הוא
חולשה מדווחת - **אין לדווח עליו כ"עבר"**, ובמסירה הוא נרשם `בוצע ולא נבדק`.

קוד יציאה: 0 - תקין; 1 - נמצאו כשלים; 2 - שגיאת שימוש, קריאה או קידוד.
Python 3 סטנדרטי בלבד - ללא תלויות חיצוניות.
"""

import os
import re
import sys
import zipfile

MAX_NAME = 64
MAX_DESC = 1024
MANUAL_UPLOAD_DESC = 200

NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
FIELD_RE = re.compile(r"^([A-Za-z0-9_-]+):[ \t]*(.*)$")
LINK_RE = re.compile(r"\[[^\]\n]*\]\(([^)\s]+)\)")
FILE_SUFFIXES = (".md", ".txt", ".py", ".js", ".json", ".yaml", ".yml",
                 ".csv", ".docx", ".xlsx", ".pdf", ".zip", ".html")
VERSION_RE = re.compile("גרסה\\s+\\d+(?:\\.\\d+)+\\s*-")

# מקפים שאינם U+002D - אסורים לפי מדיניות המקף הקצר. כתובים כ-escapes כדי
# שקובץ המקור עצמו יישאר נקי מהם.
BAD_DASHES = (
    "\u2010\u2011\u2012\u2013\u2014\u2015\u2043\u2212"
    "\u05be\ufe58\ufe63\uff0d")
# \u05e9\u05d5\u05e8\u05ea \u05ea\u05d9\u05e2\u05d5\u05d3 \u05e9\u05de\u05d6\u05db\u05d9\u05e8\u05d4 \u05ea\u05d5 \u05d0\u05e1\u05d5\u05e8 \u05d1\u05e9\u05de\u05d5 (\u05d8\u05d1\u05dc\u05ea \u05d8\u05d9\u05e4\u05d5\u05d2\u05e8\u05e4\u05d9\u05d4, \u05e0\u05d9\u05e1\u05d5\u05d7 \u05d4\u05d0\u05d9\u05e1\u05d5\u05e8 \u05e2\u05e6\u05de\u05d5) \u05e4\u05d8\u05d5\u05e8\u05d4
# \u05de\u05d4\u05dc\u05d9\u05e0\u05d8 - \u05d0\u05d7\u05e8\u05ea \u05db\u05dc \u05e1\u05e7\u05d9\u05dc \u05e9\u05de\u05ea\u05e2\u05d3 \u05d0\u05ea \u05de\u05d3\u05d9\u05e0\u05d9\u05d5\u05ea \u05d4\u05de\u05e7\u05e3 \u05e0\u05db\u05e9\u05dc \u05e2\u05dc \u05d4\u05db\u05dc\u05dc \u05e9\u05d4\u05d5\u05d0 \u05e2\u05e6\u05de\u05d5 \u05d0\u05d5\u05db\u05e3.
# \u05d4\u05e8\u05e9\u05d9\u05de\u05d4 \u05d6\u05d4\u05d4 \u05dc-DOC_EXEMPT_TOKENS \u05d1-release_core.py; \u05e9\u05d9\u05e0\u05d5\u05d9 \u05db\u05d0\u05df \u05e0\u05e2\u05e9\u05d4 \u05d1\u05e9\u05e0\u05d9\u05d4\u05dd.
DOC_EXEMPT_TOKENS = ("en-dash", "em-dash", "U+2013", "U+2014", "U+05BE",
                     "\u05de\u05e7\u05e3 \u05e2\u05d1\u05e8\u05d9", "\u05e7\u05d5 \u05de\u05e4\u05e8\u05d9\u05d3", "endash", "emdash")
BIDI_RE = re.compile(
    "[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]")

# ידע מתיישן - כל דפוס כזה בגוף הסקיל אמור לשאת לצידו הוראת אימות.
STALE_PATTERNS = [
    ("סכום בשקלים", re.compile("₪\\s*[\\d,]+|[\\d,]+\\s*ש\"ח")),
    ("שיעור באחוזים", re.compile(r"\d+(?:\.\d+)?%")),
    ("מניין ימים", re.compile("\\b\\d{1,4}\\s+ימים")),
    ("הפניה לסעיף בחוק", re.compile("סעיף\\s+\\d+[א-ת]?\\s+ל")),
]
STALE_TABLE_RE = re.compile("ידע מתיישן|הוראת האימות")

# סקריפטים בחבילה - ספרייה תקנית בלבד, בלי התקנת חבילות בזמן ריצה (בלוק 3).
# הדפוס תופס גם קריאה מפורקת לרשימת ארגומנטים של מנהל החבילות, ולא רק פקודה
# רצופה בשורה אחת.
SCRIPT_SUFFIXES = (".py", ".js", ".mjs", ".cjs", ".sh", ".ps1")
# הפועל עצמו מורכב ואינו כתוב ליטרלית, כדי ששורת ההגדרה לא תתפוס את עצמה -
# אותו טיפול שקיבלו המקפים האסורים ב-BAD_DASHES.
_INST = "insta" + "ll"
INSTALL_RE = re.compile(
    r"\bpip3?['\"\s,\]\[]{0,6}%s\b|\bnpm\s+(?:%s|i)\b|"
    r"\byarn\s+add\b|\bpnpm\s+add\b|\bapt-get\s+%s\b|"
    r"\beasy_%s\b|\bpoetry\s+add\b" % (_INST, _INST, _INST, _INST))
# שורה שמנסחת את האיסור עצמו אינה הפרתו - אותו היגיון כמו בלינט המקף.
INSTALL_EXEMPT_TOKENS = ("אינו מתקין", "אין להתקין", "אל תתקין", "לא מתקין",
                         "בלי התקנ", "ללא התקנ", "no install")
# **שורת הערה אינה קוד שרץ.** סקריפט שמסביר בהערה היכן תלות מותקנת ("docx may
# be installed globally (npm install -g docx)") אינו מתקין דבר, וכשל עליו חוסם
# מסירה של סקיל תקין. הבדיקה חלה על הקוד המורץ בלבד; הערה נספרת ונאמרת, כמו כל
# פטור אחר בקובץ הזה. הערה חוסמת רק כשהקוד שלצדה באותה שורה מפר בעצמו.
COMMENT_PREFIXES = {
    ".py": ("#",), ".sh": ("#",), ".ps1": ("#",),
    ".js": ("//",), ".mjs": ("//",), ".cjs": ("//",),
}


def _code_part(line, suffix):
    """מחזיר את חלק השורה שאינו הערה. שורת הערה מלאה מחזירה מחרוזת ריקה."""
    out = line
    for pref in COMMENT_PREFIXES.get(suffix, ()):
        idx = out.find(pref)
        if idx >= 0:
            out = out[:idx]
    return out

# שם מוצר כתנאי הסתעפות (בלוק 1) - נבדק בגוף SKILL.md בלבד, כהערה.
PRODUCT_NAME_RE = re.compile(
    "Claude Code|claude\\.ai|Cowork|קלוד קוד|בטרמינל|בצ'אט|בצ׳אט|"
    "בדפדפן|בשורת הפקודה")
BRANCH_EXEMPT_TOKENS = ("כתנאי הסתעפות", "אל תכתוב", "אין לכתוב",
                        "לא לפי שם מוצר", "לפי יכולת", "שמות מוצרים")

# שלושת מצבי הדיווח של שורת "מה ירד" (בלוק 2) - שניים מהם אינם מספיקים.
REPORT_MODES = ("בוצע ונבדק", "בוצע ולא נבדק", "לא בוצע")
SPEC_FILE = "references/spec.md"
# תקרת ה-~200 שורות היא המלצה שיש לה חריגים לגיטימיים (סקיל-על); מעל הסף
# הזה כבר אין ויכוח שהכבד לא הועבר ל-references/.
MAX_SKILL_LINES = 300

REQUIRED_SECTIONS = [
    ("קווים אדומים", re.compile("קווים אדומים")),
    ("מתי עוצרים ושואלים", re.compile("עוצר|עצירה|עוצרים")),
    ("מה קורה אחרי העצירה", re.compile("אחרי העצירה|תמשיך בכל זאת|בזמן ההמתנה")),
    ("שורת אחריות מקצועית", re.compile("אינו תחליף לשיקול דעת|טיוטה לבדיקת")),
]


class Target(object):
    """מקור אחיד לבדיקה - תיקייה או ארכיון."""

    def __init__(self, kind, container, files):
        self.kind = kind            # "dir" או "zip"
        self.container = container  # שם התיקייה, או תיקיית השורש בארכיון
        self.files = files          # {נתיב יחסי בקו נטוי: טקסט או None}

    def text(self, rel):
        return self.files.get(rel)

    def exists(self, rel):
        return rel in self.files

    def md_files(self):
        return sorted(k for k in self.files if k.lower().endswith(".md"))

    def script_files(self):
        return sorted(k for k in self.files
                      if k.lower().endswith(SCRIPT_SUFFIXES))


def _decode(raw, label, problems):
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        problems.append("%s אינו UTF-8 תקין - הקובץ לא ייקרא." % label)
        return None


def _load_dir(path, problems):
    files = {}
    for root, dirs, names in os.walk(path):
        dirs[:] = [d for d in dirs if d not in (".git", "__pycache__")]
        for nm in names:
            full = os.path.join(root, nm)
            rel = os.path.relpath(full, path).replace(os.sep, "/")
            if nm.lower().endswith((".md", ".txt") + SCRIPT_SUFFIXES):
                with open(full, "rb") as fh:
                    files[rel] = _decode(fh.read(), rel, problems)
            else:
                files[rel] = None
    return Target("dir", os.path.basename(os.path.abspath(path)), files)


def _load_zip(path, problems):
    with zipfile.ZipFile(path) as zf:
        names = [n for n in zf.namelist() if not n.endswith("/")]
        if not names:
            problems.append("הארכיון ריק.")
            return None
        roots = set(n.split("/")[0] for n in names if "/" in n)
        loose = [n for n in names if "/" not in n]
        if loose:
            problems.append(
                "מבנה ארכיון שגוי - קבצים יושבים בשורש הארכיון (%s). ארכיון "
                "של סקיל בודד חייב להכיל תיקייה אחת בשם הסקיל, ובתוכה SKILL.md."
                % ", ".join(sorted(loose)[:3]))
            return None
        if len(roots) != 1:
            problems.append(
                "מבנה ארכיון שגוי - נמצאו %d תיקיות שורש (%s); נדרשת אחת בלבד, "
                "בשם הסקיל." % (len(roots), ", ".join(sorted(roots))))
            return None
        root = roots.pop()
        files = {}
        for n in names:
            rel = n.split("/", 1)[1]
            if rel.lower().endswith((".md", ".txt") + SCRIPT_SUFFIXES):
                files[rel] = _decode(zf.read(n), rel, problems)
            else:
                files[rel] = None
        return Target("zip", root, files)


def _split_frontmatter(text, problems):
    """מחזיר את שורות הפרונטמטר, או None אם אין פרונטמטר תקין."""
    lines = text.split("\n")
    if not lines or lines[0].rstrip("\r") != "---":
        problems.append(
            "השורה הראשונה ב-SKILL.md אינה `---` בדיוק - אין כרטיס זיהוי, "
            "והסקיל לא ייטען.")
        return None
    for i in range(1, len(lines)):
        if lines[i].rstrip("\r") == "---":
            return [ln.rstrip("\r") for ln in lines[1:i]]
    problems.append("כרטיס הזיהוי נפתח ב-`---` ולא נסגר ב-`---` נוספת.")
    return None


def _unquote(value, key, problems):
    """בודק את ציטוט הערך ומחזיר את הערך עצמו, או None בכשל."""
    if not value:
        problems.append("השדה `%s` בכרטיס הזיהוי ריק." % key)
        return None
    if value[0] in "'\"":
        q = value[0]
        if len(value) < 2 or value[-1] != q:
            problems.append(
                "השדה `%s` נפתח במרכאה %s ואינו נסגר בה - הפרסור ייכשל."
                % (key, q))
            return None
        inner = value[1:-1]
        if inner.replace(q * 2, "").count(q):
            problems.append(
                "השדה `%s` מכיל מרכאה %s בודדת שאינה מוכפלת בתוך ערך עטוף "
                "באותה מרכאה - הפרסור ייכשל." % (key, q))
            return None
        return inner.replace(q * 2, q)
    if ": " in value or value.endswith(":"):
        problems.append(
            "השדה `%s` אינו מצוטט ומכיל נקודתיים-ורווח - זו שגיאת הפרסור "
            "השכיחה ביותר. הפרד במקף, או עטוף את כל הערך במרכאות בודדות."
            % key)
        return None
    if value[0] in "[{&*!|>%@`":
        problems.append(
            "השדה `%s` נפתח בתו `%s`, שיש לו משמעות מיוחדת בפרונטמטר - "
            "עטוף את הערך במרכאות בודדות." % (key, value[0]))
        return None
    return value


def _parse_frontmatter(fm_lines, problems, notes):
    fields = {}
    for n, raw in enumerate(fm_lines, start=2):
        if not raw.strip():
            continue
        if raw[0] in " \t":
            problems.append(
                "שורה %d בכרטיס הזיהוי פותחת בהזחה - ערך שנשבר לשורה שנייה "
                "או הזחה בטאב שוברים את הפרסור. כל שדה בשורה אחת." % n)
            continue
        if "\t" in raw:
            problems.append("שורה %d בכרטיס הזיהוי מכילה טאב." % n)
            continue
        m = FIELD_RE.match(raw)
        if not m:
            problems.append(
                "שורה %d בכרטיס הזיהוי אינה בצורה `מפתח: ערך`." % n)
            continue
        key, value = m.group(1), m.group(2).strip()
        if key in fields:
            problems.append("השדה `%s` מופיע פעמיים בכרטיס הזיהוי." % key)
            continue
        fields[key] = _unquote(value, key, problems)
    extra = [k for k in fields if k not in ("name", "description")]
    if extra:
        notes.append(
            "מפתחות נוספים בכרטיס הזיהוי מעבר ל-name ול-description: %s. "
            "מותר, ונרשם כדי שלא יעבור בלי שיראו אותו." % ", ".join(sorted(extra)))
    return fields


def _check_yaml_second_opinion(fm_text, problems, notes):
    """דעה שנייה בעזרת PyYAML, אם הוא מותקן. אינו תלות."""
    try:
        import yaml  # noqa
    except ImportError:
        notes.append(
            "PyYAML אינו מותקן - הפרסור בוצע בספרייה התקנית בלבד, לפי המפרט "
            "שבצ'קליסט. אין להתקין חבילות לצורך הבדיקה.")
        return
    try:
        data = yaml.safe_load(fm_text)
    except Exception as exc:
        problems.append("פרסור YAML של כרטיס הזיהוי נכשל: %s" % exc)
        return
    if not isinstance(data, dict):
        problems.append("כרטיס הזיהוי אינו נפרס למיפוי מפתח-ערך.")


def _check_frontmatter(target, skill_md, problems, notes):
    fm_lines = _split_frontmatter(skill_md, problems)
    if fm_lines is None:
        return
    fm_text = "\n".join(fm_lines)
    if BIDI_RE.search(fm_text):
        problems.append(
            "כרטיס הזיהוי מכיל סימן כיווניות בלתי נראה - הסר אותו; מקומו "
            "בגוף הסקיל, לא בכרטיס.")
    _check_yaml_second_opinion(fm_text, problems, notes)
    fields = _parse_frontmatter(fm_lines, problems, notes)

    name = fields.get("name")
    if name is None:
        if "name" not in fields:
            problems.append("אין שדה `name` בכרטיס הזיהוי.")
    else:
        if len(name) > MAX_NAME:
            problems.append(
                "`name` באורך %d תווים - התקרה היא %d."
                % (len(name), MAX_NAME))
        if not NAME_RE.match(name):
            problems.append(
                "`name` = %s אינו kebab-case תקין (אנגלית קטנה, ספרות ומקף "
                "יחיד U+002D בין מילים)." % name)
        if name != target.container:
            problems.append(
                "שם ה%s הוא %s ושדה `name` הוא %s - הם חייבים להיות זהים תו "
                "בתו. אי-התאמה כאן מייצרת סקיל שאינו מופיע, בלי שום הודעת "
                "שגיאה."
                % ("תיקייה" if target.kind == "dir" else "תיקייה בארכיון",
                   target.container, name))

    desc = fields.get("description")
    if desc is None:
        if "description" not in fields:
            problems.append(
                "אין שדה `description` בכרטיס הזיהוי - בלעדיו הסקיל לא יזוהה.")
    else:
        n = len(desc)
        if n > MAX_DESC:
            problems.append(
                "`description` באורך %d תווים - התקרה במפרט Agent Skills היא "
                "%d. הסר טריגרים כפולים, לא את סעיף \"מתי לא\"; מה שנחתך עובר "
                "לפסקה הראשונה של גוף הסקיל." % (n, MAX_DESC))
        elif n > MANUAL_UPLOAD_DESC:
            notes.append(
                "`description` באורך %d תווים - תקין לפלאגין ולספריית סקילים "
                "(תקרה %d). ליעד של העלאה ידנית ל-claude.ai בלבד התקרה היא %d, "
                "והמספרים אינם מאוחדים." % (n, MAX_DESC, MANUAL_UPLOAD_DESC))
        if "\n" in desc:
            problems.append("`description` נשבר לשורה שנייה - חייב שורה אחת.")


def _check_dashes(target, problems, notes=None):
    exempted = 0
    for rel in target.md_files():
        text = target.text(rel)
        if not text:
            continue
        hits = []
        for i, line in enumerate(text.split("\n"), start=1):
            for ch in line:
                if ch in BAD_DASHES:
                    # שורה שמזכירה את התו האסור בשמו היא ניסוח האיסור, לא הפרתו.
                    if any(tok in line for tok in DOC_EXEMPT_TOKENS):
                        exempted += 1
                    else:
                        hits.append((i, "U+%04X" % ord(ch)))
                    break
        if hits:
            where = ", ".join("שורה %d (%s)" % h for h in hits[:5])
            problems.append(
                "%s מכיל מקף שאינו U+002D ב-%d שורות: %s%s. מדיניות הבית - "
                "מקף קצר בלבד."
                % (rel, len(hits), where, " ..." if len(hits) > 5 else ""))
    # הפטור נאמר ואינו נבלע: שורה פטורה אינה שורה שנבדקה ועברה.
    if exempted and notes is not None:
        notes.append(
            "%d שורות תיעוד פטורות מלינט המקף (מזכירות את התו האסור בשמו)."
            % exempted)


def _check_links(target, problems):
    missing = []
    for rel in target.md_files():
        text = target.text(rel)
        if not text:
            continue
        base = os.path.dirname(rel)
        for raw in LINK_RE.findall(text):
            link = raw.split("#")[0].strip()
            if not link or "://" in link or link.startswith(("mailto:", "<")):
                continue
            if link.startswith(("~", "/")) or re.match(r"^[A-Za-z]:", link):
                continue
            # מסננים מציין-מקום בתבנית ("[טקסט](url)") - נבדק רק מה שנראה
            # כנתיב קובץ: יש בו קו נטוי, או סיומת מוכרת.
            if "/" not in link and not link.lower().endswith(FILE_SUFFIXES):
                continue
            tgt = os.path.normpath(os.path.join(base, link)).replace(os.sep, "/")
            if not target.exists(tgt):
                missing.append("%s -> %s" % (rel, link))
    for m in sorted(set(missing)):
        problems.append(
            "הפניה לקובץ שאינו קיים: %s. הפניה מתה בסקיל היא הוראה שלא תבוצע."
            % m)


def _check_scripts(target, problems, notes):
    """סקריפט בחבילה משתמש בספרייה התקנית ואינו מתקין דבר (בלוק 3)."""
    exempted = 0
    commented = 0
    for rel in target.script_files():
        text = target.text(rel)
        if not text:
            continue
        suffix = "." + rel.rsplit(".", 1)[-1] if "." in rel else ""
        hits = []
        for i, line in enumerate(text.split("\n"), start=1):
            if not INSTALL_RE.search(line):
                continue
            if any(tok in line for tok in INSTALL_EXEMPT_TOKENS):
                exempted += 1
            elif not INSTALL_RE.search(_code_part(line, suffix)):
                commented += 1          # ההתקנה יושבת בהערה, לא בקוד שרץ
            else:
                hits.append(i)
        if hits:
            problems.append(
                "%s מתקין חבילה בזמן ריצה (שורות %s). יציאת הרשת אינה זהה בין "
                "סביבות, וסקריפט שנכשל בהתקנה מפיל את הסקיל אצל עוה\"ד - "
                "ספרייה תקנית בלבד."
                % (rel, ", ".join(str(h) for h in hits[:5])))
    if exempted:
        notes.append(
            "%d שורות בסקריפטים פטורות מבדיקת ההתקנה (מנסחות את האיסור עצמו)."
            % exempted)
    if commented:
        notes.append(
            "%d שורות בסקריפטים נושאות פקודת התקנה בתוך הערה ולא בקוד שרץ - "
            "אינן כשל, ונרשמות כדי שלא יעברו בלי שיראו אותן." % commented)


def _check_inheritance(target, skill_md, notes):
    """ירושת החבילה בסקיל הנבנה - בדיקות טקסטואליות, ולכן הערות בלבד."""
    hits = []
    for i, line in enumerate(skill_md.split("\n"), start=1):
        if not PRODUCT_NAME_RE.search(line):
            continue
        if any(tok in line for tok in BRANCH_EXEMPT_TOKENS):
            continue
        hits.append(i)
    if hits:
        notes.append(
            "שם מוצר בגוף SKILL.md (שורות %s) - ודא שאינו תנאי הסתעפות. "
            "הסתעפות לפי שם מוצר מתיישנת, וסביבה חדשה אינה נופלת לאף ענף; "
            "הנוסח הנכון הוא בדיקת יכולת."
            % ", ".join(str(h) for h in hits[:5]))

    missing = [m for m in REPORT_MODES if m not in skill_md]
    if len(missing) == len(REPORT_MODES):
        notes.append(
            "אין ב-SKILL.md שורת \"מה ירד\" עם שלושת מצבי הדיווח (%s) - שכבה "
            "שלא רצה תיבלע במסירה." % " / ".join(REPORT_MODES))
    elif missing:
        notes.append(
            "שורת \"מה ירד\" חלקית - חסרים המצבים %s. שניים אינם מספיקים; "
            "האמצעי (`בוצע ולא נבדק`) הוא בדיוק זה שנוטים להשמיט."
            % " / ".join(missing))

    if not target.exists(SPEC_FILE):
        notes.append(
            "אין %s - אם זהו סקיל שנבנה בתהליך הזה, האפיון המאושר לא נשמר, "
            "ובעדכון הבא לא יהיה מקור מחייב לשאלה מה הכתיב עוה\"ד." % SPEC_FILE)

    n_lines = len(skill_md.strip().split("\n"))
    if n_lines > MAX_SKILL_LINES:
        notes.append(
            "SKILL.md בן %d שורות - ההמלצה היא ~200, והכבד (תבניות, רשימות, "
            "דוגמאות) שייך ל-references/. מעל %d כבר אין חשיפה הדרגתית."
            % (n_lines, MAX_SKILL_LINES))


def _check_soft(skill_md, notes):
    tail = "\n".join(skill_md.strip().split("\n")[-8:])
    if not VERSION_RE.search(tail):
        notes.append(
            "אין שורת גרסה בתחתית SKILL.md (\"גרסה 1.0 - <תאריך>\").")
    for label, rx in REQUIRED_SECTIONS:
        if not rx.search(skill_md):
            notes.append("לא נמצא סעיף חובה: %s." % label)
    found = [label for label, rx in STALE_PATTERNS if rx.search(skill_md)]
    if found and not STALE_TABLE_RE.search(skill_md):
        notes.append(
            "נמצא ידע מתיישן (%s) ואין בסקיל טבלת \"פריט ידע מתיישן | הוראת "
            "האימות בזמן ריצה\" - כל פריט כזה חייב שורה בטבלה."
            % ", ".join(found))


def _validate(target, problems, notes):
    skill_md = target.text("SKILL.md")
    if skill_md is None:
        problems.append(
            "אין SKILL.md ב%s - זהו הקובץ היחיד שחייב להיות."
            % ("תיקיית הסקיל" if target.kind == "dir" else "תיקיית הארכיון"))
        return
    _check_frontmatter(target, skill_md, problems, notes)
    _check_dashes(target, problems, notes)
    _check_links(target, problems)
    _check_scripts(target, problems, notes)
    _check_inheritance(target, skill_md, notes)
    _check_soft(skill_md, notes)


def main(argv):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    usage = "שימוש: python validate_skill.py <תיקיית סקיל | SKILL.md | סקיל.zip>"
    args = list(argv[1:])
    if len(args) != 1:
        print(usage)
        return 2
    path = args[0]
    problems = []
    notes = []
    try:
        if os.path.isdir(path):
            target = _load_dir(path, problems)
        elif os.path.isfile(path) and path.lower().endswith(".zip"):
            target = _load_zip(path, problems)
        elif os.path.isfile(path) and os.path.basename(path).lower() == "skill.md":
            target = _load_dir(os.path.dirname(os.path.abspath(path)), problems)
        else:
            print("נתיב לא נתמך: %s" % path)
            print(usage)
            return 2
    except (OSError, zipfile.BadZipFile) as exc:
        print("שגיאת קריאה: %s" % exc)
        return 2

    if target is not None:
        _validate(target, problems, notes)

    for p in problems:
        print("- " + p)
    for n in notes:
        print("מידע: " + n)
    if problems:
        print("נכשל: %d כשלים." % len(problems))
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
