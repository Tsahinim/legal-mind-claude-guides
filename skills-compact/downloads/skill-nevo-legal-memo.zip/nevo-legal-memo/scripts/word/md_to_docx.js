// md_to_docx.js - Markdown -> Hebrew RTL .docx (docx-js).
//
// Usage: node md_to_docx.js input.md output.docx
//
// Text normalization applied to every text path (paragraphs, list items,
// headings, block quotes, table cells, link TEXT) - never to link targets,
// bare URLs or `code` spans:
//   - quotation marks: Hebrew gershayim U+05F4 is kept/produced ONLY inside an
//     abbreviation - between two Hebrew letters (עו״ד, בע״מ, תשנ״ט, מנכ״לים).
//     A straight " in that position becomes gershayim; a gershayim anywhere
//     else (a quotation mark typed as ״) becomes the straight ASCII ". An
//     opening quote after a one-letter prefix (ו"ביטוי, כ"מעין) stays a quote.
//     Geresh ׳ is never touched.
//   - spacing: whitespace before , . ; : ? ! ) is removed ("..." ellipsis
//     keeps its space), whitespace after ( is removed, runs of 2+ spaces
//     collapse to one, leading/trailing whitespace is trimmed.
//   - digit-hyphen-digit (29-35, 61475-07-14): the hyphen is emitted as Word's
//     non-breaking hyphen element <w:noBreakHyphen/> (shown as a plain hyphen,
//     no Unicode dash in the text), so a range or case number never wraps at
//     the hyphen. An LRM (U+200E) on each side keeps the digits in order -
//     without it LibreOffice reorders 29-35 to 35-29 inside RTL paragraphs.
const fs = require('fs');

// docx may be installed globally (npm install -g docx); node does not search the
// global root from this script's directory, so fall back to it explicitly.
function loadDocx() {
  try { return require('docx'); } catch (e) {
    const globalRoot = require('child_process').execSync('npm root -g').toString().trim();
    return require(require('path').join(globalRoot, 'docx'));
  }
}
const {
  Document, Packer, Paragraph, TextRun, ExternalHyperlink,
  AlignmentType, HeadingLevel, LevelFormat, BorderStyle,
  Table, TableRow, TableCell, WidthType, ShadingType,
  Footer, PageNumber, NoBreakHyphen
} = loadDocx();

const SRC = process.argv[2];
const OUT = process.argv[3];
const md = fs.readFileSync(SRC, 'utf8').replace(/\r\n/g, '\n');
const lines = md.split('\n');

const FONT = 'David';
const BODY = 22; // 11pt

// Any RTL-script codepoint (Hebrew, Arabic + presentation forms).
// MUST stay identical to RTL_CHARS in scripts/fix_rtl.py - a character this
// function misses lands in an LTR run carrying <w:rtl w:val="false"/>, and
// fix_rtl.py deliberately preserves that marker instead of repairing it.
const isRtlChar = c =>
  (c >= 0x0590 && c <= 0x08ff) ||
  (c >= 0xfb1d && c <= 0xfdff) ||
  (c >= 0xfe70 && c <= 0xfeff);

// Atomic patterns that must never be split across two runs.
// - clause citations 12(א) / 3(2): one run, kept in the RTL flow (see ATOMIC)
//   (mixed-direction rule: the clause number and its sub-clause letter stay together)
// - law-year citations התשכ"ט-1969: one RTL run, the year is NOT split off
//   (law-year rule: the Hebrew year and the civil year stay in one Hebrew run)
const ATOMIC = [
  // clause citations stay ONE run in the Hebrew (RTL) flow, exactly as Word lays them out when
  // a lawyer types them: "ס׳ 254(א)(3)" reads number-first next to ס׳. An LTR run reverses
  // the parts ("(3)(א)254") - the bug seen in the 21.10.2026 memo. Longest pattern first.
  { re: /\d+[א-ת]?(?:\((?:[א-ת]{1,2}|\d+)\))+(?:[-–]\((?:[א-ת]{1,2}|\d+)\))?/y, ltr: false },
  { re: /[א-ת]+[״׳"']?[א-ת]?-\d{4}/y, ltr: false },
];

// classify a plain (no markdown) string into RTL/LTR runs
function classifyRuns(str) {
  const runs = [];
  let cur = null;
  const push = (text, want) => {
    if (cur && cur.ltr === want) cur.text += text;
    else { if (cur) runs.push(cur); cur = { text, ltr: want }; }
  };
  const isLtr = c => (c >= 0x30 && c <= 0x39) || (c >= 0x41 && c <= 0x5A) || (c >= 0x61 && c <= 0x7A);
  const chars = Array.from(str);
  // index in code units, so the sticky regexes line up with the source string
  let i = 0;
  for (let k = 0; k < chars.length; ) {
    let matched = null;
    for (const a of ATOMIC) {
      a.re.lastIndex = i;
      const m = a.re.exec(str);
      if (m) { matched = { text: m[0], ltr: a.ltr }; break; }
    }
    if (matched) {
      push(matched.text, matched.ltr);
      i += matched.text.length;
      k += Array.from(matched.text).length;
      continue;
    }
    const ch = chars[k];
    const code = ch.codePointAt(0);
    let want = null;
    if (isRtlChar(code)) want = false;  // rtl
    else if (isLtr(code)) want = true;  // ltr
    if (want === null) { // neutral
      // A neutral run (space, comma, period, bracket...) after LTR text belongs to
      // the LTR run only if more LTR text follows it on the same side; otherwise
      // it is part of the Hebrew flow. Without this, "ביום 8.10.2026, לאחר" ends
      // with ", " inside the LTR run and Word renders "ביום ,8.10.2026לאחר".
      if (cur && cur.ltr) {
        let j = k + 1;
        while (j < chars.length) {
          const cj = chars[j].codePointAt(0);
          if (isRtlChar(cj)) { want = false; break; }
          // digits are weak: they keep the neutral LTR only as a separator inside one
          // number (12,000 / 1.10.2026 / 12-14); otherwise "Ltd (30% מהמניות)" would
          // pull "(30" into the English run
          const isDigit = cj >= 0x30 && cj <= 0x39;
          if (isLtr(cj) && (!isDigit || (j === k + 1 && /[0-9]/.test(chars[k - 1] || '')))) { want = true; break; }
          j += 1;
        }
        if (want === null) want = false; // end of paragraph: back to the base direction
        push(ch, want);
      } else if (cur) cur.text += ch;
      else cur = { text: ch, ltr: false };
    } else {
      push(ch, want);
    }
    i += ch.length;
    k += 1;
  }
  if (cur) runs.push(cur);
  return runs;
}

// --- Hebrew typography normalization (see the header comment) ---------------
const HEB_LETTER = /[א-ת]/;
const PREFIX_ONLY = /^[ובכלמשה]+$/; // one-letter prefixes: ו ה ש ב כ ל מ
function fixQuoteMarks(s) {
  let out = '';
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c !== '"' && c !== '״') { out += c; continue; }
    let abbr = false;
    if (i > 0 && HEB_LETTER.test(s[i - 1]) && i + 1 < s.length && HEB_LETTER.test(s[i + 1])) {
      let j = i + 1; while (j < s.length && HEB_LETTER.test(s[j])) j++;
      let k = i - 1; while (k >= 0 && HEB_LETTER.test(s[k])) k--;
      // abbreviation: one letter after the mark (עו״ד, בע״מ), or an inflected
      // abbreviation whose letters before the mark are not just a prefix
      // (מנכ״לים, דו״חות). A prefix + a whole word (ו"ביטוי) is an opening quote.
      abbr = (j - i - 1) === 1 || !PREFIX_ONLY.test(s.slice(k + 1, i));
    }
    out += abbr ? '״' : '"';
  }
  return out;
}
// link targets "](url)", `code` spans and bare URLs are never normalized
const PROTECTED = /\]\([^)]*\)|`[^`]*`|https?:\/\/[^\s<>\]]+/g;
function normalizeInline(line) {
  if (/[-]/.test(line)) return line; // private-use text: leave it as is
  const kept = [];
  let s = line.replace(PROTECTED, m => { kept.push(m); return String.fromCharCode(0xE000 + kept.length - 1); });
  s = fixQuoteMarks(s)
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/[ \t]+(?=[,;:?!)]|\.(?!\.))/g, '')
    .replace(/\([ \t]+/g, '(')
    .trim();
  return s.replace(/[-]/g, ch => kept[ch.charCodeAt(0) - 0xE000]);
}

// run content: a hyphen between two digits becomes <w:noBreakHyphen/>, with an
// LRM on each side so the number keeps its order in every renderer. A bare URL
// in the text keeps its plain hyphens (copy-paste must yield a working URL).
const DIGIT_HYPHEN = /(?<=\d)-(?=\d)/;
const BARE_URL = /https?:\/\/[^\s<>\]]+/;
const LRM = '‎';
function runContent(text) {
  const parts = text.split(DIGIT_HYPHEN);
  // rejoin the splits that fall inside a bare URL
  if (parts.length > 1 && BARE_URL.test(text)) {
    const urls = [];
    const re = new RegExp(BARE_URL.source, 'g');
    let u;
    while ((u = re.exec(text)) !== null) urls.push([u.index, u.index + u[0].length]);
    const merged = [parts[0]];
    let pos = parts[0].length;
    for (let i = 1; i < parts.length; i++) {
      if (urls.some(([a, b]) => pos >= a && pos < b)) merged[merged.length - 1] += '-' + parts[i];
      else merged.push(parts[i]);
      pos += 1 + parts[i].length;
    }
    parts.splice(0, parts.length, ...merged);
  }
  if (parts.length === 1) return { text };
  const kids = [];
  let buf = '';
  parts.forEach((p, i) => {
    if (i) { kids.push(buf + LRM); kids.push(new NoBreakHyphen()); buf = LRM; }
    buf += p;
  });
  kids.push(buf);
  return { children: kids };
}

// build TextRun[] for a plain segment with given styling
function makeRuns(text, { bold = false, link = false, size = BODY, color = null } = {}) {
  return classifyRuns(text).map(r => new TextRun({
    ...runContent(r.text),
    font: FONT,
    size,
    bold,
    ...(color ? { color } : {}),
    rightToLeft: !r.ltr,
    ...(link ? { style: 'Hyperlink' } : {})
  }));
}

// split a segment by **bold** and produce runs
function styleRuns(text, { link = false, size = BODY, bold: baseBold = false, color = null } = {}) {
  const parts = text.split(/\*\*/);
  let bold = baseBold;
  const out = [];
  for (const p of parts) {
    if (p) out.push(...makeRuns(p, { bold, link, size, color }));
    bold = !bold;
  }
  return out;
}

// parse a line's inline markdown (links + bold) into TextRun/ExternalHyperlink[]
function parseInline(line, opts = {}) {
  line = normalizeInline(line);
  const out = [];
  const re = /\[([^\]]+)\]\(([^)]+)\)/g;
  let last = 0, m;
  while ((m = re.exec(line)) !== null) {
    if (m.index > last) out.push(...styleRuns(line.slice(last, m.index), opts));
    out.push(new ExternalHyperlink({ link: m[2], children: styleRuns(m[1], { ...opts, link: true }) }));
    last = re.lastIndex;
  }
  if (last < line.length) out.push(...styleRuns(line.slice(last), opts));
  return out;
}

const children = [];
const P = (opts) => children.push(new Paragraph(opts));

// --- Markdown tables → real w:tbl with bidiVisual ---
const isTableLine = l => /^\s*\|.*\|\s*$/.test(l);
const isSepLine = l => /^\s*\|(\s*:?-+:?\s*\|)+\s*$/.test(l);

function parseTableRow(line) {
  let s = line.trim();
  if (s.startsWith('|')) s = s.slice(1);
  if (s.endsWith('|')) s = s.slice(0, -1);
  return s.split(/(?<!\\)\|/).map(c => c.trim().replace(/\\\|/g, '|'));
}

function buildTable(headerCells, bodyRows) {
  const TABLE_W = 9026; // A4 content width in twips (11906 page - 2 x 1440 margins)
  const cols = headerCells.length;
  const colW = Math.floor(TABLE_W / cols);
  const widths = Array(cols).fill(colW);
  widths[cols - 1] += TABLE_W - colW * cols; // sum of columnWidths must equal table width
  const border = { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' };
  const borders = { top: border, bottom: border, left: border, right: border };
  const cell = (text, i, header) => new TableCell({
    borders,
    width: { size: widths[i], type: WidthType.DXA }, // dual widths: cell AND columnWidths
    ...(header ? { shading: { fill: 'D5E8F0', type: ShadingType.CLEAR } } : {}),
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    children: [new Paragraph({
      bidirectional: true, spacing: { after: 0 },
      children: header ? makeRuns(normalizeInline(text).replace(/\*\*/g, ''), { bold: true }) : parseInline(text)
    })]
  });
  const row = (cells, header) => new TableRow({
    ...(header ? { tableHeader: true } : {}),
    children: headerCells.map((_, i) => cell(cells[i] || '', i, header))
  });
  return new Table({
    visuallyRightToLeft: true,
    width: { size: TABLE_W, type: WidthType.DXA },
    columnWidths: widths,
    rows: [row(headerCells, true), ...bodyRows.map(r => row(r, false))]
  });
}

// מספור אוטומטי אמיתי: reference נפרד לכל בלוק (מתאפס בכל כותרת)
let listRef = 0;

// --- Numbered headings: REAL Word outline numbering ---------------------------
// A ##/###/#### heading whose text opens with a numeric section prefix
// ("1. ", "4.1 ", "4.1.2 ") is emitted with <w:numPr> on the dedicated multilevel
// list "heading-outline" and the typed prefix is STRIPPED, so adding or removing
// a section renumbers automatically in Word. The numbering level is the DEPTH of
// the prefix (count of numeric components), not the markdown "#" count. One
// continuous instance for the whole document, so "4.1" follows "4." correctly.
// Headings without a prefix (and every "#" H1) stay unnumbered.
const HEADING_NUM_RE = /^\d{1,2}(\.\d{1,2}){0,3}\.?\s+/;
const HEADING_LOOK = {
  2: { heading: HeadingLevel.HEADING_2, size: 28, spacing: { before: 280, after: 140 },
       border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: '2E75B6', space: 2 } } },
  3: { heading: HeadingLevel.HEADING_3, size: 26, color: '1F4E79', spacing: { before: 180, after: 90 } },
  4: { heading: HeadingLevel.HEADING_4, size: 24, color: '2E75B6', spacing: { before: 140, after: 70 } },
};
const outlineCount = [0, 0, 0]; // what Word will display, per level
function headingOutline(text, srcLine) {
  // tolerate a bold wrapper around the prefix: "**1. title**"
  let lead = '';
  let body = text;
  if (body.startsWith('**') && HEADING_NUM_RE.test(body.slice(2))) { lead = '**'; body = body.slice(2); }
  const m = body.match(HEADING_NUM_RE);
  if (!m) return null;
  const parts = m[0].trim().replace(/\.$/, '').split('.').map(Number);
  if (parts.length > 3) {
    process.stderr.write('md_to_docx: warning - line ' + srcLine + ': heading prefix "' + m[0].trim() +
      '" is deeper than 3 levels; numbered at level 3\n');
  }
  const level = Math.min(2, parts.length - 1);
  outlineCount[level]++;
  for (let k = level + 1; k < outlineCount.length; k++) outlineCount[k] = 0;
  const expected = outlineCount.slice(0, level + 1);
  const typed = parts.slice(0, level + 1);
  if (typed.join('.') !== expected.join('.')) {
    process.stderr.write('md_to_docx: warning - line ' + srcLine + ': heading typed as "' +
      m[0].trim() + '" will be auto-numbered "' + expected.join('.') + (level === 0 ? '.' : '') +
      '" (skipped, duplicated or out-of-sequence number in the source)\n');
  }
  return { level, text: lead + body.slice(m[0].length) };
}

for (let i = 0; i < lines.length; i++) {
  const raw = lines[i];
  const line = raw.replace(/\s+$/,'');
  if (!line.trim()) { continue; }

  // MD table block: header row + |---| separator + body rows
  if (isTableLine(line) && i + 1 < lines.length && isSepLine(lines[i + 1])) {
    const header = parseTableRow(line);
    const body = [];
    let j = i + 2;
    while (j < lines.length && isTableLine(lines[j]) && !isSepLine(lines[j])) {
      body.push(parseTableRow(lines[j])); j++;
    }
    children.push(buildTable(header, body));
    P({ bidirectional: true, spacing: { after: 80 }, children: [] }); // gap so consecutive tables don't merge
    i = j - 1;
    continue;
  }

  let m;

  // Horizontal rule (---, ***, ___) - a real bottom border, NEVER literal text
  if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(line)) {
    P({ bidirectional: true, spacing: { before: 120, after: 120 },
        border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: 'BFBFBF', space: 1 } },
        children: [] });
    continue;
  }

  if ((m = line.match(/^#\s+(.*)/))) {
    listRef++;
    // H1 is the document title - never auto-numbered, even with a numeric prefix
    P({ heading: HeadingLevel.HEADING_1, bidirectional: true, spacing: { after: 200 },
        children: parseInline(m[1], { size: 34, bold: true }) });
    continue;
  }
  if ((m = line.match(/^(#{2,4})\s+(.*)/))) {
    listRef++;
    const hashes = m[1].length;
    const look = HEADING_LOOK[hashes];
    const num = headingOutline(m[2], i + 1);
    P({ heading: look.heading, bidirectional: true, spacing: look.spacing,
        ...(look.border ? { border: look.border } : {}),
        // real Word numbering (no typed digits) on the one continuous outline
        // instance; the paragraph-mark run gives the number glyph the heading look
        ...(num ? { numbering: { reference: 'heading-outline', level: num.level },
                    run: { bold: true, size: look.size, font: FONT, rightToLeft: true,
                           ...(look.color ? { color: look.color } : {}) } } : {}),
        children: parseInline(num ? num.text : m[2],
          { size: look.size, bold: true, ...(look.color ? { color: look.color } : {}) }) });
    continue;
  }

  // Blockquote - also an indented one ("   > ...") nested under a list item,
  // which is indented further instead of leaking a literal ">" into the text
  if ((m = line.match(/^(\s*)>\s?(.*)/))) {
    const nested = m[1].replace(/\t/g, '  ').length >= 2;
    m = [m[0], m[2]];
    P({ bidirectional: true, alignment: AlignmentType.JUSTIFIED, spacing: { before: 120, after: 120, line: 340, lineRule: 'auto' },
        indent: { left: nested ? 1080 : 360 },
        border: { left: { style: BorderStyle.SINGLE, size: 12, color: '999999', space: 8 } },
        children: parseInline(m[1]) });
    continue;
  }

  // Bullet source line - indentation of 2+ spaces = one nesting level down
  if ((m = line.match(/^(\s*)[-*]\s+(.*)/))) {
    const lvl = Math.min(1, Math.floor(m[1].replace(/\t/g, '  ').length / 2));
    P({ bidirectional: true, alignment: AlignmentType.JUSTIFIED, spacing: { after: 60, line: 320, lineRule: 'auto' },
        numbering: { reference: 'src', level: lvl },
        children: parseInline(m[2]) });
    continue;
  }

  // Numbered point - REAL Word automatic numbering, restarts each block (new listRef per heading).
  // Accepts 1. / 1) / 1.1 / 1.1.1 and indented items; decimal depth and indentation
  // both map onto numbering levels 0-2. A number is NEVER written as literal text.
  // A bare number followed by a space (a year, an amount) is NOT a list item: a
  // single-level number must carry its "." or ")" delimiter to qualify, and a
  // decimal number qualifies only in clause shape - up to 3 segments of 1-2
  // digits each, so a date at the start of a line (15.7.2026) stays a paragraph.
  if ((m = line.match(/^(\s*)(\d{1,2}(?:\.\d{1,2}){1,2})[.)]?\s+(.*)/)) ||
      (m = line.match(/^(\s*)(\d+)[.)]\s+(.*)/))) {
    const indent = m[1].replace(/\t/g, '  ').length;
    const dots = m[2].split('.').length - 1;
    const lvl = Math.min(2, dots || Math.floor(indent / 2));
    P({ bidirectional: true, alignment: AlignmentType.JUSTIFIED, spacing: { before: 100, after: 60, line: 340, lineRule: 'auto' },
        numbering: { reference: 'pts' + listRef, level: lvl }, children: parseInline(m[3]) });
    continue;
  }

  // Normal paragraph
  P({ bidirectional: true, alignment: AlignmentType.JUSTIFIED, spacing: { after: 80, line: 340, lineRule: 'auto' },
      children: parseInline(line) });
}

// תצורות מספור: תבליט למקורות (שתי רמות) + reference עשרוני רב-רמתי נפרד לכל בלוק (איפוס אמיתי).
// כלל קריטי: צד ההזחה הוא תמיד left - בפסקה דו-כיוונית left הוא ההתחלה הלוגית, כלומר ימין פיזי.
const bulletLevel = (level, text, left) => ({
  level, format: LevelFormat.BULLET, text, alignment: AlignmentType.LEFT,
  style: { paragraph: { indent: { left, hanging: 300 }, bidirectional: true }, run: { rightToLeft: true } },
});
const decimalLevel = (level, text, left) => ({
  level, format: LevelFormat.DECIMAL, text, alignment: AlignmentType.LEFT,
  style: { paragraph: { indent: { left, hanging: 360 }, bidirectional: true }, run: { rightToLeft: true } },
});
const numConfig = [
  { reference: 'src', levels: [bulletLevel(0, '•', 900), bulletLevel(1, 'o', 1260)] },
];
// Heading outline: one multilevel list, decimal, "%1." / "%1.%2" / "%1.%2.%3".
// Modest hanging indent (~0.6-0.9cm) on the logical start side (w:left = physical
// right in a bidi paragraph); lvlJc left = logical start. NEVER AlignmentType.RIGHT.
const outlineLevel = (level, text, hanging) => ({
  level, format: LevelFormat.DECIMAL, text, alignment: AlignmentType.LEFT,
  style: { paragraph: { indent: { left: hanging, hanging }, bidirectional: true }, run: { rightToLeft: true } },
});
numConfig.push({ reference: 'heading-outline', levels: [
  outlineLevel(0, '%1.', 340),
  outlineLevel(1, '%1.%2', 425),
  outlineLevel(2, '%1.%2.%3', 510),
] });
for (let i = 0; i <= listRef; i++) {
  numConfig.push({ reference: 'pts' + i, levels: [
    decimalLevel(0, '%1.', 720),
    decimalLevel(1, '%1.%2.', 1140),
    decimalLevel(2, '%1.%2.%3.', 1620),
  ] });
}

// Heading1-Heading4 are BUILT-IN docx-js styles: the library always emits them
// into styles.xml. Re-declaring the same ids under `paragraphStyles` does not
// replace them - it appends a SECOND <w:style w:styleId="Heading1"> to the same
// file, and which of the two Word honours is undefined. The visible casualty is
// w:outlineLvl (navigation pane + table of contents), because the stock style
// carries none. The supported way to restyle a built-in heading is the
// styles.default.headingN slot below; `paragraphStyles` stays reserved for ids
// the library does not already define.
const headingStyle = (size, before, after, outlineLevel) => ({
  run: { size, bold: true, font: FONT, rightToLeft: true },
  paragraph: { spacing: { before, after }, bidirectional: true, outlineLevel },
});

const doc = new Document({
  styles: {
    default: {
      document: { run: { font: FONT, size: BODY, rightToLeft: true }, paragraph: { bidirectional: true } },
      heading1: headingStyle(34, 240, 160, 0),
      heading2: headingStyle(28, 260, 130, 1),
      heading3: headingStyle(26, 180, 90, 2),
      heading4: headingStyle(24, 140, 70, 3),
    },
  },
  numbering: { config: numConfig },
  sections: [{
    properties: { bidi: true, page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
    // כותרת תחתונה "עמוד X מתוך Y" - שדות המספר הם ספרות ולכן rightToLeft: false
    // (Hebrew page furniture: centered page-number footer)
    footers: { default: new Footer({ children: [
      new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, children: [
        new TextRun({ text: 'עמוד ', font: FONT, size: 20, rightToLeft: true }),
        new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 20, rightToLeft: false }),
        new TextRun({ text: ' מתוך ', font: FONT, size: 20, rightToLeft: true }),
        new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FONT, size: 20, rightToLeft: false }),
      ]}),
    ]}) },
    children
  }]
});

Packer.toBuffer(doc).then(b => { fs.writeFileSync(OUT, b); console.log('written', OUT, b.length, 'bytes'); });
