#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_quotes.py - שער המחרוזת המכני לזהות ציטוטים ישירים.

מנוע עצמאי, שאינו יודע דבר על שלד התוצר של סקיל כלשהו: הוא קורא **קובץ
`quotes.json` בלבד** - שלישיות הציטוט שהזרימה כותבת בזמן שהיא מצטטת - ובודק
לכל ציטוט שלוש רגליים:

1. **זהות המחרוזת:** הציטוט קיים מילה במילה בתוך חלון ההקשר שנשמר מהטקסט
   שנשלף בפועל (ההשוואה מנרמלת ומשווה `context.includes(text)`).
2. **כבילת הציטוט למסמך:** האסמכתא שנכתבה לצד הציטוט מפנה לאותו
   `documentId` שממנו נשלף הטקסט - ציטוט אמיתי שהוצמד לאסמכתא של מסמך אחר
   הוא כשל. הכבילה נבדקת קודם כול מול פרמטר המזהה שב-url של האסמכתא
   (`verdictid` / `documentid` / `docid`); אסמכתא בלי url כלל, או url שאינו
   נושא פרמטר מזהה בעוד ה-`documentId` הוא מספר קצר, **אינה מאומתת** - וזו
   בעיה מכשילה ולא התאמה. התאמה טקסטואלית של המזהה בגוף האסמכתא מותרת רק
   כשהמזהה ארוך מספיק או שאינו מספר גרידא, שאם לא כן הוא מזדהה במקרה עם
   שנה, עמוד או מספר פסקה שבאסמכתא.
3. **ההפניה לעמוד או לפסקה** (רגל מיקום): מספר העמוד או הפסקה שבאסמכתא נבדק
   מול הסמנים שבחלון ההקשר, **בהפרדה בין עמוד לפסקה** - הפניה לעמוד מושווית
   רק לסמן עמוד והפניה לפסקה רק לסמן פסקה. אין בחלון סמן מתאים, או שהסמן
   אינו תואם - התוצאה היא **"ההפניה לא אומתה"** ולא "עבר". רגל זו מדווחת
   כ**אזהרה שאינה מכשילה**: חלון של כ-500 תווים אינו נושא בהכרח סמן,
   וכשל היה מייצר רעש שווא ושוחק את אמון השער.

**שלושת מצבי הדיווח של השער - ואין רביעי:** `הורץ מכנית` (הסקריפט רץ) ·
`נבדק ידנית תו-אחר-תו` (אין הרצת קוד בסביבה, וההשוואה בוצעה ידנית) ·
`לא נבדק מכנית` (לא רץ ולא נבדק ידנית). המצב השלישי הוא חולשה מדווחת -
**אין לדווח עליו כ"עבר"**. **פנקס ריק, או אובייקט JSON בלי המפתח `quotes`,
הם המצב השלישי** - הסקריפט מחזיר קוד יציאה 2, ואין לרשום עליו "עבר".

מבנה `quotes.json`: מערך רשומות `{text, documentId, citation, context}`, או
אובייקט עם המפתח `quotes` שערכו מערך כזה. `text` - גוף הציטוט בלי מרכאות
עוטפות; `context` - חלון ההקשר שנשמר מהטקסט שנשלף בפועל; `citation` -
**ציטוט ה-Markdown המלא כפי שנכתב בתוצר, כולל ה-url שהוחזר
מ-`get_document_link`** בצורת `[ציטוט מלא](url)`, ולא האסמכתא הנראית בלבד.

**מעמד הקובץ - גרסה עצמאית, לא עותק זהה.** קובץ זה התפצל מהעותק הקנוני של
משפחת נבו (`nevo-legal-suite/skills/nevo-legal-questions/scripts/check_quotes.py`)
בגל ב של סבב השדרוג, ואינו זהה לו. חמישה הבדלים פונקציונליים:

1. `citation` מקובע כציטוט ה-Markdown המלא כולל ה-url; אסמכתא בלי url היא
   **בעיה מכשילה** ולא התאמה, והתאמה טקסטואלית של מזהה **מספרי קצר** בגוף
   האסמכתא נחסמה (בקנוני היא הזדהתה במקרה עם שנה, עמוד או מספר פסקה).
2. פנקס ריק, או אובייקט JSON בלי המפתח `quotes`, מחזיר **קוד יציאה 2**
   ("לא נבדק מכנית") ולא "OK" עם קוד 0.
3. נוסף הארגומנט `--expect N` - פער בין מספר הרשומות בפנקס למספר הציטוטים
   שהזרימה מצהירה עליהם הוא בעיה מכשילה.
4. המקף העברי (U+05BE) הוצא מטווח הניקוד, ולכן הוא מגיע לטבלת נרמול המקפים
   במקום להימחק לפניה.
5. רגל המיקום מפרידה **הפניית עמוד מהפניית פסקה** ואינה מאחדת אותן לקבוצת
   מספרים אחת; ובנוסף נוסף מצב `--selftest`.

סנכרון חוזר מול המשפחה הוא משימה נפרדת, ואינו נעשה מכאן. **אין להצהיר על
קובץ זה כ"עותק זהה לקנוני"** - הצהרה שאינה נכונה גרועה מהיעדר הצהרה.

שימוש עצמאי: python check_quotes.py <quotes.json> [--expect N]
`--expect N` - מספר הציטוטים המילוליים שהזרימה מצהירה עליהם בטיוטה; פער בינו
לבין מספר הרשומות בפנקס הוא בעיה מכשילה (ציטוט בטיוטה בלי רשומה בפנקס).
בדיקה עצמית של המנוע: python check_quotes.py --selftest
שימוש כמודול:  from check_quotes import _check_quotes, _load_quotes
פלט: רשימת בעיות (מכשילות) ורשימת הערות (אינן מכשילות), או OK.
קוד יציאה: 0 - תקין; 1 - נמצאו בעיות; 2 - שגיאת שימוש או קריאה, וכן פנקס ריק
או בלי המפתח quotes ("לא נבדק מכנית").
Python 3 סטנדרטי בלבד - ללא תלויות חיצוניות.
"""

import json
import re
import sys

# --- נרמול להשוואת מחרוזות ---
# הנרמול מבטל הבדלי כתיב שאינם הבדלי תוכן בלבד; הוא **אינו** מבטל סוגריים
# מרובעים, שינוי מין/מספר או השמטת מילה - שלושת אלה חייבים ליפול בשער.
# תווי מרכאות, גרשיים ומקפים שמנורמלים - כתובים כ-escapes כדי שקובץ המקור
# עצמו יישאר נקי ממקף ארוך (מדיניות המקף הקצר).
QUOTE_CHARS = (
    "\"'\u05f3\u05f4\u2018\u2019\u201a\u201b"
    "\u201c\u201d\u201e\u201f\u2032\u2033\u00ab\u00bb")
DASH_CHARS = (
    "\u2010\u2011\u2012\u2013\u2014\u2015\u2043\u2212"
    "\u05be\ufe58\ufe63\uff0d")
# טווח הניקוד והטעמים **בלי U+05BE (מקף עברי)**: המקף העברי יושב בתוך הטווח
# הרציף, ומחיקתו כניקוד הקדימה את טבלת המקפים והפילה בשער ציטוט תקין שנשלף
# מטקסט נבו הנושא מקף עברי. הטווח מפוצל כדי שהמקף יגיע לטבלת המקפים ויומר.
NIQQUD_RE = re.compile("[\u0591-\u05bd\u05bf-\u05c7]")
BIDI_RE = re.compile("[\u00ad\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]")
WS_RE = re.compile(r"\s+")
DOC_ID_PARAM_RE = re.compile(
    r"(?:verdictid|documentid|docid)=([^&#\s)\"']+)", re.I)
URL_RE = re.compile(r"https?://[^\s)\"'<>]+", re.I)
# מזהה טקסטואלי מותר להתאמה בגוף האסמכתא רק כשאורכו MIN_TEXTUAL_ID_LEN ומעלה
# או שהוא מכיל תו שאינו ספרה; מזהה מספרי קצר מזדהה במקרה עם שנה, עמוד או
# מספר פסקה, ומעביר בשקט אסמכתא של מסמך אחר.
MIN_TEXTUAL_ID_LEN = 5

# --- רגל המיקום: הפניה לעמוד או לפסקה ---
# באסמכתא ההפניה כתובה במילים ("פסקה 12", "פס׳ 12", "עמ׳ 5"); בחלון ההקשר
# סמן הפסקה מופיע לרוב כמספר בראש שורה ("12."), ולעיתים במילים. שני הדפוסים
# מתקבלים - הבדיקה היא על קיום סמן ועל התאמתו, לא על צורת הכתיבה - אבל
# **סוג ההפניה נשמר**: עמוד מושווה לסמן עמוד ופסקה לסמן פסקה, ולא מספר מול
# מספר, שאם לא כן "עמ׳ 5" נחשב מאומת בזכות סמן הפסקה "5." שבחלון.
PARA_REF_RE = re.compile(
    "(פסקאות|פסקה|פס[׳']|עמודים|עמוד|עמ[׳'])\\s*"
    "(\\d{1,4})")
CONTEXT_PARA_NUM_RE = re.compile(r"(?:^|[\n\r])\s*(\d{1,4})\s*[.)]")


def _short(title, limit=50):
    """קיצור תווית לדיווח."""
    return title if len(title) <= limit else title[: limit - 3] + "..."


def _plain(line):
    """שורה בלי סימני הדגשה של Markdown - להשוואת תבנית בלבד."""
    return line.replace("*", "").replace("`", "")


def _norm_quote(s):
    """נרמול להשוואת מחרוזות בין ציטוט לחלון ההקשר.

    מבטל אך ורק הבדלי כתיב שאינם הבדלי תוכן: סימני כיווניות, ניקוד, וריאנטים
    של מרכאות/גרשיים ושל מקפים (לרבות המקף העברי), ורווחים כפולים. סוגריים
    מרובעים, שינוי מין או מספר והשמטת מילה נשארים הבדל - וזה בדיוק מה שהשער
    נועד לתפוס.
    """
    t = BIDI_RE.sub("", str(s))
    t = NIQQUD_RE.sub("", t)
    t = t.translate({ord(c): '"' for c in QUOTE_CHARS})
    t = t.translate({ord(c): "-" for c in DASH_CHARS})
    return WS_RE.sub(" ", t).strip()


def _citation_status(citation, doc_id):
    """מצב כבילת האסמכתא למסמך, באחד מארבעה ערכים.

    `ok` - האסמכתא מפנה לאותו documentId · `mismatch` - היא מפנה למסמך אחר ·
    `no-url` - אין באסמכתא url ולכן אין מה לאמת · `short-id` - יש url אך אין
    בו פרמטר מזהה, וה-documentId מספרי וקצר מכדי שהתאמתו בגוף האסמכתא תהיה
    ראיה. שלושת האחרונים אינם "עבר".
    """
    if not citation:
        return "no-url"
    params = DOC_ID_PARAM_RE.findall(citation)
    if params:
        return "ok" if doc_id in params else "mismatch"
    if not URL_RE.search(citation):
        return "no-url"
    if len(doc_id) >= MIN_TEXTUAL_ID_LEN or not doc_id.isdigit():
        pat = r"(?<![0-9A-Za-z])%s(?![0-9A-Za-z])" % re.escape(doc_id)
        return "ok" if re.search(pat, citation) else "mismatch"
    return "short-id"


def _ref_kind(word):
    """סוג ההפניה מתוך המילה שנתפסה - עמוד או פסקה."""
    return "עמוד" if word.startswith("עמ") else "פסקה"


def _fmt_ref(pair):
    """תצוגת זוג (סוג, מספר) לדיווח."""
    kind, num = pair
    return ("עמ׳ %s" if kind == "עמוד" else "פס׳ %s") % num


def _fmt_refs(pairs):
    """תצוגת קבוצת הפניות לדיווח, ממוינת."""
    return ", ".join(sorted(_fmt_ref(p) for p in pairs))


def _para_refs(citation):
    """ההפניות שבאסמכתא, כזוגות (סוג, מספר)."""
    return set(
        (_ref_kind(w), n)
        for w, n in PARA_REF_RE.findall(str(citation or "")))


def _context_para_marks(context):
    """הסמנים שבחלון ההקשר, כזוגות (סוג, מספר).

    סמן במילים נושא את סוגו; מספר בראש שורה ("12.") הוא סמן פסקה.
    """
    txt = str(context or "")
    marks = set((_ref_kind(w), n) for w, n in PARA_REF_RE.findall(txt))
    marks |= set(("פסקה", n) for n in CONTEXT_PARA_NUM_RE.findall(txt))
    return marks


def _check_quotes(quotes, problems, notes=None):
    """שער מכני לזהות הציטוטים.

    לכל רשומה: הציטוט קיים כמחרוזת מנורמלת בתוך חלון ההקשר השמור, והאסמכתא
    מפנה לאותו documentId. השער מחליף בדיקת שיקול דעת של המודל שהעתיק את
    הציטוט; הצהרה כללית ("הציטוטים מקורם בקטעים שהוחזרו") אינה תחליף לו.

    רגל שלישית - ההפניה לעמוד/פסקה מול סמני החלון - נכתבת ל-`notes` ואינה
    מכשילה: חלון של כ-500 תווים אינו נושא בהכרח סמן.
    """
    if notes is None:
        notes = []
    for n, q in enumerate(quotes, 1):
        if not isinstance(q, dict):
            problems.append(
                "ציטוט %d בקובץ הציטוטים אינו רשומה בתבנית "
                "{text, documentId, citation, context}." % n)
            continue
        text = str(q.get("text") or "")
        context = str(q.get("context") or "")
        doc_id = str(q.get("documentId") or "").strip()
        citation = str(q.get("citation") or "")
        label = _short(text.strip(), 40) or ("ציטוט %d" % n)
        if not text.strip():
            problems.append("ציטוט %d בקובץ הציטוטים בלי שדה text." % n)
            continue
        if not context.strip():
            problems.append(
                'ציטוט %d ("%s") בלי חלון הקשר (context) - אין מול מה להשוות; '
                "חלון ההקשר נשמר בשליפה (סוכן nevo-search או שליפה אינליין)."
                % (n, label))
        elif _norm_quote(text) not in _norm_quote(context):
            problems.append(
                'ציטוט %d ("%s") אינו קיים מילה במילה בחלון ההקשר השמור - '
                "לתקן את הציטוט ללשון המקור או להסירו (ההשוואה מתעלמת ממרכאות, "
                "מקפים, ניקוד ורווחים כפולים בלבד)." % (n, label))
        if not doc_id:
            problems.append(
                'ציטוט %d ("%s") בלי documentId - אי אפשר לאמת שהאסמכתא מפנה '
                "למסמך שממנו נשלף הציטוט." % (n, label))
        else:
            status = _citation_status(citation, doc_id)
            if status == "mismatch":
                problems.append(
                    'ציטוט %d ("%s"): האסמכתא אינה מפנה ל-documentId %s שממנו '
                    "נשלף הציטוט - לאמת מול טבלת מיפוי המקורות ומול "
                    "get_document_link." % (n, label, doc_id))
            elif status == "no-url":
                problems.append(
                    'ציטוט %d ("%s"): האסמכתא בלי url - לא ניתן לאמת את כבילת '
                    "הציטוט למסמך. ערך citation בפנקס הוא ציטוט ה-Markdown "
                    "המלא כולל הקישור שהוחזר מ-get_document_link, ולא האסמכתא "
                    "הנראית בלבד." % (n, label))
            elif status == "short-id":
                problems.append(
                    'ציטוט %d ("%s"): לא ניתן לאמת כבילה - ה-url שבאסמכתא אינו '
                    "נושא פרמטר מזהה מסמך (verdictid / documentid / docid), "
                    "וה-documentId %s הוא מספר קצר שהופעתו בגוף האסמכתא אינה "
                    "ראיה (שנה, עמוד או מספר פסקה)." % (n, label, doc_id))
        _check_para_ref(n, label, citation, context, notes)
    return notes


def _check_para_ref(n, label, citation, context, notes):
    """רגל המיקום - אזהרה שאינה מכשילה.

    שלוש התוצאות: ההפניה אומתה (סמן תואם באותו סוג בחלון ההקשר) · ההפניה לא
    אומתה (אין סמן מאותו סוג, או שהסמן אינו תואם) · אין הפניה כלל באסמכתא.
    שתי האחרונות נכתבות כהערה, ובשורת ה-QA הן נאמרות בנוסח "ההפניה לא
    אומתה" - לא "עבר".
    """
    refs = _para_refs(citation)
    if not refs:
        notes.append(
            'ציטוט %d ("%s"): ההפניה לא אומתה - אין באסמכתא מספר עמוד או '
            "פסקה שניתן לבדוק מול חלון ההקשר." % (n, label))
        return
    marks = _context_para_marks(context)
    kinds = set(k for k, _ in refs)
    same_kind = set(m for m in marks if m[0] in kinds)
    if not same_kind:
        notes.append(
            'ציטוט %d ("%s"): ההפניה לא אומתה - חלון ההקשר אינו נושא סמן '
            "מסוג %s שאפשר להשוות אליו את ההפניה (%s)."
            % (n, label, " / ".join(sorted(kinds)), _fmt_refs(refs)))
    elif not (refs & marks):
        notes.append(
            'ציטוט %d ("%s"): ההפניה לא אומתה - ההפניה (%s) אינה מופיעה '
            "בסמנים מאותו סוג שבחלון ההקשר (%s); לאמת את מספר העמוד או "
            "הפסקה מול הטקסט שנשלף."
            % (n, label, _fmt_refs(refs), _fmt_refs(same_kind)))


def _load_quotes(path):
    """טוען את קובץ הציטוטים: מערך רשומות, או אובייקט עם המפתח quotes."""
    with open(path, "r", encoding="utf-8-sig") as fh:
        data = json.load(fh)
    if isinstance(data, dict):
        if "quotes" not in data:
            raise ValueError(
                "אובייקט JSON בלי המפתח quotes - הפנקס לא נכתב כנדרש; "
                "המצב הוא 'לא נבדק מכנית' ולא 'עבר'")
        data = data["quotes"]
    if not isinstance(data, list):
        raise ValueError(
            "מבנה לא צפוי - נדרש מערך רשומות "
            "{text, documentId, citation, context}")
    return data


def _selftest():
    """בדיקת יחידה קצרה למנוע - נרמול המקף העברי, כבילה וסוג ההפניה."""
    failures = []
    maqaf = chr(0x05be)
    if _norm_quote("על-פי הסכם") != _norm_quote("על" + maqaf + "פי הסכם"):
        failures.append("מקף עברי אינו מנורמל למקף רגיל")
    url = "https://www.nevo.co.il/x.aspx?verdictid=1234567"
    if _citation_status("[ציטוט](%s)" % url, "1234567") != "ok":
        failures.append("כבילה תקינה מול verdictid לא זוהתה")
    if _citation_status("[ציטוט](%s)" % url, "7654321") != "mismatch":
        failures.append("אסמכתא של מסמך אחר לא נתפסה")
    if _citation_status("(נבו 7.9.2011)", "2011") != "no-url":
        failures.append("אסמכתא בלי url לא סווגה כלא-ניתנת לאימות")
    if _citation_status("[ציטוט](https://www.nevo.co.il/x)", "2011") != (
            "short-id"):
        failures.append("מזהה מספרי קצר בלי פרמטר לא סווג כלא-ניתן לאימות")
    if _para_refs("עמ׳ 5") & _context_para_marks("5. טקסט"):
        failures.append("הפניה לעמוד הותאמה לסמן פסקה")
    if not (_para_refs("פס׳ 5") & _context_para_marks("5. טקסט")):
        failures.append("הפניה לפסקה לא הותאמה לסמן פסקה")
    for f in failures:
        print("- כשל בבדיקה העצמית: " + f)
    if failures:
        return 1
    print("selftest OK")
    return 0


def main(argv):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    usage = "שימוש: python check_quotes.py <quotes.json> [--expect N]"
    args = list(argv[1:])
    if args and args[0] == "--selftest":
        return _selftest()
    expect = None
    if len(args) == 3 and args[1] == "--expect":
        try:
            expect = int(args[2])
        except ValueError:
            print(usage)
            return 2
        args = args[:1]
    if len(args) != 1:
        print(usage)
        return 2
    try:
        quotes = _load_quotes(args[0])
    except (OSError, UnicodeDecodeError, ValueError, json.JSONDecodeError) as exc:
        print("שגיאת קריאת קובץ הציטוטים: %s" % exc)
        return 2
    if not quotes:
        print(
            "פנקס הציטוטים ריק - השער לא נבדק מכנית. אם יש בטיוטה ציטוט "
            "מילולי אחד ומעלה, הפנקס לא נכתב: יש לכתוב רשומה "
            "{text, documentId, citation, context} לכל ציטוט ולהריץ שוב. "
            "המצב הנרשם הוא 'לא נבדק מכנית' ולעולם לא 'עבר'.")
        return 2
    problems = []
    notes = []
    _check_quotes(quotes, problems, notes)
    if expect is not None and expect != len(quotes):
        problems.append(
            "פער בין הטיוטה לפנקס: הוצהרו %d ציטוטים מילוליים בטיוטה מול %d "
            "רשומות בפנקס - ציטוט בלי רשומה אינו נבדק, ואין לרשום 'עבר'. "
            "השלם את הפנקס והרץ שוב." % (expect, len(quotes)))
    for p in problems:
        print("- " + p)
    for note in notes:
        print("מידע: " + note)
    if problems:
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
