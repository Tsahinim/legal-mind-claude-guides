#!/usr/bin/env node
/*
 * merge.mjs - legal-timeline data injector.
 *
 * Usage:
 *   node merge.mjs <template.html> <data.json> <out.html> [--doctype]
 *
 * Reads the template, locates the JSON body between the markers
 *   /+ BEGIN_TIMELINE_DATA +/ ... /+ END_TIMELINE_DATA +/   (as block comments)
 * INSIDE the <script id="timeline-data" type="application/json"> block
 * (the marker strings appear elsewhere in the file - in the documentation
 * comment and in the JS that strips them - so the search is anchored to the
 * script tag), replaces ONLY the JSON body between the markers (the markers
 * themselves are kept), escapes every "</" as "<\/" so a closing tag inside a
 * source quote cannot terminate the script block, and writes the output file.
 *
 * --doctype prepends "<!doctype html>" (used when writing the print template
 * as a standalone file; the templates ship without a doctype so they stay
 * artifact-compatible).
 *
 * Pure Node stdlib. Fails loudly (nonzero exit) on missing markers or bad JSON.
 */
import { readFileSync, writeFileSync } from "node:fs";

const BEGIN = "/* BEGIN_TIMELINE_DATA */";
const END = "/* END_TIMELINE_DATA */";
const SCRIPT_OPEN = '<script id="timeline-data"';

function fail(msg) {
  console.error("merge.mjs ERROR: " + msg);
  process.exit(1);
}

const args = process.argv.slice(2);
const flags = args.filter((a) => a.startsWith("--"));
const pos = args.filter((a) => !a.startsWith("--"));
for (const f of flags) {
  if (f !== "--doctype") fail("unknown flag: " + f);
}
if (pos.length !== 3) {
  fail("usage: node merge.mjs <template.html> <data.json> <out.html> [--doctype]");
}
const [tplPath, dataPath, outPath] = pos;
const addDoctype = flags.includes("--doctype");

let tpl;
try {
  tpl = readFileSync(tplPath, "utf8");
} catch (e) {
  fail("cannot read template file '" + tplPath + "': " + e.message);
}

let dataRaw;
try {
  dataRaw = readFileSync(dataPath, "utf8");
} catch (e) {
  fail("cannot read data file '" + dataPath + "': " + e.message);
}

let data;
try {
  data = JSON.parse(dataRaw.replace(/^\uFEFF/, ""));
} catch (e) {
  fail("data file '" + dataPath + "' is not valid JSON: " + e.message);
}
if (data === null || typeof data !== "object" || Array.isArray(data)) {
  fail("data JSON must be an object of the form { \"meta\": {...}, \"events\": [...] }");
}
if (!data.meta || typeof data.meta !== "object") {
  fail('data JSON is missing the "meta" object');
}
if (!Array.isArray(data.events)) {
  fail('data JSON is missing the "events" array');
}

// Calendar validation: a well-formed ISO string is not enough. "2025-02-31" rolls
// over silently - and to two DIFFERENT dates in the two places that parse it - so
// an impossible date is refused here rather than printed as an invented one.
const ISO_RE = /^\d{4}-\d{2}-\d{2}$/;
function isRealDate(s) {
  if (!ISO_RE.test(s)) return false;
  const [y, m, d] = s.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}
const badDates = [];
function checkDate(where, v) {
  if (typeof v !== "string" || v === "") return;
  if (!isRealDate(v)) badDates.push(where + '="' + v + '"');
}
data.events.forEach((e, i) => {
  const id = (e && e.id) || "events[" + i + "]";
  const d = e && e.dateResolved;
  if (typeof d === "string") checkDate(id + ".dateResolved", d);
  else if (d && typeof d === "object") {
    checkDate(id + ".dateResolved.start", d.start);
    checkDate(id + ".dateResolved.end", d.end);
  }
});
checkDate("meta.referenceDate", data.meta.referenceDate);
if (badDates.length) {
  fail("impossible or malformed calendar date(s): " + badDates.join(", ") +
    " - fix the data file; dates are never rolled over silently");
}

// Anchor the marker search to the timeline-data script block: the marker
// strings also appear in the template's documentation comment and in the JS
// code that strips them at runtime.
const scriptIdx = tpl.indexOf(SCRIPT_OPEN);
if (scriptIdx === -1) {
  fail("template has no " + SCRIPT_OPEN + " ...> block");
}
const scriptClose = tpl.indexOf("</script>", scriptIdx);
if (scriptClose === -1) {
  fail("timeline-data script block is never closed (</script> not found)");
}
const beginIdx = tpl.indexOf(BEGIN, scriptIdx);
if (beginIdx === -1 || beginIdx > scriptClose) {
  fail("BEGIN_TIMELINE_DATA marker not found inside the timeline-data script block");
}
const endIdx = tpl.indexOf(END, beginIdx + BEGIN.length);
if (endIdx === -1 || endIdx > scriptClose) {
  fail("END_TIMELINE_DATA marker not found inside the timeline-data script block");
}

// Re-serialize (guarantees valid JSON) and escape "</" as "<\/" - a legal JSON
// escape that JSON.parse reverses, so the injected text cannot close the tag.
const json = JSON.stringify(data, null, 2).replace(/<\//g, "<\\/");

const out =
  (addDoctype ? "<!doctype html>\n" : "") +
  tpl.slice(0, beginIdx + BEGIN.length) +
  "\n" + json + "\n" +
  tpl.slice(endIdx);

try {
  writeFileSync(outPath, out, "utf8");
} catch (e) {
  fail("cannot write output file '" + outPath + "': " + e.message);
}
console.log(
  "merge.mjs OK: wrote " + outPath +
  " (" + out.length + " chars, " + data.events.length + " events)"
);
