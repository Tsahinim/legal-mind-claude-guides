#!/usr/bin/env node
/**
 * gateb_checks.js - הבדיקות המכניות של שער ב' (נאמנות תוכן) בסקיל legal-timeline.
 * מריץ כסקריפט אחד את ב-1, ב-2, ב-3, ב-6, ב-7, ב-8, ב-9 ואת החלק המכני של ב-4
 * מתוך references/qa-checklist.md.
 * יתרת ב-4 (במסמך contract/hybrid) ו-ב-5 אינן כאן - הן נשארות לסוכן המאמת / לבדיקה עצמית.
 *
 * שימוש:
 *   node gateb_checks.js <data.json> [--require-arith] [<שם>=doc1.txt | doc1.txt ...]
 *
 * <data.json> - קובץ הנתונים { meta, events } (או מערך אירועים חשוף).
 * קבצי המסמכים אופציונליים: בלעדיהם ב-1 מדווח "לא ניתנת לבדיקה" (אימות ציטוטים ידני/סוכן).
 * **זוג שם=נתיב** (למשל "ההסכם=agreement.txt" "כתב התביעה=claim.txt") מפעיל את שיוך
 * הציטוט למסמך ש-location מפנה אליו; בלי שמות - די בהימצאות באחד המסמכים.
 * --require-arith - הופך "ב-2 לא ניתנת לבדיקה" לכשל חוסם (exit 1).
 *
 * יציאה: exit 0 כשאין FAIL; exit 1 כשיש (או כש---require-arith נדרש ולא רץ).
 * **בדיקה שלא רצה אינה "עברה":** בדיקה שלא היה לה על מה לרוץ נרשמת כ-N/A
 * ("לא ניתנת לבדיקה") ואינה נספרת בין הבדיקות שעברו.
 */
"use strict";
const fs = require("fs");

const argv = process.argv.slice(2);
const optFlags = argv.filter(a => a.startsWith("--"));
const args = argv.filter(a => !a.startsWith("--"));
for (const f of optFlags) {
  if (f !== "--require-arith") {
    console.error("דגל לא מוכר: " + f);
    process.exit(2);
  }
}
const REQUIRE_ARITH = optFlags.includes("--require-arith");
if (args.length < 1) {
  console.error("שימוש: node gateb_checks.js <data.json> [--require-arith] [<שם>=doc1 | doc1 ...]");
  process.exit(2);
}

/* נרמול משותף לשני הצדדים של ב-1 (הציטוט ב-JSON והמסמך): רווחים, מקפים,
   מרכאות טיפוגרפיות וסימני כיווניות. בלעדיו ב-7 (מקף קצר בלבד) ו-ב-1 (ציטוט
   כלשונו) סותרות זו את זו במסמך שיש בו מקף ארוך: השארת המקף מפילה את ב-7,
   ונרמולו - כפי ש-SKILL.md <שפה> מחייב - היה מפיל את ב-1. */
const norm = s => String(s)
  .replace(/[\u200B-\u200F\u202A-\u202E\u2060\uFEFF]/g, "")   // סימני כיווניות ורוחב-אפס
  .replace(/[\u2010-\u2015\u05BE\u2212]/g, "-")              // כל וריאנטי המקף הארוך למקף קצר
  .replace(/[\u201C\u201D\u201E\u201F\u05F4]/g, '"')         // מרכאות כפולות טיפוגרפיות + גרשיים
  .replace(/[\u2018\u2019\u201A\u201B\u05F3]/g, "'")         // מרכאות יחידות טיפוגרפיות + גרש
  .replace(/\s+/g, " ").trim();

let raw;
try {
  raw = JSON.parse(fs.readFileSync(args[0], "utf8"));
} catch (e) {
  console.error("FAIL: קובץ הנתונים אינו JSON תקין - " + e.message);
  process.exit(1);
}
const events = Array.isArray(raw) ? raw : (raw.events || []);

/* ארגומנט מסמך יכול להיות נתיב חשוף או זוג "<שם המסמך>=<נתיב>". השם משמש לשיוך
   הציטוט למסמך ש-location מפנה אליו (ב-1 בקלט מרובה מסמכים). */
const docs = args.slice(1).map(a => {
  const eq = a.indexOf("=");
  const named = eq > 0;
  const p = named ? a.slice(eq + 1) : a;
  return { name: named ? a.slice(0, eq).trim() : null, path: p, text: norm(fs.readFileSync(p, "utf8")) };
});
const namedDocs = docs.filter(d => d.name);
/* התאמת שם מסמך למראה מקום: "ההסכם" מול "ס' 4.2 להסכם" - ה"א הידיעה הפותחת
   נושרת כדי שאותיות השימוש (ל/ב/מ/ו/כ/ש) לא ימנעו התאמה. */
const docCore = name => norm(name).replace(/^ה/, "");

const results = []; // { id, status: PASS|FAIL|SKIP|N/A, detail }
const add = (id, status, detail) => results.push({ id, status, detail });

/* ---------- ב-1: אימות ציטוטים מילולי ---------- */
if (docs.length === 0) {
  add("ב-1", "N/A", "לא ניתנת לבדיקה - לא נמסרו קבצי מקור; אימות הציטוטים ייעשה ידנית או בסוכן");
} else {
  const b1Fail = [];
  for (const e of events) {
    const q = norm(e.sourceQuote || "");
    if (!q) { b1Fail.push(`${e.id}: sourceQuote ריק`); continue; }
    const found = docs.filter(d => d.text.includes(q));
    if (!found.length) { b1Fail.push(`${e.id}: הציטוט לא נמצא באף מסמך מקור`); continue; }
    if (!namedDocs.length) continue;             // מסמך יחיד / בלי שמות - די בהימצאות
    const loc = norm(e.location || "");
    const target = namedDocs.filter(d => loc.includes(docCore(d.name)));
    if (!target.length) continue;                // location אינו נוקב בשם מסמך מוכר
    if (target.some(d => found.indexOf(d) >= 0)) continue;   // די בהתאמה לאחד ממראי המקום
    b1Fail.push(`${e.id}: הציטוט נמצא ב-"${found.map(d => d.name || d.path).join(", ")}" אך location מפנה ל-"${target.map(d => d.name).join(", ")}"`);
  }
  if (!b1Fail.length)
    add("ב-1", "PASS", `כל ${events.length} הציטוטים נמצאו במקור` + (namedDocs.length ? " ובמסמך ש-location מפנה אליו" : ""));
  else add("ב-1", "FAIL", b1Fail.join(" | "));
}

/* ---------- ב-2: אימות אריתמטיקה של תאריכים מחושבים ---------- */
const byId = Object.fromEntries(events.map(e => [e.id, e]));
const isoRe = /^\d{4}-\d{2}-\d{2}$/;
/* פרסור קשיח: הצורה תקינה **וגם** התאריך קיים בלוח השנה. בלעדיו "2025-02-31"
   מתגלגל בשקט - ובשני מקומות לשתי תוצאות שונות (Date.UTC נותן 3.3, הבנייה
   בתבנית נותנת 2.3). מחזיר null לתאריך בלתי אפשרי; המאתר הוא ב-9. */
const parseISO = s => {
  if (typeof s !== "string" || !isoRe.test(s)) return null;
  const [y, m, d] = s.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return null;
  return dt;
};
const toISO = dt => dt.toISOString().slice(0, 10);
const offsetRe = /(\d+)\s*(ימי\s*עסקים|יום|ימים|חודשים|חודש|שבועות|שבוע|שנים|שנה)/;

/* חודש = חודש קלנדרי, ושנה = שנה קלנדרית, לפי הכלל המחייב ב-
   references/israeli-legal-temporal.md חלק ד׳: אם יום העוגן אינו קיים בחודש
   היעד - הקצה המאוחר האפשרי, כלומר היום האחרון בחודש היעד (31.1 + חודש =
   28/29.2, ולא 3.3 כפי ש-setUTCMonth גולש). */
const daysInMonth = (y, mIdx) => new Date(Date.UTC(y, mIdx + 1, 0)).getUTCDate();
const addCalendarMonths = (dt, n) => {
  const total = dt.getUTCMonth() + n;
  const ty = dt.getUTCFullYear() + Math.floor(total / 12);
  const tm = ((total % 12) + 12) % 12;
  return new Date(Date.UTC(ty, tm, Math.min(dt.getUTCDate(), daysInMonth(ty, tm))));
};
const addCalendarYears = (dt, n) => addCalendarMonths(dt, n * 12);

const b2Fail = [], b2Manual = [];
let b2Checked = 0, b2Computed = 0;
for (const e of events) {
  if (e.dateCertainty !== "computed") continue;
  b2Computed++;
  const anchorEv = typeof e.anchor === "string" ? byId[e.anchor] : null;
  const anchorDate = anchorEv && parseISO(anchorEv.dateResolved) ? anchorEv.dateResolved : null;
  const m = offsetRe.exec(e.dateRaw || "");
  if (!anchorDate || !m || !parseISO(e.dateResolved)) {
    b2Manual.push(e.id); // עוגן טקסטואלי / טווח / ניסוח לא-סטנדרטי / תאריך פסול - לבדיקת שיפוט
    continue;
  }
  if (/עסקים/.test(m[2])) { b2Manual.push(e.id + " (ימי עסקים)"); continue; }
  const n = Number(m[1]);
  const before = /לפני/.test(e.dateRaw);
  const signed = before ? -n : n;
  let dt = parseISO(anchorDate);
  if (/^(יום|ימים)$/.test(m[2])) dt.setUTCDate(dt.getUTCDate() + signed);
  else if (/^(שבוע|שבועות)$/.test(m[2])) dt.setUTCDate(dt.getUTCDate() + signed * 7);
  else if (/^(חודש|חודשים)$/.test(m[2])) dt = addCalendarMonths(dt, signed);
  else dt = addCalendarYears(dt, signed);
  b2Checked++;
  const expected = toISO(dt);
  if (expected !== e.dateResolved)
    b2Fail.push(`${e.id}: צפוי ${expected} (עוגן ${anchorDate} + "${m[0]}") אך נרשם ${e.dateResolved}`);
}
/* שלושה מצבים, לא שניים. "בדיקה שלא רצה אינה עברה": אפס תאריכים שאומתו מכנית
   אינו PASS - גם כשאין בציר אף תאריך computed, וגם כשיש כאלה אך אף אחד מהם
   אינו בר-אימות מכני. --require-arith הופך את המצב הזה לכשל חוסם. */
if (b2Fail.length) add("ב-2", "FAIL", b2Fail.join(" | "));
else if (b2Checked === 0 && b2Computed === 0)
  add("ב-2", "N/A", "לא ניתנת לבדיקה - אין בציר אף תאריך dateCertainty:\"computed\"");
else if (b2Checked === 0)
  add("ב-2", "N/A", `לא ניתנת לבדיקה - לא אומת אף תאריך מכנית; נדרשת בדיקה ידנית של ${b2Computed} אירועים מחושבים` +
    (b2Manual.length ? `: ${b2Manual.join(", ")}` : ""));
else if (b2Checked === 1 && b2Computed > 1)
  add("ב-2", "N/A", `לא ניתנת לבדיקה - אומת תאריך אחד בלבד מתוך ${b2Computed} מחושבים (ה-QA דורש שניים לפחות)` +
    (b2Manual.length ? `; לבדיקה ידנית: ${b2Manual.join(", ")}` : ""));
else add("ב-2", "PASS", `${b2Checked} תאריכים מחושבים אומתו` + (b2Manual.length ? `; לבדיקת שיפוט (לא-סטנדרטי): ${b2Manual.join(", ")}` : ""));

/* ---------- ב-3: לינט שפת דגלים ---------- */
const blacklist = ["התביעה התיישנה", "הפרה מוכחת", "אין ספק", "בוודאות", "מסקנה חד-משמעית", "הפרה יסודית"];
const b3Fail = [];
for (const e of events) {
  for (const f of e.flags || []) {
    const note = f.note || "";
    if (!note.startsWith("לאימות:")) b3Fail.push(`${e.id}/${f.kind}: ה-note אינו נפתח ב-"לאימות:"`);
    for (const bad of blacklist) if (note.includes(bad)) b3Fail.push(`${e.id}/${f.kind}: ניסוח מסקנה אסור ("${bad}")`);
  }
}
/* טקסט שנכתב לעמוד הוויזואלי נבדק באותו בלאק-ליסט (בלי דרישת התחילית "לאימות:"):
   התווית הקצרה על הפס וכותרת קו המדידה מוצגות לעו"ד ולבית המשפט ככל דגל. */
for (const e of events) {
  const sl = e.visual && e.visual.shortLabel;
  if (typeof sl === "string")
    for (const bad of blacklist) if (sl.includes(bad)) b3Fail.push(`${e.id}/visual.shortLabel: ניסוח מסקנה אסור ("${bad}")`);
}
const visMeta = (raw.meta && raw.meta.visual) || {};
const spanList = [].concat(visMeta.span || [], Array.isArray(visMeta.spans) ? visMeta.spans : []);
spanList.forEach((sp, i) => {
  const t = sp && sp.title;
  if (typeof t === "string")
    for (const bad of blacklist) if (t.includes(bad)) b3Fail.push(`meta.visual.span[${i}].title: ניסוח מסקנה אסור ("${bad}")`);
});
add("ב-3", b3Fail.length ? "FAIL" : "PASS", b3Fail.length ? b3Fail.join(" | ") : "כל הדגלים והטקסט הוויזואלי בשפת 'לאימות'");

/* ---------- ב-4 (חלק מכני): factStatus באירועי כתב טענות ---------- */
/* מכני רק כש-meta.docType === "pleadings" - שם כל אירועי הציר הם אירועי טענות.
   ב-contract וב-hybrid יש אירועים חוזיים טהורים שבהם factStatus הוא null כדין,
   ולכן שם הבדיקה מדווחת SKIP ונשארת לשיפוט (סוכן מעל הסף / בדיקה עצמית מתחתיו).
   יתר רכיבי ב-4 (שם צד מאוחד מ-meta.parties) נשארים לשיפוט בכל מקרה. */
const docType = (raw && raw.meta && raw.meta.docType) || null;
if (docType !== "pleadings") {
  add("ב-4 (מכני)", "SKIP", `docType=${docType || "לא צוין"} - עקביות המצב נבדקת בשיפוט (סוכן / בדיקה עצמית)`);
} else {
  const b4Fail = events
    .filter(e => e.factStatus === null || e.factStatus === undefined || e.factStatus === "")
    .map(e => e.id);
  if (b4Fail.length) add("ב-4 (מכני)", "FAIL", "אירוע כתב טענות בלי factStatus (established/alleged/disputed): " + b4Fail.join(", "));
  else add("ב-4 (מכני)", "PASS", `לכל ${events.length} אירועי כתב הטענות נקבע factStatus; שם הצד המאוחד - לשיפוט`);
}

/* ---------- ב-6: תאריכים מחוץ לטווח סביר ---------- */
const b6Fail = [];
const checkYear = (id, iso) => {
  const y = Number(String(iso).slice(0, 4));
  if (y < 1900 || y > 2100) b6Fail.push(`${id}: ${iso}`);
};
for (const e of events) {
  const d = e.dateResolved;
  if (typeof d === "string" && isoRe.test(d)) checkYear(e.id, d);
  else if (d && typeof d === "object") { if (d.start) checkYear(e.id, d.start); if (d.end) checkYear(e.id, d.end); }
}
add("ב-6", b6Fail.length ? "FAIL" : "PASS", b6Fail.length ? "תאריך חשוד (כנראה שגיאת dd/mm): " + b6Fail.join(", ") : "כל התאריכים בטווח 1900-2100");

/* ---------- ב-7: לינט מקף קצר ---------- */
const longDash = new RegExp("[\\u2010-\\u2015\\u05BE]"); // en/em-dash, U+2010..U+2015, U+05BE
const b7Fail = [];
(function walk(node, path) {
  if (typeof node === "string") { if (longDash.test(node)) b7Fail.push(path); }
  else if (Array.isArray(node)) node.forEach((v, i) => walk(v, `${path}[${i}]`));
  else if (node && typeof node === "object") for (const k of Object.keys(node)) walk(node[k], path ? `${path}.${k}` : k);
})(raw, "");
add("ב-7", b7Fail.length ? "FAIL" : "PASS", b7Fail.length ? "מקף ארוך אסור ב: " + b7Fail.join(", ") : "מקף קצר בלבד בכל המחרוזות");

/* ---------- ב-8: עקביות עוגן/דגל ---------- */
/* סתירה: ה-anchor הוא מזהה של אירוע קיים שתאריכו נפתר, ובכל זאת האירוע נושא דגל unresolvedAnchor.
   עוגן שהוא צומת placeholder בלי תאריך (ביצוע עתידי שטרם אירע) אינו סתירה - שם הדגל במקומו,
   וכך גם עוגן טקסטואלי. הלולאה של ב-2 מדלגת על מקרים אלה כי dateCertainty אינו "computed". */
const anchorResolvedDate = ev => {
  const d = ev && ev.dateResolved;
  if (typeof d === "string") return isoRe.test(d) ? d : null;
  if (d && typeof d === "object" && d.start && d.end) return `${d.start}..${d.end}`;
  return null;
};
const b8Fail = [];
for (const e of events) {
  if (!(e.flags || []).some(f => f && f.kind === "unresolvedAnchor")) continue;
  const anchorEv = typeof e.anchor === "string" ? byId[e.anchor] : null;
  const d = anchorResolvedDate(anchorEv);
  if (d) b8Fail.push(`${e.id}: anchor="${e.anchor}" מצביע על אירוע מתוארך (${d}) ובכל זאת נושא דגל unresolvedAnchor`);
}
add("ב-8", b8Fail.length ? "FAIL" : "PASS", b8Fail.length ? "צירוף סותר עוגן/דגל: " + b8Fail.join(" | ") : "אין צירוף סותר של עוגן פתור עם דגל unresolvedAnchor");

/* ---------- ב-9: תאריך קלנדרי בלתי אפשרי ---------- */
/* צורת ISO תקינה אינה מספיקה: 2025-02-31 ו-2024-02-30 אינם קיימים בלוח השנה,
   ו-2025-13-01 אינו חודש. תאריך כזה גולש בשקט לתאריך אחר - ובשני מקומות
   בקוד לשתי תוצאות שונות - ולכן הוא כשל, לא אזהרה. */
const b9Fail = [];
const checkCalendar = (id, field, v) => {
  if (typeof v !== "string" || !v) return;
  if (!isoRe.test(v)) { b9Fail.push(`${id}.${field}: "${v}" אינו בצורת YYYY-MM-DD`); return; }
  if (!parseISO(v)) b9Fail.push(`${id}.${field}: "${v}" אינו תאריך קיים בלוח השנה`);
};
for (const e of events) {
  const d = e.dateResolved;
  if (typeof d === "string") checkCalendar(e.id, "dateResolved", d);
  else if (d && typeof d === "object") {
    checkCalendar(e.id, "dateResolved.start", d.start);
    checkCalendar(e.id, "dateResolved.end", d.end);
  }
}
const metaRef = raw && raw.meta && raw.meta.referenceDate;
if (typeof metaRef === "string" && metaRef) checkCalendar("meta", "referenceDate", metaRef);
add("ב-9", b9Fail.length ? "FAIL" : "PASS",
  b9Fail.length ? "תאריך בלתי אפשרי: " + b9Fail.join(" | ") : "כל התאריכים קיימים בלוח השנה");

/* ---------- ב-10: תקופת ההתיישנות נרשמה במפורש ---------- */
/* בציר שיש בו אירוע knowledge/breach/damage מתוארך, התבנית חייבת לדעת מהי
   התקופה ומהו העוגן - אחרת היא נופלת ל-7 שנים קשיחות ולעוגן יחיד, ותקופות
   15/25 שנה במקרקעין ותקרת 10 השנים בנזיקין אינן יכולות להגיע לתוצר.
   meta.limitation = { anchorId, periodYears | periodDays, basis }, או מערך
   כזה כשיש כמה עילות (israeli-legal-temporal.md א.1/א.3/א.6). */
const LIMIT_TYPES = { knowledge: 1, breach: 1, damage: 1 };
const limCandidates = events.filter(e => LIMIT_TYPES[e.type] && (
  (typeof e.dateResolved === "string" && isoRe.test(e.dateResolved)) ||
  (e.dateResolved && typeof e.dateResolved === "object" && e.dateResolved.start)));
if (!limCandidates.length) {
  add("ב-10", "N/A", "לא ניתנת לבדיקה - אין בציר אירוע knowledge/breach/damage מתוארך");
} else {
  let lim = raw && raw.meta && raw.meta.limitation;
  if (lim && !Array.isArray(lim)) lim = [lim];
  const b10Fail = [];
  if (!Array.isArray(lim) || !lim.length) {
    b10Fail.push(`קיימים ${limCandidates.length} אירועי עילה מתוארכים (${limCandidates.map(e => e.id).join(", ")}) ואין meta.limitation - התקופה והעוגן חייבים להיכתב`);
  } else {
    lim.forEach((s, i) => {
      if (!s || typeof s !== "object") { b10Fail.push(`meta.limitation[${i}]: אינו אובייקט`); return; }
      const anchorEv = typeof s.anchorId === "string" ? byId[s.anchorId] : null;
      if (!anchorEv) { b10Fail.push(`meta.limitation[${i}]: anchorId="${s.anchorId}" אינו מזהה אירוע קיים`); return; }
      if (!parseISO(anchorEv.dateResolved) && !(anchorEv.dateResolved && anchorEv.dateResolved.start))
        b10Fail.push(`meta.limitation[${i}]: אירוע העוגן ${s.anchorId} אינו מתוארך`);
      const py = typeof s.periodYears === "number" && s.periodYears > 0;
      const pd = typeof s.periodDays === "number" && s.periodDays > 0;
      if (!py && !pd) b10Fail.push(`meta.limitation[${i}]: חסרה תקופה (periodYears או periodDays חיובי)`);
      if (typeof s.basis !== "string" || !s.basis.trim())
        b10Fail.push(`meta.limitation[${i}]: חסרה basis - האסמכתה מוצגת בהערת הדגל`);
    });
  }
  if (b10Fail.length) add("ב-10", "FAIL", b10Fail.join(" | "));
  else add("ב-10", "PASS", `נרשמו ${lim.length} תקופות התיישנות עם עוגן ואסמכתה`);
}

/* ---------- ב-11: סימון onTimeline מעל 9 אירועים מתוארכים ---------- */
/* הכלל קיים ב-visual-timeline.md 3.1 ולא נאכף בשום שער: יותר מ-9 אירועים
   מתוארכים בלי אף visual.onTimeline:true - התבנית בוחרת לבד לפי ניקוד חי,
   והעמוד עלול להציג אירועים אחרים מאלה שהוצגו לעו"ד בשער. */
const wantVisual = !!(raw && raw.meta && raw.meta.render && raw.meta.render.visual === true);
if (!wantVisual) {
  add("ב-11", "N/A", "לא ניתנת לבדיקה - לא נבחר עמוד ויזואלי (meta.render.visual אינו true)");
} else {
  const datedEvents = events.filter(e =>
    (typeof e.dateResolved === "string" && isoRe.test(e.dateResolved)) ||
    (e.dateResolved && typeof e.dateResolved === "object" && e.dateResolved.start));
  const marked = datedEvents.filter(e => e.visual && e.visual.onTimeline === true);
  if (datedEvents.length > 9 && !marked.length)
    add("ב-11", "FAIL", `${datedEvents.length} אירועים מתוארכים ואף אחד אינו מסומן visual.onTimeline:true - סמן עד 9 אירועי מפתח, אחרת הצמתים בעמוד אינם הרשימה שאושרה בשער`);
  else if (datedEvents.length < 2)
    add("ב-11", "FAIL", `${datedEvents.length} אירועים מתוארכים - אין די צמתים לעמוד ויזואלי; אין להציע אותו`);
  else
    add("ב-11", "PASS", marked.length ? `${marked.length} אירועים מסומנים לציר מתוך ${datedEvents.length} מתוארכים` : `${datedEvents.length} אירועים מתוארכים (עד 9) - כולם על הציר`);
}

/* ---------- דוח ---------- */
let hasFail = false;
for (const r of results) {
  if (r.status === "FAIL") hasFail = true;
  console.log(`${r.id} ${r.status}: ${r.detail}`);
}
/* שורת הסיכום לפי מצבי הדיווח של החבילה: "בוצעו N · לא ניתנות" ולעולם לא "N/N" -
   בדיקה שלא רצה אינה נבלעת במונה. */
const pass = results.filter(r => r.status === "PASS").length;
const failed = results.filter(r => r.status === "FAIL");
const notRun = results.filter(r => r.status === "N/A" || r.status === "SKIP");
console.log(`---\nסיכום שער ב' (מכני): בוצעו ${pass}` +
  (failed.length ? ` · נכשלו ${failed.length}: ${failed.map(r => r.id).join(", ")}` : "") +
  (notRun.length ? ` · לא ניתנות לבדיקה כאן: ${notRun.map(r => r.id).join(", ")}` : "") +
  ` · אירועים: ${events.length} · יתרת ב-4 ו-ב-5 (שיפוט) אינן בסקריפט זה`);
/* --require-arith: סביבה שבה שער ב-2 חייב לרוץ מכנית - "לא ניתנת לבדיקה" הופכת לחוסמת. */
const arithBlocked = REQUIRE_ARITH && results.some(r => r.id === "ב-2" && r.status === "N/A");
if (arithBlocked) console.log("ב-2 נדרשה מכנית (--require-arith) ולא רצה - חוסם.");
process.exit(hasFail || arithBlocked ? 1 : 0);
