#!/usr/bin/env node
/**
 * gatec_checks.js - הבדיקות המכניות של שער ג' (תקינות התוצר) בסקיל legal-timeline.
 * זהו השער היחיד שנוגע ב**קובץ שנמסר לעו"ד** בפועל, ולא ב-JSON שלפניו.
 *
 * שימוש:
 *   node gatec_checks.js <out.html> <data.json> [out.pdf]
 *
 * <out.html>  - קובץ ה-HTML המוזרק (קובץ הביניים בדרגה 1, קובץ היעד בדרגה 2).
 * <data.json> - קובץ הנתונים שאושר בשער - ה**מקור** שמולו נבדק התוצר.
 * [out.pdf]   - ה-PDF שהופק, כשקיים. בלעדיו ג-5 (רכיב ה-PDF) ו-ג-10 מדווחות N/A.
 *
 * מה נבדק מכנית כאן: ג-1 (סמנים ופרסור בתוך בלוק ה-script), ג-2 (אסקייפ),
 * ג-3 (כל אירוע, שם צד ודגל שנכתב מגיעים לתוצר, והתבנית אינה מוחקת דגל כתוב),
 * ג-4 (אפס משאבים חיצוניים ואפס innerHTML), ג-5 (הקובץ נוצר וגודלו סביר),
 * ג-7 עד ג-9 (העמוד הוויזואלי - צמתים, קווי מדידה, חשבון X מתוך Y) ו-ג-10
 * (מספר עמודי ה-PDF מול הצפוי).
 *
 * **מה אינו ניתן לבדיקה מכנית ואינו נבדק כאן:** ג-6 (פתיחה חזותית של ה-PDF -
 * חיתוך עמודות, גלישת טקסט, קריאוּת) והרכיב החזותי של ג-10 (מקטע או תווית
 * שנחתכו). אלה נשארות דגימה ידנית ומסומנות ככאלה בפלט - הסקריפט אינו מעמיד
 * פנים שבדק אותן.
 *
 * יציאה: exit 0 כשאין FAIL; exit 1 כשיש.
 * **בדיקה שלא רצה אינה "עברה":** בדיקה שלא היה לה על מה לרוץ נרשמת כ-N/A
 * ("לא ניתנת לבדיקה") ואינה נספרת בין הבדיקות שבוצעו.
 */
"use strict";
const fs = require("fs");

const argv = process.argv.slice(2).filter(a => !a.startsWith("--"));
if (argv.length < 2) {
  console.error("שימוש: node gatec_checks.js <out.html> <data.json> [out.pdf]");
  process.exit(2);
}
const [htmlPath, dataPath, pdfPath] = argv;

const results = [];                       // { id, status: PASS|FAIL|N/A, detail }
const add = (id, status, detail) => results.push({ id, status, detail });
const manual = [];                        // בדיקות שנשארות לעין, ואינן נספרות
const addManual = (id, detail) => manual.push({ id, detail });

let html;
try { html = fs.readFileSync(htmlPath, "utf8"); }
catch (e) { console.error("FAIL: לא ניתן לקרוא את קובץ ה-HTML - " + e.message); process.exit(1); }

let approved;
try { approved = JSON.parse(fs.readFileSync(dataPath, "utf8").replace(/^﻿/, "")); }
catch (e) { console.error("FAIL: קובץ הנתונים שאושר אינו JSON תקין - " + e.message); process.exit(1); }

/* ---------- ג-1: הסמנים והפרסור, בתוך בלוק ה-script בלבד ---------- */
/* הניסוח הישן ("כל סמן קיים בדיוק פעם אחת בקובץ") נכשל בכל ריצה תקינה: הסמנים
   מופיעים גם בהערת התיעוד שבראש התבנית וגם בקוד ה-JS שמסיר אותם בזמן ריצה.
   הבדיקה מעוגנת לחלון של merge.mjs: <script id="timeline-data" ... ה-</script>
   הראשון שאחריו, ובתוכו בלבד נדרש סמן BEGIN אחד וסמן END אחד. */
const SCRIPT_OPEN = '<script id="timeline-data"';
const BEGIN = "/* BEGIN_TIMELINE_DATA */";
const END = "/* END_TIMELINE_DATA */";
const countOf = (hay, needle) => hay.split(needle).length - 1;

let injected = null, body = null;
(function gate1() {
  const si = html.indexOf(SCRIPT_OPEN);
  if (si === -1) { add("ג-1", "FAIL", `לא נמצא בלוק ${SCRIPT_OPEN} בתוצר`); return; }
  const sc = html.indexOf("</script>", si);
  if (sc === -1) { add("ג-1", "FAIL", "בלוק timeline-data אינו נסגר (</script> חסר)"); return; }
  const win = html.slice(si, sc);
  const nb = countOf(win, BEGIN), ne = countOf(win, END);
  if (nb !== 1 || ne !== 1) {
    add("ג-1", "FAIL", `בתוך בלוק הנתונים נמצאו ${nb} סמני BEGIN ו-${ne} סמני END; נדרש אחד מכל אחד`);
    return;
  }
  const bi = win.indexOf(BEGIN), ei = win.indexOf(END);
  if (ei < bi) { add("ג-1", "FAIL", "סמן END מופיע לפני סמן BEGIN בתוך בלוק הנתונים"); return; }
  body = win.slice(bi + BEGIN.length, ei);
  try { injected = JSON.parse(body); }
  catch (e) { add("ג-1", "FAIL", "ה-JSON שבין הסמנים אינו מתפרסר - " + e.message); return; }
  add("ג-1", "PASS", `סמן BEGIN אחד וסמן END אחד בתוך בלוק הנתונים, וה-JSON שביניהם מתפרסר (${countOf(html, BEGIN)} מופעי BEGIN בקובץ כולו - מותר מחוץ לחלון)`);
})();

/* ---------- ג-2: אסקייפ ---------- */
if (body === null) add("ג-2", "N/A", "לא ניתנת לבדיקה - בלוק הנתונים לא אותר");
else {
  const raw = countOf(body, "</");
  if (raw) add("ג-2", "FAIL", `נמצאו ${raw} רצפי "</" גולמיים בבלוק הנתונים - תג סגירה בתוך ציטוט עלול לסגור את בלוק ה-script; נדרש "<\\/"`);
  else add("ג-2", "PASS", `אין רצף "</" גולמי בבלוק הנתונים (${countOf(body, "<\\/")} רצפים מואסקפים)`);
}

/* ---------- ג-3: האירועים, הצדדים והדגלים הגיעו לתוצר ---------- */
const evOf = d => (d && Array.isArray(d.events)) ? d.events : (Array.isArray(d) ? d : []);
const partiesOf = d => ((d && d.meta && Array.isArray(d.meta.parties)) ? d.meta.parties : []).map(p => (p && p.name) || "");
if (injected === null) add("ג-3", "N/A", "לא ניתנת לבדיקה - בלוק הנתונים לא אותר");
else {
  const a = evOf(approved), b = evOf(injected);
  const fail = [];
  if (a.length !== b.length) fail.push(`מספר האירועים: ${a.length} אושרו, ${b.length} בתוצר`);
  const ida = a.map(e => e.id).join(","), idb = b.map(e => e.id).join(",");
  if (ida !== idb) {
    const miss = a.map(e => e.id).filter(i => b.every(e => e.id !== i));
    const extra = b.map(e => e.id).filter(i => a.every(e => e.id !== i));
    fail.push("מזהי האירועים אינם זהים" + (miss.length ? ` (חסרים: ${miss.join(", ")})` : "") + (extra.length ? ` (עודפים: ${extra.join(", ")})` : ""));
  }
  const pa = partiesOf(approved).join(" | "), pb = partiesOf(injected).join(" | ");
  if (pa !== pb) fail.push(`שמות הצדדים: אושרו "${pa}", בתוצר "${pb}"`);
  /* כל דגל שנכתב ב-JSON שאושר חייב להימצא בתוצר, עם ה-note שלו - שם יושבת
     הסתייגות ההארכה במועד דיוני. */
  const byIdB = {}; b.forEach(e => { if (e && e.id) byIdB[e.id] = e; });
  let flagCount = 0;
  a.forEach(e => {
    (e.flags || []).forEach(f => {
      if (!f || !f.kind) return;
      flagCount++;
      const t = byIdB[e.id];
      const g = t && (t.flags || []).find(x => x && x.kind === f.kind);
      if (!g) { fail.push(`${e.id}: הדגל "${f.kind}" שנכתב ב-JSON אינו בתוצר`); return; }
      if ((g.note || "") !== (f.note || "")) fail.push(`${e.id}/${f.kind}: ה-note בתוצר שונה מזה שאושר`);
    });
  });
  /* שומר רגרסיה על קוד הרינדור: בגרסאות קודמות effectiveFlags שמרה דגל כתוב רק
     כשלא היה ב-TIME_KINDS, ולכן מחקה בשקט דגל זמן שנכתב (ובכללו מועד דיוני עם
     הסתייגות ההארכה) אחרי ששער ב' דיווח עליו PASS. הדגל קיים בבלוק הנתונים -
     ונעלם מהעמוד. הבדיקה הזו תופסת את החזרת הפילטר. */
  const flat = html.replace(/\s+/g, "");
  if (flat.includes("!TIME_KINDS[f.kind]"))
    fail.push("קוד הרינדור מסנן דגלים כתובים לפי TIME_KINDS - דגל זמן שנכתב ימחק בשקט מהעמוד");
  else if (!flat.includes("(ev.flags||[]).forEach(function(f){if(f&&f.kind)map[f.kind]=f;});"))
    fail.push("לא אותר בקוד הרינדור השורש שמזין את כל הדגלים הכתובים ל-effectiveFlags - יש לוודא ידנית שדגל כתוב אינו נמחק");
  if (fail.length) add("ג-3", "FAIL", fail.join(" | "));
  else add("ג-3", "PASS", `${b.length} אירועים, ${partiesOf(injected).length} צדדים ו-${flagCount} דגלים כתובים - זהים למה שאושר; קוד הרינדור אינו מסנן דגלים כתובים`);
}

/* ---------- ג-4: אפס משאבים חיצוניים ואפס innerHTML ---------- */
(function gate4() {
  const fail = [];
  const ext = html.match(/(?:\bsrc|\bhref)\s*=\s*["']?\s*(?:https?:)?\/\//gi);
  if (ext) fail.push(`משאב חיצוני ב-src/href (${ext.length} מופעים)`);
  const ih = html.match(/\.innerHTML\b/g);
  if (ih) fail.push(`שימוש ב-innerHTML (${ih.length} מופעים) - הזרקת טקסט לא-מבוקר ל-DOM`);
  if (fail.length) add("ג-4", "FAIL", fail.join(" | "));
  else add("ג-4", "PASS", "אין http/https ב-src/href ואין innerHTML - הקובץ עצמאי");
})();

/* ---------- ג-5: התוצר נוצר בפועל ---------- */
const MIN_HTML = 20 * 1024, MIN_PDF = 10 * 1024;
let pdfPages = null;
(function gate5() {
  const detail = [];
  let fail = false;
  const hs = fs.statSync(htmlPath).size;
  detail.push(`HTML ${htmlPath}: ${Math.round(hs / 1024)}KB`);
  if (hs < MIN_HTML) { fail = true; detail.push(`גודל ה-HTML קטן מהמינימום (${Math.round(MIN_HTML / 1024)}KB) - ייתכן שההזרקה נכשלה`); }
  if (!pdfPath) {
    add("ג-5", fail ? "FAIL" : "PASS", detail.join(" · ") + " · PDF: לא נמסר נתיב - רכיב ה-PDF לא נבדק (דרגה 2 או 3)");
    return;
  }
  let buf;
  try { buf = fs.readFileSync(pdfPath); }
  catch (e) { add("ג-5", "FAIL", detail.join(" · ") + ` · קובץ ה-PDF "${pdfPath}" אינו קיים - אין לדווח על PDF שלא נוצר`); return; }
  detail.push(`PDF ${pdfPath}: ${Math.round(buf.length / 1024)}KB`);
  if (buf.length < MIN_PDF) { fail = true; detail.push(`גודל ה-PDF קטן מהמינימום (${Math.round(MIN_PDF / 1024)}KB)`); }
  if (buf.slice(0, 5).toString("latin1") !== "%PDF-") { fail = true; detail.push("הקובץ אינו מתחיל ב-%PDF-"); }
  pdfPages = pdfPageCount(buf);
  detail.push(pdfPages === null ? "מספר העמודים לא נקבע מהקובץ" : `${pdfPages} עמודים`);
  add("ג-5", fail ? "FAIL" : "PASS", detail.join(" · "));
})();

function pdfPageCount(buf) {
  const s = buf.toString("latin1");
  const m = s.match(/\/Type\s*\/Page(?![sA-Za-z])/g);
  if (m && m.length) return m.length;
  const counts = s.match(/\/Count\s+(\d+)/g);
  if (counts) return Math.max.apply(null, counts.map(c => Number(c.replace(/\D+/g, ""))));
  return null;      // xref/objects דחוסים - לא נקבע, ולא מומצא
}

/* ---------- ג-6: דגימה ידנית, לא מכנית ---------- */
addManual("ג-6", "פתיחה חזותית של התוצר: הטבלה נטענת במלואה, תמצית ההתראות מציגה את הדגלים הצפויים, אין עמודה חתוכה ואין טקסט שגלש. **אינה ניתנת לבדיקה מכנית** - הטבלה נבנית ב-JS בזמן הצפייה, וחיתוך הוא תוצאה של פריסה.");

/* ---------- העמוד הוויזואלי: ג-7 עד ג-10 ---------- */
const V_MAX = 9, V_ROW_MAX = 9, MS_DAY = 86400000;
const isoRe = /^\d{4}-\d{2}-\d{2}$/;
function parseISO(s) {
  if (typeof s !== "string" || !isoRe.test(s)) return null;
  const [y, m, d] = s.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return null;
  return dt;
}
function startDate(ev) {
  const d = ev && ev.dateResolved;
  if (typeof d === "string") return parseISO(d);
  if (d && typeof d === "object" && d.start) return parseISO(d.start);
  return null;
}
function endDate(ev) {
  const d = ev && ev.dateResolved;
  if (typeof d === "string") return parseISO(d);
  if (d && typeof d === "object" && d.end) return parseISO(d.end);
  return null;
}
const trim1 = x => (Math.round(x * 10) / 10).toFixed(1).replace(/\.0$/, "");
/* שכפול מדויק של durationText שבתבנית - כדי שהמשך המוצג ייבדק מול חישוב עצמאי. */
function durationText(a, b) {
  const days = Math.abs(Math.round((b - a) / MS_DAY));
  if (days === 0) return "אותו יום";
  if (days === 1) return "יום אחד";
  if (days === 2) return "יומיים";
  if (days < 45) return days + " ימים";
  const months = days / 30.4375;
  if (months < 24) return trim1(months) + " חודשים";
  return trim1(days / 365.25) + " שנים";
}
/* שכפול selectVisual, בשני המסלולים הדטרמיניסטיים בלבד. המסלול השלישי - בחירה
   אוטומטית מעל 9 אירועים מתוארכים - מדרג לפי דגלים שמחושבים **חי בדפדפן** מול
   תאריך הצפייה, ולכן אינו ניתן לשחזור כאן ואינו ניתן להשוואה מול הרשימה שהוצגה
   בשער. הכלל שב-visual-timeline.md 3.1 מחייב ממילא לסמן onTimeline מעל 9. */
function selectVisual(data) {
  const dated = evOf(data).filter(startDate).sort((x, y) => startDate(x) - startDate(y));
  const explicit = dated.filter(e => e.visual && e.visual.onTimeline === true);
  if (explicit.length) return { dated, sel: explicit, mode: "explicit" };
  if (dated.length <= V_MAX) return { dated, sel: dated.slice(), mode: "all" };
  return { dated, sel: null, mode: "auto" };
}
const SPAN_FROM_TYPES = { obligation: 1, payment: 1, notice: 1 };
function collectSpans(data, sel) {
  const VIS = (data.meta && data.meta.visual) || {};
  let out = [];
  if (VIS.span) out.push(VIS.span);
  if (Array.isArray(VIS.spans)) out = out.concat(VIS.spans);
  const authored = ("span" in VIS) || ("spans" in VIS);
  if (authored || VIS.autoSpan === false || (data.meta && data.meta.docType) !== "hybrid")
    return { spans: out, auto: false };
  const byId = {}; evOf(data).forEach(e => { if (e && e.id) byId[e.id] = e; });
  const onV = {}; sel.forEach(e => { onV[e.id] = 1; });
  let best = null;
  sel.forEach(ev => {
    if (!SPAN_FROM_TYPES[ev.type]) return;
    const a = startDate(ev); if (!a) return;
    (ev.links || []).forEach(l => {
      const t = byId[l.toId];
      if (!t || !onV[t.id] || t.type !== "breach") return;
      const b = endDate(t) || startDate(t); if (!b) return;
      const gap = Math.round((b - a) / MS_DAY);
      if (gap < 45) return;
      if (!best || gap > best.gap) best = { gap: gap, fromId: ev.id, toId: t.id };
    });
  });
  if (best) out.push({ fromId: best.fromId, toId: best.toId, title: "פער של" });
  return { spans: out, auto: !!best };
}

const VISUAL_IDS = ["ג-7", "ג-8", "ג-9"];   // ג-10 מוכרעת בנפרד, אחרי ספירת עמודי ה-PDF
const wantVisual = injected && injected.meta && injected.meta.render && injected.meta.render.visual === true;
const wantTable = !(injected && injected.meta && injected.meta.render && injected.meta.render.table === false);
let visualRendered = false;

if (!injected) VISUAL_IDS.forEach(id => add(id, "N/A", "לא ניתנת לבדיקה - בלוק הנתונים לא אותר"));
else if (!wantVisual) VISUAL_IDS.forEach(id => add(id, "N/A", "לא ניתנת לבדיקה - לא נבחר עמוד ויזואלי (meta.render.visual אינו true)"));
else {
  const cur = selectVisual(injected), ok = selectVisual(approved);
  /* ג-7 */
  if (cur.mode === "auto") {
    add("ג-7", "FAIL", `${cur.dated.length} אירועים מתוארכים ואף אחד אינו מסומן visual.onTimeline:true - הבחירה נעשית בתבנית לפי ניקוד חי, ולכן הצמתים שיוצגו אינם ניתנים להשוואה מול הרשימה שאושרה בשער (visual-timeline.md 3.1 מחייב לסמן מעל 9)`);
    add("ג-8", "N/A", "לא ניתנת לבדיקה - קבוצת הצמתים אינה ידועה (ראה ג-7)");
    add("ג-9", "N/A", "לא ניתנת לבדיקה - קבוצת הצמתים אינה ידועה (ראה ג-7)");
  } else if (cur.sel.length < 2) {
    add("ג-7", "N/A", `לא ניתנת לבדיקה - ${cur.sel.length} אירועים מתוארכים על הציר; העמוד הוויזואלי לא נוצר ואין לדווח עליו`);
    add("ג-8", "N/A", "לא ניתנת לבדיקה - העמוד הוויזואלי לא נוצר");
    add("ג-9", "N/A", "לא ניתנת לבדיקה - העמוד הוויזואלי לא נוצר");
  } else {
    visualRendered = true;
    const fail = [];
    const idsCur = cur.sel.map(e => e.id).join(",");
    const idsOk = ok.sel ? ok.sel.map(e => e.id).join(",") : null;
    if (idsOk === null) fail.push("ב-JSON שאושר הבחירה אוטומטית ואינה ניתנת לשחזור - אין מול מה להשוות");
    else if (idsCur !== idsOk) fail.push(`קבוצת הצמתים בתוצר (${idsCur}) שונה מזו שאושרה (${idsOk})`);
    cur.sel.forEach((e, i) => {
      const lab = ((e.visual && e.visual.shortLabel) || e.label || "").trim();
      if (!lab) fail.push(`${e.id}: צומת ${i + 1} בלי תווית`);
      if (!startDate(e)) fail.push(`${e.id}: צומת בלי תאריך`);
    });
    if (fail.length) add("ג-7", "FAIL", fail.join(" | "));
    else add("ג-7", "PASS", `${cur.sel.length} צמתים (${cur.mode === "explicit" ? "onTimeline מפורש" : "כל האירועים המתוארכים"}), כולם עם תאריך ותווית, וקבוצת המזהים זהה לזו שאושרה: ${idsCur}`);

    /* ג-8 */
    const sp = collectSpans(injected, cur.sel);
    if (!sp.spans.length) add("ג-8", "N/A", "לא ניתנת לבדיקה - אין קו מדידה בעמוד (לא נכתב span ולא נגזר אוטומטית)");
    else {
      const byId = {}; evOf(injected).forEach(e => { if (e && e.id) byId[e.id] = e; });
      const onSel = {}; cur.sel.forEach((e, i) => { onSel[e.id] = i; });
      const rows = Math.ceil(cur.sel.length / V_ROW_MAX), per = Math.ceil(cur.sel.length / rows);
      const f8 = [], ok8 = [];
      sp.spans.forEach((s, i) => {
        if (!s || !s.fromId || !s.toId) { f8.push(`span[${i}]: חסר fromId/toId`); return; }
        const f = byId[s.fromId], t = byId[s.toId];
        if (!f || !t) { f8.push(`span[${i}]: מפנה למזהה שאינו קיים (${s.fromId} / ${s.toId})`); return; }
        const a = startDate(f), b = endDate(t) || startDate(t);
        if (!a || !b) { f8.push(`span[${i}]: אחד הקצוות אינו מתוארך`); return; }
        if (!(s.fromId in onSel) || !(s.toId in onSel)) { f8.push(`span[${i}]: קצה שאינו על הציר (${s.fromId} / ${s.toId})`); return; }
        const title = String(s.title || "פער של");
        if (/\d/.test(title) && /(ימים|יום|חודשים|חודש|שנים|שנה)/.test(title))
          f8.push(`span[${i}]: ה-title נוקב במספר ("${title}") - המשך מחושב בקוד ואינו נכתב בטקסט`);
        const sameRow = Math.floor(onSel[s.fromId] / per) === Math.floor(onSel[s.toId] / per);
        ok8.push(`span[${i}] ${s.fromId}->${s.toId}: ${title} ${durationText(a, b)}` + (sameRow ? "" : " (קצוות בשורות שונות - אין קו, המשך עובר לשורת ההסבר)"));
      });
      if (f8.length) add("ג-8", "FAIL", f8.join(" | "));
      else add("ג-8", "PASS", (sp.auto ? "קו מדידה נגזר אוטומטית · " : "") + ok8.join(" · ") + " - המשך שחושב כאן עצמאית; השוואתו לטקסט שעל העמוד היא הדגימה הידנית ג-6");
    }

    /* ג-9 */
    if (cur.sel.length < cur.dated.length)
      add("ג-9", "PASS", `נבחרו אירועי מפתח - העמוד אמור להצהיר "מוצגים ${cur.sel.length} מתוך ${cur.dated.length}"; הספירה נגזרת מהנתונים ותקינה`);
    else
      add("ג-9", "PASS", `כל ${cur.dated.length} האירועים המתוארכים על הציר - אין שורת "X מתוך Y" ואין מה לספור`);
  }
}

/* ג-10: מספר עמודי ה-PDF מול הצפוי. החיתוך החזותי - ידני. */
if (!injected) add("ג-10", "N/A", "לא ניתנת לבדיקה - בלוק הנתונים לא אותר");
else if (!wantVisual) add("ג-10", "N/A", "לא ניתנת לבדיקה - לא נבחר עמוד ויזואלי");
else if (!pdfPath) add("ג-10", "N/A", "לא ניתנת לבדיקה - לא נמסר PDF (דרגה 2 או 3)");
else if (pdfPages === null) add("ג-10", "N/A", "לא ניתנת לבדיקה - מספר העמודים לא נקבע מקובץ ה-PDF");
else {
  const expectedMin = (visualRendered ? 1 : 0) + ((wantTable || !visualRendered) ? 1 : 0);
  if (visualRendered && !wantTable) {
    if (pdfPages === 1) add("ג-10", "PASS", "עמוד ויזואלי בלבד = עמוד A4 לרוחב אחד בדיוק");
    else add("ג-10", "FAIL", `נבחר ויזואלי בלבד אך ב-PDF ${pdfPages} עמודים - העמוד הוויזואלי גלש`);
  } else if (pdfPages < expectedMin) {
    add("ג-10", "FAIL", `ב-PDF ${pdfPages} עמודים, מתחת לצפוי (${expectedMin} לפחות: ${visualRendered ? "ויזואלי 1 + " : ""}טבלה)`);
  } else {
    add("ג-10", "PASS", `${pdfPages} עמודים ב-PDF, לא פחות מהצפוי (${expectedMin}: ${visualRendered ? "ויזואלי 1 + " : ""}עמודי הטבלה)`);
  }
}
if (wantVisual && visualRendered)
  addManual("ג-10 (רכיב חזותי)", "אין מקטע, תווית או טקסט שנחתכו בעמוד הוויזואלי. **אינו ניתן לבדיקה מכנית** - חיתוך נקבע בפריסה בזמן ההדפסה.");

/* ---------- דוח ---------- */
let hasFail = false;
for (const r of results) {
  if (r.status === "FAIL") hasFail = true;
  console.log(`${r.id} ${r.status}: ${r.detail}`);
}
for (const m of manual) console.log(`${m.id} ידנית (לא נבדק כאן): ${m.detail}`);
const pass = results.filter(r => r.status === "PASS").length;
const failed = results.filter(r => r.status === "FAIL");
const notRun = results.filter(r => r.status === "N/A");
console.log(`---\nסיכום שער ג' (מכני): בוצעו ${pass}` +
  (failed.length ? ` · נכשלו ${failed.length}: ${failed.map(r => r.id).join(", ")}` : "") +
  (notRun.length ? ` · לא ניתנות לבדיקה כאן: ${notRun.map(r => r.id).join(", ")}` : "") +
  ` · דגימה ידנית: ${manual.map(m => m.id).join(", ") || "אין"}`);
process.exit(hasFail ? 1 : 0);
