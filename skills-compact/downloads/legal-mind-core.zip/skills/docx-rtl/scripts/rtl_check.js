#!/usr/bin/env node
// rtl_check.js - the RTL validation SPEC, implemented in Node (part of the docx-rtl skill).
//
// This is layer 1 of the skill's three-layer mechanical gate, in the second
// runtime: it performs exactly the seven-section spec written out under
// "## Validation policy" in SKILL.md, on the same files, with the same pass/fail
// rule. It exists so that tier B of the production ladder (node available,
// python not) is a MECHANICAL check and not a manual one.
//
// It is NOT the single binding implementation and it does not replace
// fix_rtl.py: fix_rtl.py both repairs and verifies, rtl_check.js only reads.
// A file that fails here is not delivered.
//
// Node standard library only - fs, zlib, path. Nothing is installed.
//
// Usage:  node scripts/rtl_check.js document.docx [--quiet]
// Exit:   0 all seven sections passed | 3 at least one failed | 64 usage

'use strict';
const fs = require('fs');
const zlib = require('zlib');

// ------------------------------------------------------------ ZIP reading
// A .docx is a ZIP. Reading it needs no dependency: locate the end-of-central-
// directory record, walk the central directory, inflate each stored entry.
function readZip(file) {
  const buf = fs.readFileSync(file);
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i >= buf.length - 66000; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('not a ZIP archive (no end-of-central-directory record): ' + file);
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const entries = new Map();
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) break;
    const method = buf.readUInt16LE(off + 10);
    const compSize = buf.readUInt32LE(off + 20);
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    const localOff = buf.readUInt32LE(off + 42);
    const name = buf.toString('utf8', off + 46, off + 46 + nameLen);
    if (buf.readUInt32LE(localOff) === 0x04034b50) {
      const lNameLen = buf.readUInt16LE(localOff + 26);
      const lExtraLen = buf.readUInt16LE(localOff + 28);
      const start = localOff + 30 + lNameLen + lExtraLen;
      const raw = buf.subarray(start, start + compSize);
      let data;
      if (method === 0) data = raw;
      else if (method === 8) data = zlib.inflateRawSync(raw);
      else throw new Error('unsupported ZIP compression method ' + method + ' for ' + name);
      entries.set(name, data.toString('utf8'));
    }
    off += 46 + nameLen + extraLen + commentLen;
  }
  return entries;
}

// ------------------------------------------------------------ normalization
// Per the spec: compare tag and attribute NAMES only, independent of the
// namespace-prefix abbreviation, and ignore whitespace between tags and inside
// a tag. Hebrew is recognised by codepoint range, never by a word list.
const HEB = /[֐-׿]/;
const RTL_ANY = /[֐-ࣿיִ-﷿ﹰ-﻿]/;

const normalize = xml => xml
  .replace(/\r\n/g, '\n')
  .replace(/>\s+</g, '><')          // whitespace between tags
  .replace(/\s*=\s*/g, '=')         // whitespace around attribute equals
  .replace(/\s+/g, ' ');            // collapse remaining runs of whitespace

// name-agnostic matchers: any prefix, or none
const tag = name => '<(?:[A-Za-z0-9_.-]+:)?' + name;
const has = (block, name) => new RegExp(tag(name) + '(?:\\s[^>]*)?/?>').test(block);
const attrEq = (block, el, attr, val) =>
  new RegExp(tag(el) + '[^>]*\\s(?:[A-Za-z0-9_.-]+:)?' + attr + '="' + val + '"').test(block);

// collect <name>...</name> blocks, depth-aware so nested tables are handled
function blocks(xml, name) {
  const open = new RegExp(tag(name) + '(?:\\s[^>]*)?(/)?>', 'g');
  const close = new RegExp('</(?:[A-Za-z0-9_.-]+:)?' + name + '>', 'g');
  const marks = [];
  let m;
  while ((m = open.exec(xml)) !== null) marks.push({ i: m.index, end: open.lastIndex, self: !!m[1], kind: 'o' });
  while ((m = close.exec(xml)) !== null) marks.push({ i: m.index, end: close.lastIndex, kind: 'c' });
  marks.sort((a, b) => a.i - b.i);
  const out = [];
  const stack = [];
  for (const mk of marks) {
    if (mk.kind === 'o') {
      if (mk.self) { out.push(xml.slice(mk.i, mk.end)); continue; }
      stack.push(mk.i);
    } else if (stack.length) {
      const start = stack.pop();
      if (!stack.length) out.push(xml.slice(start, mk.end));
    }
  }
  return out;
}

const textOf = block =>
  (block.match(new RegExp(tag('t') + '(?:\\s[^>]*)?>[\\s\\S]*?</(?:[A-Za-z0-9_.-]+:)?t>', 'g')) || [])
    .map(s => s.replace(/^<[^>]*>/, '').replace(/<[^>]*>$/, ''))
    .join('');

// The one documented exception to section 4: a clause citation (12(א), 3(2))
// is ONE physical LTR run and the single Hebrew sub-clause letter rides inside
// it - references/hebrew-legal-patterns.md, "Mixed-direction content". Such a
// run legitimately carries <w:rtl w:val="false"/>.
const CLAUSE_CITATION = /^[\s(]*\d+\((?:[א-ת]{1,2}|\d+)\)[\s).,;:]*$/;

// ------------------------------------------------------------ the seven sections
function check(file) {
  const zip = readZip(file);
  const names = [...zip.keys()];
  const partNames = names.filter(n =>
    n === 'word/document.xml' || n === 'word/styles.xml' || n === 'word/numbering.xml' ||
    /^word\/(header|footer)\d*\.xml$/.test(n));
  const parts = new Map(partNames.map(n => [n, normalize(zip.get(n))]));
  if (!parts.has('word/document.xml')) throw new Error('word/document.xml missing - not a .docx');

  const results = [];
  const add = (n, title, fails, note) =>
    results.push({ n, title, ok: fails.length === 0, fails, note: note || '' });

  // 1 - every <w:sectPr> carries <w:bidi/>
  let f = [];
  for (const [name, xml] of parts) {
    for (const s of blocks(xml, 'sectPr')) if (!has(s, 'bidi')) f.push(name + ': sectPr without <w:bidi/>');
  }
  add(1, 'bidi in every sectPr', f);

  // 2 - not one single jc w:val="right"
  f = [];
  for (const [name, xml] of parts) {
    const c = (xml.match(new RegExp(tag('jc') + '[^>]*val="right"', 'g')) || []).length;
    if (c) f.push(name + ': ' + c + ' x jc="right" (renders physical LEFT in Word)');
  }
  add(2, 'no jc="right" anywhere', f);

  // 3 - every paragraph holding Hebrew text carries <w:bidi/> in its <w:pPr>
  f = [];
  let hebParas = 0;
  for (const [name, xml] of parts) {
    if (name === 'word/styles.xml' || name === 'word/numbering.xml') continue;
    for (const p of blocks(xml, 'p')) {
      const t = textOf(p);
      if (!HEB.test(t)) continue;
      hebParas++;
      const pPr = blocks(p, 'pPr')[0] || '';
      if (!has(pPr, 'bidi')) f.push(name + ': paragraph without <w:bidi/> - "' + t.slice(0, 40) + '"');
    }
  }
  add(3, 'bidi in every Hebrew paragraph', f, hebParas + ' Hebrew paragraphs');

  // 4 - every run holding a Hebrew character carries <w:rtl/>
  f = [];
  let hebRuns = 0, exempt = 0;
  for (const [name, xml] of parts) {
    for (const r of blocks(xml, 'r')) {
      const t = textOf(r);
      if (!HEB.test(t)) continue;
      hebRuns++;
      if (has(r, 'rtl') && !attrEq(r, 'rtl', 'val', 'false')) continue;
      if (CLAUSE_CITATION.test(t)) { exempt++; continue; }
      f.push(name + ': run without <w:rtl/> - "' + t.slice(0, 40) + '"');
    }
  }
  add(4, 'rtl on every Hebrew run', f,
      hebRuns + ' Hebrew runs, ' + exempt + ' clause-citation exceptions');

  // 5 - every table carries <w:bidiVisual/> in its <w:tblPr>
  f = [];
  let tables = 0;
  for (const [name, xml] of parts) {
    for (const t of blocks(xml, 'tbl')) {
      tables++;
      const tblPr = blocks(t, 'tblPr')[0] || '';
      if (!has(tblPr, 'bidiVisual')) f.push(name + ': table without <w:bidiVisual/>');
    }
  }
  add(5, 'bidiVisual on every table', f, tables + ' tables');

  // 6 - numbering.xml has no right-side indent and no lvlJc right
  f = [];
  const num = parts.get('word/numbering.xml');
  if (num !== undefined) {
    if (new RegExp(tag('ind') + '[^>]*\\sw?:?right=').test(num)) f.push('numbering.xml: w:ind w:right= present');
    if (new RegExp(tag('lvlJc') + '[^>]*val="right"').test(num)) f.push('numbering.xml: lvlJc val="right" present');
  }
  add(6, 'numbering indents on the logical start side', f,
      num === undefined ? 'no numbering.xml in this document' : '');

  // 7 - page size is A4 portrait
  f = [];
  const doc = parts.get('word/document.xml');
  const pg = doc.match(new RegExp(tag('pgSz') + '[^>]*>', 'g')) || [];
  if (!pg.length) f.push('document.xml: no <w:pgSz>');
  for (const g of pg) {
    if (!/\sw?:?w="11906"/.test(g) || !/\sw?:?h="16838"/.test(g)) f.push('document.xml: page size is not A4 portrait - ' + g);
  }
  add(7, 'A4 portrait page size', f);

  return results;
}

// ------------------------------------------------------------ CLI
if (require.main === module) {
  const args = process.argv.slice(2).filter(a => a !== '--');
  if (args.includes('-h') || args.includes('--help')) {
    console.log('Usage: node rtl_check.js document.docx [--quiet]');
    console.log('Runs the seven-section RTL validation spec from SKILL.md (## Validation policy).');
    console.log('Read-only - it never modifies the file. Exit: 0 passed | 3 failed | 64 usage');
    process.exit(0);
  }
  const quiet = args.includes('--quiet');
  const file = args.find(a => !a.startsWith('-'));
  if (!file) { console.error('usage: node rtl_check.js document.docx  (see --help)'); process.exit(64); }
  if (!fs.existsSync(file)) { console.error('file not found: ' + file); process.exit(64); }

  let results;
  try { results = check(file); }
  catch (e) { console.error('rtl_check failed to read the document: ' + e.message); process.exit(3); }

  const bad = results.filter(r => !r.ok);
  for (const r of results) {
    if (quiet && r.ok) continue;
    console.log('[' + (r.ok ? 'PASS' : 'FAIL') + '] ' + r.n + '. ' + r.title + (r.note ? ' (' + r.note + ')' : ''));
    for (const line of r.fails.slice(0, 5)) console.log('        ' + line);
    if (r.fails.length > 5) console.log('        ... and ' + (r.fails.length - 5) + ' more');
  }
  console.log(bad.length
    ? 'RTL check FAILED - ' + bad.length + ' of 7 sections: ' + bad.map(r => r.n).join(', ')
    : 'RTL check passed - 7 of 7 sections');
  process.exit(bad.length ? 3 : 0);
}

module.exports = { check, readZip };
