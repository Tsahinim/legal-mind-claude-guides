#!/usr/bin/env python3
"""
qc_docx.py - the delivery QC gate for a Hebrew .docx (part of the docx-rtl skill).

READ-ONLY. It opens the .docx as a ZIP, reads the XML and prints a report.
It never writes, never repairs and never touches the file it is given.

Why it exists: fix_rtl.py repairs direction and rtl_check.js verifies the seven
direction sections, but the skill's own QC checklist
(references/hebrew-legal-patterns.md - "RTL quality-control checklist") also
forbids things no script enforced until now - en-dash, em-dash, maqaf, Latin
curly quotes inside Hebrew, literal bullet characters, markdown that leaked
into the document as plain text, and headings that carry no outline level.
Those are exactly the defects a lawyer sees and a direction check does not.

Checks - FAIL blocks delivery, WARN is reported only:

  A. inherited direction checks (same three the wrapper used to run inline)
     A1 FAIL  every <w:sectPr> carries <w:bidi/>
     A2 FAIL  no jc/lvlJc w:val="right" in document, headers, footers,
              styles.xml or numbering.xml (paragraph properties only)
     A3 FAIL  page size is A4 portrait (11906 x 16838)
  B. Hebrew typography (the house rule: the plain hyphen U+002D is the only
     horizontal line, in every character of the document)
     B1 FAIL  no en-dash U+2013, em-dash U+2014 or maqaf U+05BE in any
              <w:t>/<w:delText>
     B2 FAIL  no Latin curly quotes in a run that contains a Hebrew character
              (an English-only run keeps its typographic quotes)
     B3 FAIL  no literal bullet character in text - lists use real numbering
  C. structure
     C1 FAIL  no duplicate <w:style w:styleId="..."> in styles.xml
     C2 FAIL  every Heading style used in the document carries <w:outlineLvl>
              and <w:bidi/>
     C3 FAIL  no markdown left as literal text (a "#" heading, a "---" rule, or
              a numbered item with no <w:numPr>)
     C4 FAIL  a clause citation is not split across two runs of opposite
              direction ("12(" + "א)")
     C5 WARN  a footer with PAGE and NUMPAGES fields exists
     C6 WARN  no <w:jc> inside a <w:tblPr> (table alignment, reported not fixed)

Python standard library only. Nothing is installed.

Usage:  python qc_docx.py document.docx [--quiet]
Exit:   0 no FAIL | 3 at least one FAIL | 64 usage
"""
import re
import sys
import zipfile

# ---------------------------------------------------------------- parts

BODY_RE = re.compile(r'^word/(document|header\d*|footer\d*|footnotes|endnotes|comments)\.xml$')
HEB = re.compile('[֐-׿]')

# lint exemption: the three tables below MUST contain the forbidden characters
# themselves - that is what makes them detectable. These are literal examples,
# not house-rule violations.
FORBIDDEN_DASHES = {
    '–': 'en-dash U+2013',
    '—': 'em-dash U+2014',
    '־': 'maqaf U+05BE',
}
CURLY_QUOTES = {
    '‘': 'U+2018', '’': 'U+2019',
    '“': 'U+201C', '”': 'U+201D',
}
LITERAL_BULLETS = {
    '•': 'U+2022', '●': 'U+25CF', '▪': 'U+25AA',
    '◦': 'U+25E6', '·': 'U+00B7',
}

# the two numbered-item shapes md_to_docx.js converts to real Word numbering -
# kept character-identical so a BODY paragraph that matches here and carries no
# <w:numPr> is leaked markdown by construction, never a false positive on a
# date (15.7.2026) or a bare year at the start of a line. Heading paragraphs are
# excluded separately - see HEADING_STYLE_RE below.
NUMBERED_MD = (
    re.compile(r'^\s*\d{1,2}(?:\.\d{1,2}){1,2}[.)]?\s+\S'),
    re.compile(r'^\s*\d+[.)]\s+\S'),
)
HEADING_MD = re.compile(r'^\s*#{1,6}\s+\S')
RULE_MD = re.compile(r'^\s*(-{3,}|\*{3,}|_{3,})\s*$')
# a Word HEADING that opens with a number ("## 2. התמורה" -> Heading2 "2. התמורה")
# is not leaked markdown: md_to_docx.js renders every "#" heading through
# HeadingLevel and never gives a heading a <w:numPr>, so the numbered-item branch
# below would fail EVERY numbered Hebrew agreement - the house's default shape -
# and block delivery at exit 3. Headings are exempt from that branch only; a
# literal "## ..." string still fails through HEADING_MD above.
HEADING_STYLE_RE = re.compile(r'<w:pStyle w:val="(?:Heading|Title|Subtitle)')


def unescape(text: str) -> str:
    """XML text -> characters. Numeric refs matter here: unpack.py rewrites
    curly quotes as &#x201C; and they must still be caught."""
    text = re.sub(r'&#x([0-9A-Fa-f]+);', lambda m: chr(int(m.group(1), 16)), text)
    text = re.sub(r'&#(\d+);', lambda m: chr(int(m.group(1))), text)
    for ent, ch in (('&lt;', '<'), ('&gt;', '>'), ('&quot;', '"'),
                    ('&apos;', "'"), ('&amp;', '&')):
        text = text.replace(ent, ch)
    return text


def blocks(xml: str, name: str) -> list:
    """All <w:name>...</w:name> blocks, outermost only (depth-aware)."""
    out, stack = [], []
    pattern = re.compile(r'<w:%s(?:\s[^>]*)?(/?)>|</w:%s>' % (name, name))
    for m in pattern.finditer(xml):
        if m.group(0).startswith('</'):
            if stack:
                start = stack.pop()
                if not stack:
                    out.append(xml[start:m.end()])
        elif m.group(1):
            if not stack:
                out.append(m.group(0))
        else:
            stack.append(m.start())
    return out


def text_of(block: str) -> str:
    parts = re.findall(r'<w:(?:t|delText)(?:\s[^>]*)?>(.*?)</w:(?:t|delText)>',
                       block, flags=re.S)
    return unescape(''.join(parts))


def runs_of(paragraph: str) -> list:
    return blocks(paragraph, 'r')


def run_is_ltr(run: str) -> bool:
    return bool(re.search(r'<w:rtl\s+w:val="(?:false|0)"\s*/>', run))


def run_is_rtl(run: str) -> bool:
    return bool(re.search(r'<w:rtl\s*/>', run)) or \
        bool(re.search(r'<w:rtl\s+w:val="(?:true|1)"\s*/>', run))


# ---------------------------------------------------------------- the gate

class Report:
    def __init__(self):
        self.items = []

    def add(self, code, severity, title, fails, note=''):
        self.items.append({'code': code, 'sev': severity, 'title': title,
                           'fails': fails, 'note': note})

    @property
    def failed(self):
        return [i for i in self.items if i['sev'] == 'FAIL' and i['fails']]

    @property
    def warned(self):
        return [i for i in self.items if i['sev'] == 'WARN' and i['fails']]


def qc(path: str) -> Report:
    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()
        parts = {n: zf.read(n).decode('utf-8', 'replace')
                 for n in names if BODY_RE.match(n) or
                 n in ('word/styles.xml', 'word/numbering.xml')}
    if 'word/document.xml' not in parts:
        raise ValueError('word/document.xml missing - not a .docx')

    body = {n: x for n, x in parts.items() if BODY_RE.match(n)}
    styles = parts.get('word/styles.xml', '')
    numbering = parts.get('word/numbering.xml', '')
    document = parts['word/document.xml']
    r = Report()

    # --- A1 sectPr bidi
    f = []
    for n, x in body.items():
        for s in blocks(x, 'sectPr'):
            if '<w:bidi/>' not in s and '<w:bidi ' not in s:
                f.append('%s: sectPr without <w:bidi/>' % n)
    r.add('A1', 'FAIL', 'bidi in every sectPr', f)

    # --- A2 jc / lvlJc right
    f = []
    for n, x in list(body.items()) + [('word/styles.xml', styles),
                                      ('word/numbering.xml', numbering)]:
        if not x:
            continue
        for tag in ('jc', 'lvlJc'):
            hits = re.findall(r'<w:%s\s+w:val="right"\s*/>' % tag, x)
            if hits:
                f.append('%s: %d x <w:%s w:val="right"/> (renders physical LEFT in Word)'
                         % (n, len(hits), tag))
    r.add('A2', 'FAIL', 'no jc/lvlJc right-alignment', f)

    # --- A3 A4
    f = []
    pg = re.findall(r'<w:pgSz[^>]*>', document)
    if not pg:
        f.append('document.xml: no <w:pgSz>')
    for g in pg:
        if 'w:w="11906"' not in g or 'w:h="16838"' not in g:
            f.append('document.xml: page size is not A4 portrait - ' + g)
    r.add('A3', 'FAIL', 'A4 portrait page size', f)

    # --- B1 forbidden dashes, B2 curly quotes in Hebrew runs, B3 literal bullets
    f_dash, f_quote, f_bullet = [], [], []
    for n, x in body.items():
        for run in blocks(x, 'r'):
            t = text_of(run)
            if not t:
                continue
            for ch, label in FORBIDDEN_DASHES.items():
                if ch in t:
                    f_dash.append('%s: %s in "%s"' % (n, label, t.strip()[:40]))
            if HEB.search(t):
                for ch, label in CURLY_QUOTES.items():
                    if ch in t:
                        f_quote.append('%s: Latin curly quote %s inside a Hebrew run - "%s"'
                                       % (n, label, t.strip()[:40]))
            for ch, label in LITERAL_BULLETS.items():
                if ch in t:
                    f_bullet.append('%s: literal bullet %s in text - "%s"'
                                    % (n, label, t.strip()[:40]))
    r.add('B1', 'FAIL', 'the plain hyphen is the only horizontal line', f_dash)
    r.add('B2', 'FAIL', 'no Latin curly quotes inside Hebrew runs', f_quote)
    r.add('B3', 'FAIL', 'no literal bullet characters', f_bullet)

    # --- C1 duplicate styleId
    f = []
    seen = {}
    for sid in re.findall(r'<w:style\s[^>]*w:styleId="([^"]+)"', styles):
        seen[sid] = seen.get(sid, 0) + 1
    for sid, count in seen.items():
        if count > 1:
            f.append('styles.xml: w:styleId="%s" defined %d times - Word picks one '
                     'undefined-ly, and outlineLvl (navigation pane, TOC) is the '
                     'first casualty' % (sid, count))
    r.add('C1', 'FAIL', 'every w:styleId defined once', f, '%d styles' % len(seen))

    # --- C2 heading styles used in the document carry outlineLvl + bidi
    f = []
    used = sorted(set(re.findall(r'<w:pStyle\s+w:val="(Heading\d)"\s*/>', document)))
    for sid in used:
        m = re.search(r'<w:style\s[^>]*w:styleId="%s".*?</w:style>' % sid, styles, re.S)
        if not m:
            f.append('styles.xml: %s is used in the document but not defined' % sid)
            continue
        block = m.group(0)
        if '<w:outlineLvl ' not in block:
            f.append('styles.xml: %s has no <w:outlineLvl> - it will not appear in the '
                     'navigation pane or the table of contents' % sid)
        if '<w:bidi/>' not in block and '<w:bidi ' not in block:
            f.append('styles.xml: %s has no <w:bidi/>' % sid)
    r.add('C2', 'FAIL', 'heading styles carry outlineLvl and bidi', f,
          ', '.join(used) if used else 'no heading styles used')

    # --- C3 markdown leaked as literal text
    f = []
    for n, x in body.items():
        for p in blocks(x, 'p'):
            t = text_of(p)
            if not t.strip():
                continue
            if HEADING_MD.match(t):
                f.append('%s: markdown heading written as text - "%s"' % (n, t.strip()[:40]))
            elif RULE_MD.match(t):
                f.append('%s: markdown horizontal rule written as text - "%s"' % (n, t.strip()[:40]))
            elif ('<w:numPr>' not in p and not HEADING_STYLE_RE.search(p)
                    and any(rx.match(t) for rx in NUMBERED_MD)):
                f.append('%s: numbered item written as text instead of Word numbering - "%s"'
                         % (n, t.strip()[:40]))
    r.add('C3', 'FAIL', 'no markdown left as literal text', f)

    # --- C4 clause citation split across two runs of opposite direction
    f = []
    for n, x in body.items():
        for p in blocks(x, 'p'):
            rs = runs_of(p)
            for i in range(len(rs) - 1):
                a, b = text_of(rs[i]), text_of(rs[i + 1])
                if not a or not b:
                    continue
                opposite = (run_is_ltr(rs[i]) and run_is_rtl(rs[i + 1])) or \
                           (run_is_rtl(rs[i]) and run_is_ltr(rs[i + 1]))
                if not opposite:
                    continue
                if a.rstrip().endswith('(') or b.lstrip().startswith(')'):
                    f.append('%s: clause citation split across two runs - "%s" + "%s"'
                             % (n, a[-12:], b[:12]))
    r.add('C4', 'FAIL', 'clause citations stay in one run', f)

    # --- C5 footer with PAGE + NUMPAGES  (WARN)
    f = []
    footer_text = ' '.join(x for n, x in body.items() if re.match(r'^word/footer', n))
    if not footer_text:
        f.append('no word/footer*.xml - the document has no page numbers')
    else:
        if 'PAGE' not in footer_text:
            f.append('footer has no PAGE field')
        if 'NUMPAGES' not in footer_text:
            f.append('footer has no NUMPAGES field')
    r.add('C5', 'WARN', 'footer carries "עמוד X מתוך Y"', f)

    # --- C6 jc inside tblPr  (WARN - reported, never repaired)
    f = []
    for n, x in body.items():
        for tp in blocks(x, 'tblPr'):
            m = re.search(r'<w:jc\s+w:val="([^"]+)"', tp)
            if m:
                f.append('%s: <w:jc w:val="%s"/> inside <w:tblPr> - table alignment, '
                         'check it by eye in Word' % (n, m.group(1)))
    r.add('C6', 'WARN', 'no table-level jc left unreviewed', f)

    return r


# ---------------------------------------------------------------- CLI

def main(argv):
    # findings quote Hebrew text from the document; a Windows console in a
    # legacy codepage must not turn a QC report into a UnicodeEncodeError
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass

    args = [a for a in argv[1:] if a != '--']
    if '-h' in args or '--help' in args:
        print('Usage: python qc_docx.py document.docx [--quiet]')
        print('Read-only delivery QC gate. Exit: 0 no FAIL | 3 a FAIL | 64 usage')
        return 0
    quiet = '--quiet' in args
    files = [a for a in args if not a.startswith('-')]
    if len(files) != 1:
        print('usage: python qc_docx.py document.docx  (see --help)', file=sys.stderr)
        return 64

    try:
        report = qc(files[0])
    except FileNotFoundError:
        print('file not found: ' + files[0], file=sys.stderr)
        return 64
    except Exception as e:
        print('qc_docx failed to read the document: %s' % e, file=sys.stderr)
        return 3

    for item in report.items:
        ok = not item['fails']
        if quiet and ok:
            continue
        label = 'PASS' if ok else item['sev']
        note = ' (%s)' % item['note'] if item['note'] else ''
        print('[%s] %s. %s%s' % (label, item['code'], item['title'], note))
        for line in item['fails'][:5]:
            print('        ' + line)
        if len(item['fails']) > 5:
            print('        ... and %d more' % (len(item['fails']) - 5))

    bad = report.failed
    warn = report.warned
    if bad:
        print('QC FAILED - %d check(s): %s' % (len(bad), ', '.join(i['code'] for i in bad)))
        return 3
    print('QC passed - %d checks%s' % (
        len(report.items),
        ' (%d warning(s): %s)' % (len(warn), ', '.join(i['code'] for i in warn)) if warn else ''))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
