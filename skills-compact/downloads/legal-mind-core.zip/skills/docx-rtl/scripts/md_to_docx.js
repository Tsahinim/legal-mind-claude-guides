const fs = require('fs');

// docx may be installed globally (npm install -g docx); node does not search the
// global root from this script's directory, so fall back to it explicitly.
function loadDocx() {
  try { return require('docx'); } catch (e) {
    const globalRoot = require('child_process').execSync('npm root -g').toString().trim();
    return require(require('path').join(globalRoot, 'docx'));
  }
}
const {
  Document, Packer, Paragraph, TextRun, ExternalHyperlink,
  AlignmentType, HeadingLevel, LevelFormat, BorderStyle,
  Table, TableRow, TableCell, WidthType, ShadingType,
  Footer, PageNumber
} = loadDocx();

const SRC = process.argv[2];
const OUT = process.argv[3];
const md = fs.readFileSync(SRC, 'utf8').replace(/\r\n/g, '\n');
const lines = md.split('\n');

const FONT = 'David';
const BODY = 22; // 11pt

// Any RTL-script codepoint (Hebrew, Arabic + presentation forms).
// MUST stay identical to RTL_CHARS in scripts/fix_rtl.py - a character this
// function misses lands in an LTR run carrying <w:rtl w:val="false"/>, and
// fix_rtl.py deliberately preserves that marker instead of repairing it.
const isRtlChar = c =>
  (c >= 0x0590 && c <= 0x08ff) ||
  (c >= 0xfb1d && c <= 0xfdff) ||
  (c >= 0xfe70 && c <= 0xfeff);

// Atomic patterns that must never be split across two runs.
// - clause citations 12(א) / 3(2): one LTR run, the sub-clause letter rides inside it
//   (references/hebrew-legal-patterns.md - Mixed-direction content)
// - law-year citations התשכ"ט-1969: one RTL run, the year is NOT split off
//   (references/caller-entry.md rule 3)
const ATOMIC = [
  { re: /\d+\([א-ת]{1,2}\)/y, ltr: true },
  { re: /\d+\(\d+\)/y, ltr: true },
  { re: /[א-ת]+[״׳"']?[א-ת]?-\d{4}/y, ltr: false },
];

// classify a plain (no markdown) string into RTL/LTR runs
function classifyRuns(str) {
  const runs = [];
  let cur = null;
  const push = (text, want) => {
    if (cur && cur.ltr === want) cur.text += text;
    else { if (cur) runs.push(cur); cur = { text, ltr: want }; }
  };
  const isLtr = c => (c >= 0x30 && c <= 0x39) || (c >= 0x41 && c <= 0x5A) || (c >= 0x61 && c <= 0x7A);
  const chars = Array.from(str);
  // index in code units, so the sticky regexes line up with the source string
  let i = 0;
  for (let k = 0; k < chars.length; ) {
    let matched = null;
    for (const a of ATOMIC) {
      a.re.lastIndex = i;
      const m = a.re.exec(str);
      if (m) { matched = { text: m[0], ltr: a.ltr }; break; }
    }
    if (matched) {
      push(matched.text, matched.ltr);
      i += matched.text.length;
      k += Array.from(matched.text).length;
      continue;
    }
    const ch = chars[k];
    const code = ch.codePointAt(0);
    let want = null;
    if (isRtlChar(code)) want = false;  // rtl
    else if (isLtr(code)) want = true;  // ltr
    if (want === null) { // neutral
      if (cur) cur.text += ch; else cur = { text: ch, ltr: false };
    } else {
      push(ch, want);
    }
    i += ch.length;
    k += 1;
  }
  if (cur) runs.push(cur);
  return runs;
}

// build TextRun[] for a plain segment with given styling
function makeRuns(text, { bold = false, link = false, size = BODY, color = null } = {}) {
  return classifyRuns(text).map(r => new TextRun({
    text: r.text,
    font: FONT,
    size,
    bold,
    ...(color ? { color } : {}),
    rightToLeft: !r.ltr,
    ...(link ? { style: 'Hyperlink' } : {})
  }));
}

// split a segment by **bold** and produce runs
function styleRuns(text, { link = false, size = BODY, bold: baseBold = false, color = null } = {}) {
  const parts = text.split(/\*\*/);
  let bold = baseBold;
  const out = [];
  for (const p of parts) {
    if (p) out.push(...makeRuns(p, { bold, link, size, color }));
    bold = !bold;
  }
  return out;
}

// parse a line's inline markdown (links + bold) into TextRun/ExternalHyperlink[]
function parseInline(line, opts = {}) {
  const out = [];
  const re = /\[([^\]]+)\]\(([^)]+)\)/g;
  let last = 0, m;
  while ((m = re.exec(line)) !== null) {
    if (m.index > last) out.push(...styleRuns(line.slice(last, m.index), opts));
    out.push(new ExternalHyperlink({ link: m[2], children: styleRuns(m[1], { ...opts, link: true }) }));
    last = re.lastIndex;
  }
  if (last < line.length) out.push(...styleRuns(line.slice(last), opts));
  return out;
}

const children = [];
const P = (opts) => children.push(new Paragraph(opts));

// --- Markdown tables → real w:tbl with bidiVisual ---
const isTableLine = l => /^\s*\|.*\|\s*$/.test(l);
const isSepLine = l => /^\s*\|(\s*:?-+:?\s*\|)+\s*$/.test(l);

function parseTableRow(line) {
  let s = line.trim();
  if (s.startsWith('|')) s = s.slice(1);
  if (s.endsWith('|')) s = s.slice(0, -1);
  return s.split(/(?<!\\)\|/).map(c => c.trim().replace(/\\\|/g, '|'));
}

function buildTable(headerCells, bodyRows) {
  const TABLE_W = 9026; // A4 content width (references/docx-js-widgets.md)
  const cols = headerCells.length;
  const colW = Math.floor(TABLE_W / cols);
  const widths = Array(cols).fill(colW);
  widths[cols - 1] += TABLE_W - colW * cols; // sum of columnWidths must equal table width
  const border = { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' };
  const borders = { top: border, bottom: border, left: border, right: border };
  const cell = (text, i, header) => new TableCell({
    borders,
    width: { size: widths[i], type: WidthType.DXA }, // dual widths: cell AND columnWidths
    ...(header ? { shading: { fill: 'D5E8F0', type: ShadingType.CLEAR } } : {}),
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    children: [new Paragraph({
      bidirectional: true, spacing: { after: 0 },
      children: header ? makeRuns(text.replace(/\*\*/g, ''), { bold: true }) : parseInline(text)
    })]
  });
  const row = (cells, header) => new TableRow({
    ...(header ? { tableHeader: true } : {}),
    children: headerCells.map((_, i) => cell(cells[i] || '', i, header))
  });
  return new Table({
    visuallyRightToLeft: true,
    width: { size: TABLE_W, type: WidthType.DXA },
    columnWidths: widths,
    rows: [row(headerCells, true), ...bodyRows.map(r => row(r, false))]
  });
}

// מספור אוטומטי אמיתי: reference נפרד לכל בלוק (מתאפס בכל כותרת)
let listRef = 0;

for (let i = 0; i < lines.length; i++) {
  const raw = lines[i];
  const line = raw.replace(/\s+$/,'');
  if (!line.trim()) { continue; }

  // MD table block: header row + |---| separator + body rows
  if (isTableLine(line) && i + 1 < lines.length && isSepLine(lines[i + 1])) {
    const header = parseTableRow(line);
    const body = [];
    let j = i + 2;
    while (j < lines.length && isTableLine(lines[j]) && !isSepLine(lines[j])) {
      body.push(parseTableRow(lines[j])); j++;
    }
    children.push(buildTable(header, body));
    P({ bidirectional: true, spacing: { after: 80 }, children: [] }); // gap so consecutive tables don't merge
    i = j - 1;
    continue;
  }

  let m;

  // Horizontal rule (---, ***, ___) - a real bottom border, NEVER literal text
  if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(line)) {
    P({ bidirectional: true, spacing: { before: 120, after: 120 },
        border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: 'BFBFBF', space: 1 } },
        children: [] });
    continue;
  }

  if ((m = line.match(/^#\s+(.*)/))) {
    listRef++;
    P({ heading: HeadingLevel.HEADING_1, bidirectional: true, spacing: { after: 200 },
        children: parseInline(m[1], { size: 34, bold: true }) });
    continue;
  }
  if ((m = line.match(/^##\s+(.*)/))) {
    listRef++;
    P({ heading: HeadingLevel.HEADING_2, bidirectional: true, spacing: { before: 280, after: 140 },
        border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: '2E75B6', space: 2 } },
        children: parseInline(m[1], { size: 28, bold: true }) });
    continue;
  }
  if ((m = line.match(/^###\s+(.*)/))) {
    listRef++;
    P({ heading: HeadingLevel.HEADING_3, bidirectional: true, spacing: { before: 180, after: 90 },
        children: parseInline(m[1], { size: 26, bold: true, color: '1F4E79' }) });
    continue;
  }
  if ((m = line.match(/^####\s+(.*)/))) {
    listRef++;
    P({ heading: HeadingLevel.HEADING_4, bidirectional: true, spacing: { before: 140, after: 70 },
        children: parseInline(m[1], { size: 24, bold: true, color: '2E75B6' }) });
    continue;
  }

  // Blockquote
  if ((m = line.match(/^>\s?(.*)/))) {
    P({ bidirectional: true, alignment: AlignmentType.JUSTIFIED, spacing: { before: 120, after: 120, line: 340, lineRule: 'auto' },
        indent: { left: 360 },
        border: { left: { style: BorderStyle.SINGLE, size: 12, color: '999999', space: 8 } },
        children: parseInline(m[1]) });
    continue;
  }

  // Bullet source line - indentation of 2+ spaces = one nesting level down
  if ((m = line.match(/^(\s*)[-*]\s+(.*)/))) {
    const lvl = Math.min(1, Math.floor(m[1].replace(/\t/g, '  ').length / 2));
    P({ bidirectional: true, alignment: AlignmentType.JUSTIFIED, spacing: { after: 60, line: 320, lineRule: 'auto' },
        numbering: { reference: 'src', level: lvl },
        children: parseInline(m[2]) });
    continue;
  }

  // Numbered point - REAL Word automatic numbering, restarts each block (new listRef per heading).
  // Accepts 1. / 1) / 1.1 / 1.1.1 and indented items; decimal depth and indentation
  // both map onto numbering levels 0-2. A number is NEVER written as literal text.
  // A bare number followed by a space (a year, an amount) is NOT a list item: a
  // single-level number must carry its "." or ")" delimiter to qualify, and a
  // decimal number qualifies only in clause shape - up to 3 segments of 1-2
  // digits each, so a date at the start of a line (15.7.2026) stays a paragraph.
  if ((m = line.match(/^(\s*)(\d{1,2}(?:\.\d{1,2}){1,2})[.)]?\s+(.*)/)) ||
      (m = line.match(/^(\s*)(\d+)[.)]\s+(.*)/))) {
    const indent = m[1].replace(/\t/g, '  ').length;
    const dots = m[2].split('.').length - 1;
    const lvl = Math.min(2, dots || Math.floor(indent / 2));
    P({ bidirectional: true, alignment: AlignmentType.JUSTIFIED, spacing: { before: 100, after: 60, line: 340, lineRule: 'auto' },
        numbering: { reference: 'pts' + listRef, level: lvl }, children: parseInline(m[3]) });
    continue;
  }

  // Normal paragraph
  P({ bidirectional: true, alignment: AlignmentType.JUSTIFIED, spacing: { after: 80, line: 340, lineRule: 'auto' },
      children: parseInline(line) });
}

// תצורות מספור: תבליט למקורות (שתי רמות) + reference עשרוני רב-רמתי נפרד לכל בלוק (איפוס אמיתי).
// כלל קריטי: צד ההזחה הוא תמיד left - בפסקה דו-כיוונית left הוא ההתחלה הלוגית, כלומר ימין פיזי.
const bulletLevel = (level, text, left) => ({
  level, format: LevelFormat.BULLET, text, alignment: AlignmentType.LEFT,
  style: { paragraph: { indent: { left, hanging: 300 }, bidirectional: true }, run: { rightToLeft: true } },
});
const decimalLevel = (level, text, left) => ({
  level, format: LevelFormat.DECIMAL, text, alignment: AlignmentType.LEFT,
  style: { paragraph: { indent: { left, hanging: 360 }, bidirectional: true }, run: { rightToLeft: true } },
});
const numConfig = [
  { reference: 'src', levels: [bulletLevel(0, '•', 900), bulletLevel(1, 'o', 1260)] },
];
for (let i = 0; i <= listRef; i++) {
  numConfig.push({ reference: 'pts' + i, levels: [
    decimalLevel(0, '%1.', 720),
    decimalLevel(1, '%1.%2.', 1140),
    decimalLevel(2, '%1.%2.%3.', 1620),
  ] });
}

// Heading1-Heading4 are BUILT-IN docx-js styles: the library always emits them
// into styles.xml. Re-declaring the same ids under `paragraphStyles` does not
// replace them - it appends a SECOND <w:style w:styleId="Heading1"> to the same
// file, and which of the two Word honours is undefined. The visible casualty is
// w:outlineLvl (navigation pane + table of contents), because the stock style
// carries none. The supported way to restyle a built-in heading is the
// styles.default.headingN slot below; `paragraphStyles` stays reserved for ids
// the library does not already define.
const headingStyle = (size, before, after, outlineLevel) => ({
  run: { size, bold: true, font: FONT, rightToLeft: true },
  paragraph: { spacing: { before, after }, bidirectional: true, outlineLevel },
});

const doc = new Document({
  styles: {
    default: {
      document: { run: { font: FONT, size: BODY, rightToLeft: true }, paragraph: { bidirectional: true } },
      heading1: headingStyle(34, 240, 160, 0),
      heading2: headingStyle(28, 260, 130, 1),
      heading3: headingStyle(26, 180, 90, 2),
      heading4: headingStyle(24, 140, 70, 3),
    },
  },
  numbering: { config: numConfig },
  sections: [{
    properties: { bidi: true, page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
    // כותרת תחתונה "עמוד X מתוך Y" - שדות המספר הם ספרות ולכן rightToLeft: false
    // (references/hebrew-legal-patterns.md - Hebrew page furniture)
    footers: { default: new Footer({ children: [
      new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, children: [
        new TextRun({ text: 'עמוד ', font: FONT, size: 20, rightToLeft: true }),
        new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 20, rightToLeft: false }),
        new TextRun({ text: ' מתוך ', font: FONT, size: 20, rightToLeft: true }),
        new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FONT, size: 20, rightToLeft: false }),
      ]}),
    ]}) },
    children
  }]
});

Packer.toBuffer(doc).then(b => { fs.writeFileSync(OUT, b); console.log('written', OUT, b.length, 'bytes'); });
