#!/usr/bin/env python3
"""
fix_rtl.py - Make a .docx fully, correctly RTL for Microsoft Word.

Fixes, in place and idempotently:
  1. Strips <w:jc w:val="right"/> from bidi paragraphs (Word reads it as
     logical END = physical LEFT; a bidi paragraph with no jc is start-aligned
     = physical RIGHT). jc="center" is kept (direction-neutral).
  2. Injects <w:bidi/> into <w:sectPr> (docx-js silently drops `bidi: true`).
  3. Adds <w:bidi/> to any paragraph missing it (correct pPr schema position).
  4. Adds <w:rtl/> to any run whose text contains RTL script (Hebrew/Arabic)
     and lacks an rtl marker (adds <w:rPr> when absent). Runs carrying
     <w:rtl w:val="false"/> (docx-js rightToLeft:false) and pure-Latin/digit
     runs are left untouched - adding <w:rtl/> there reorders boundary
     neutrals (the "numbers jumped around" bug).
  5. Adds <w:bidiVisual/> to any table missing it (after tblStyle/tblpPr/
     tblOverlap, before <w:tblW> - its schema slot).
  6. numbering.xml: w:ind w:right= -> w:left= ; lvlJc right -> left.
     (In bidi paragraphs w:left = logical start = physical right.)
  7. styles.xml: strips jc="right" from defaults/styles, ensures <w:rtl/> +
     <w:lang w:bidi="he-IL"/> in rPrDefault and <w:bidi/> in pPrDefault.

Usage:
  python fix_rtl.py in.docx -o out.docx      # write to a NEW file - always do this
                                             # for a file the lawyer handed over
  python fix_rtl.py document.docx --dry-run  # report the change count, write nothing
  python fix_rtl.py document.docx            # fix in place (build path only, on a
                                             # file this skill just generated)
  python fix_rtl.py document.docx --lang ar-SA

A file the lawyer supplied is NEVER repaired in place: copy it first, or pass -o.
"""
import argparse
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

# ---------------------------------------------------------------- helpers

# Any RTL-script codepoint (Hebrew, Arabic + presentation forms)
RTL_CHARS = re.compile('[֐-ࣿיִ-﷿ﹰ-﻿]')

# rPr children that must FOLLOW <w:rtl/> (EG_RPrBase is an ordered sequence:
# ... vertAlign, rtl, cs, em, lang, eastAsianLayout, specVanish, oMath)
_RPR_AFTER_RTL = ('<w:cs/', '<w:cs ', '<w:em ', '<w:em/', '<w:lang ', '<w:lang/',
                  '<w:eastAsianLayout', '<w:specVanish', '<w:oMath')


def _insert_rtl_in_rpr(rpr_block: str) -> str:
    """Insert <w:rtl/> at its correct schema slot inside <w:rPr>...</w:rPr>."""
    indices = [i for i in (rpr_block.find(a) for a in _RPR_AFTER_RTL) if i != -1]
    idx = min(indices) if indices else rpr_block.find('</w:rPr>')
    return rpr_block[:idx] + '<w:rtl/>' + rpr_block[idx:]


def strip_jc_right(xml: str) -> str:
    """Remove jc=right (kept: center/both/end/etc.). Handles condensed + pretty XML."""
    return re.sub(r'<w:jc\s+w:val="right"\s*/>\s*', '', xml)


def ensure_paragraph_bidi(xml: str) -> str:
    """Add <w:bidi/> to every pPr that lacks it, respecting pPr child order.
    Also wrap paragraphs that have no pPr at all."""

    def fix_ppr(m):
        block = m.group(0)
        if '<w:bidi/>' in block or '<w:bidi ' in block:
            return block
        # insert before the first of: spacing / ind / jc / rPr / end
        for anchor in ('<w:spacing', '<w:ind ', '<w:ind/', '<w:jc ', '<w:rPr>', '</w:pPr>'):
            idx = block.find(anchor)
            if idx != -1:
                return block[:idx] + '<w:bidi/>' + block[idx:]
        return block

    xml = re.sub(r'<w:pPr>.*?</w:pPr>', fix_ppr, xml, flags=re.S)
    # paragraphs with no pPr: <w:p> or <w:p attrs...> directly followed by content
    # (the lookbehind skips self-closing <w:p .../>; the tag pattern cannot match
    # <w:pPr>/<w:pict>/<w:proofErr> because those have a non-space char after "<w:p")
    xml = re.sub(r'(<w:p(?:\s[^>]*)?>)(?<!/>)(?!\s*<w:pPr)',
                 r'\1<w:pPr><w:bidi/></w:pPr>', xml)
    return xml


def ensure_run_rtl(xml: str) -> str:
    """Add <w:rtl/> (at its schema slot) to runs containing RTL-script text.
    Skips runs already carrying any <w:rtl> marker - including
    <w:rtl w:val="false"/>, which docx-js emits for rightToLeft:false (ltr())
    runs - and skips pure-Latin/digit runs entirely: forcing RTL on those
    reorders boundary neutrals (the "numbers jumped around" bug)."""

    def fix_run(m):
        block = m.group(0)
        if '<w:rtl/>' in block or '<w:rtl ' in block:
            return block
        text = ''.join(re.findall(
            r'<w:(?:t|delText)(?:\s[^>]*)?>(.*?)</w:(?:t|delText)>', block, flags=re.S))
        if not RTL_CHARS.search(text):
            return block
        if '<w:rPr/>' in block:
            block = block.replace('<w:rPr/>', '<w:rPr></w:rPr>', 1)
        if '<w:rPr>' in block:
            start = block.find('<w:rPr>')
            end = block.find('</w:rPr>', start) + len('</w:rPr>')
            return block[:start] + _insert_rtl_in_rpr(block[start:end]) + block[end:]
        # no rPr - add one right after <w:r> (or <w:r ...>)
        return re.sub(r'(<w:r(?:\s[^>]*)?>)', r'\1<w:rPr><w:rtl/></w:rPr>', block, count=1)

    return re.sub(r'<w:r(?:\s[^>]*)?>.*?</w:r>', fix_run, xml, flags=re.S)


# tblPr children that must FOLLOW <w:bidiVisual/> (CT_TblPr sequence:
# tblStyle, tblpPr, tblOverlap, bidiVisual, tblStyleRowBandSize, ..., tblW, jc, ...)
_TBLPR_AFTER_BIDI = ('<w:tblStyleRowBandSize', '<w:tblStyleColBandSize', '<w:tblW',
                     '<w:jc', '<w:tblCellSpacing', '<w:tblInd', '<w:tblBorders',
                     '<w:shd', '<w:tblLayout', '<w:tblCellMar', '<w:tblLook')


def ensure_table_bidivisual(xml: str) -> str:
    """Add <w:bidiVisual/> to every tblPr that lacks it, at its schema slot
    (after tblStyle/tblpPr/tblOverlap, before tblStyleRowBandSize/tblW/...)."""

    def fix_tblpr(m):
        block = m.group(0)
        if '<w:bidiVisual' in block:
            return block
        indices = [i for i in (block.find(a) for a in _TBLPR_AFTER_BIDI) if i != -1]
        idx = min(indices) if indices else block.find('</w:tblPr>')
        return block[:idx] + '<w:bidiVisual/>' + block[idx:]

    xml = xml.replace('<w:tblPr/>', '<w:tblPr><w:bidiVisual/></w:tblPr>')
    xml = re.sub(r'<w:tblPr>.*?</w:tblPr>', fix_tblpr, xml, flags=re.S)
    # tables with no tblPr at all: tblPr is the (optional) first child of w:tbl
    xml = re.sub(r'(<w:tbl>)(?!\s*<w:tblPr)', r'\1<w:tblPr><w:bidiVisual/></w:tblPr>', xml)
    return xml


def ensure_sectpr_bidi(xml: str) -> str:
    """Add <w:bidi/> to every sectPr (schema: ... cols, titlePg, bidi, rtlGutter, docGrid)."""

    def fix_sectpr(m):
        block = m.group(0)
        if '<w:bidi/>' in block or '<w:bidi ' in block:
            return block
        for anchor in ('<w:rtlGutter', '<w:docGrid', '</w:sectPr>'):
            idx = block.find(anchor)
            if idx != -1:
                return block[:idx] + '<w:bidi/>' + block[idx:]
        return block

    return re.sub(r'<w:sectPr(?:\s[^>]*)?>.*?</w:sectPr>', fix_sectpr, xml, flags=re.S)


def fix_numbering(xml: str) -> str:
    """RTL list indents live on the logical-start side: w:left. lvlJc -> left."""

    def fix_ind(m):
        tag = m.group(0)
        # only rename w:right when the tag has no w:left - renaming both would
        # produce a duplicate w:left attribute (invalid XML)
        if 'w:left=' in tag:
            return tag
        return tag.replace('w:right=', 'w:left=', 1)

    xml = re.sub(r'<w:ind\s[^>]*/?>', fix_ind, xml)
    xml = xml.replace('<w:lvlJc w:val="right"/>', '<w:lvlJc w:val="left"/>')
    return xml


def fix_styles(xml: str, bidi_lang: str) -> str:
    xml = strip_jc_right(xml)

    # normalize self-closing docDefault tags so the regexes below see them
    # (otherwise <w:pPrDefault/> both evades the fixer AND triggers the
    # "missing pPrDefault" fallback - emitting a duplicate pPrDefault)
    xml = xml.replace('<w:rPrDefault/>', '<w:rPrDefault><w:rPr></w:rPr></w:rPrDefault>')
    xml = xml.replace('<w:pPrDefault/>', '<w:pPrDefault></w:pPrDefault>')

    # rPrDefault: ensure <w:rtl/> and <w:lang w:bidi="..."/>
    def fix_rprdefault(m):
        block = m.group(0)
        if '<w:rPr/>' in block:
            block = block.replace('<w:rPr/>', '<w:rPr></w:rPr>', 1)
        if '<w:rPr>' not in block:
            block = block.replace('<w:rPrDefault>', '<w:rPrDefault><w:rPr></w:rPr>', 1)
        if '<w:rtl/>' not in block and '<w:rtl ' not in block:
            start = block.find('<w:rPr>')
            end = block.find('</w:rPr>', start) + len('</w:rPr>')
            block = block[:start] + _insert_rtl_in_rpr(block[start:end]) + block[end:]
        if 'w:bidi="' not in block:
            lang_m = re.search(r'<w:lang(\s[^>]*?)?(/?)>', block)
            if lang_m:
                # merge the bidi attribute into the existing <w:lang> -
                # lang is maxOccurs=1; appending a second one is invalid OOXML
                attrs = lang_m.group(1) or ''
                block = block.replace(
                    lang_m.group(0),
                    f'<w:lang{attrs} w:bidi="{bidi_lang}"{lang_m.group(2)}>', 1)
            else:
                block = block.replace('</w:rPr>', f'<w:lang w:bidi="{bidi_lang}"/></w:rPr>', 1)
        return block

    xml = re.sub(r'<w:rPrDefault>.*?</w:rPrDefault>', fix_rprdefault, xml, flags=re.S)

    # pPrDefault: ensure <w:bidi/>
    def fix_pprdefault(m):
        block = m.group(0)
        if '<w:bidi/>' in block or '<w:bidi ' in block:
            return block
        if '<w:pPr/>' in block:
            return block.replace('<w:pPr/>', '<w:pPr><w:bidi/></w:pPr>', 1)
        if '<w:pPr>' in block:
            return block.replace('<w:pPr>', '<w:pPr><w:bidi/>', 1)
        return block.replace('</w:pPrDefault>', '<w:pPr><w:bidi/></w:pPr></w:pPrDefault>', 1)

    xml = re.sub(r'<w:pPrDefault>.*?</w:pPrDefault>', fix_pprdefault, xml, flags=re.S)
    # if pPrDefault doesn't exist at all, add it after rPrDefault
    # (match any form - <w:pPrDefault>, self-closing, or with attributes - so we
    # never append a duplicate)
    if not re.search(r'<w:pPrDefault[\s/>]', xml):
        xml = xml.replace('</w:rPrDefault>',
                          '</w:rPrDefault><w:pPrDefault><w:pPr><w:bidi/></w:pPr></w:pPrDefault>', 1)
    return xml


# ---------------------------------------------------------------- main

_JC_RIGHT = re.compile(r'<w:jc\s+w:val="right"\s*/>')


def _fix_body(xml: str, counts: dict) -> str:
    """Run the five body fixes in order, counting each one separately.
    Each fixer adds only its own marker, so a per-marker delta is exact."""
    step = strip_jc_right(xml)
    counts['jc="right" removed'] += len(_JC_RIGHT.findall(xml)) - len(_JC_RIGHT.findall(step))
    xml = step

    step = ensure_paragraph_bidi(xml)
    counts['paragraphs given <w:bidi/>'] += step.count('<w:bidi/>') - xml.count('<w:bidi/>')
    xml = step

    step = ensure_run_rtl(xml)
    counts['runs given <w:rtl/>'] += step.count('<w:rtl/>') - xml.count('<w:rtl/>')
    xml = step

    step = ensure_table_bidivisual(xml)
    counts['tables given <w:bidiVisual/>'] += \
        step.count('<w:bidiVisual/>') - xml.count('<w:bidiVisual/>')
    xml = step

    step = ensure_sectpr_bidi(xml)
    counts['sectPr given <w:bidi/>'] += step.count('<w:bidi/>') - xml.count('<w:bidi/>')
    return step


def fix_docx(src: Path, dst: Path, bidi_lang: str, dry_run: bool = False) -> None:
    body_files = re.compile(r'^word/(document|header\d*|footer\d*|footnotes|endnotes)\.xml$')
    stats = {}
    counts = {
        'jc="right" removed': 0,
        'paragraphs given <w:bidi/>': 0,
        'runs given <w:rtl/>': 0,
        'tables given <w:bidiVisual/>': 0,
        'sectPr given <w:bidi/>': 0,
        'styles.xml rewritten': 0,
        'numbering.xml rewritten': 0,
    }

    def transform(name: str, data: bytes) -> bytes:
        if body_files.match(name):
            before = data.decode('utf-8')
            xml = _fix_body(before, counts)
        elif name == 'word/styles.xml':
            before = data.decode('utf-8')
            xml = fix_styles(before, bidi_lang)
            counts['styles.xml rewritten'] += 1 if xml != before else 0
        elif name == 'word/numbering.xml':
            before = data.decode('utf-8')
            xml = fix_numbering(before)
            counts['numbering.xml rewritten'] += 1 if xml != before else 0
        else:
            return data
        if xml != before:
            stats[name] = 'fixed'
        return xml.encode('utf-8')

    if dry_run:
        # read, measure, write NOTHING - not the source, not a copy
        with zipfile.ZipFile(src, 'r') as zin:
            for item in zin.infolist():
                transform(item.filename, zin.read(item.filename))
    else:
        with tempfile.TemporaryDirectory() as td:
            tmp_out = Path(td) / 'out.docx'
            with zipfile.ZipFile(src, 'r') as zin, \
                 zipfile.ZipFile(tmp_out, 'w', zipfile.ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    zout.writestr(item, transform(item.filename, zin.read(item.filename)))
            shutil.move(str(tmp_out), str(dst))

    if dry_run:
        total = sum(counts.values())
        print(f"DRY RUN - nothing was written. {src} would get {total} change(s):")
    else:
        print(f"RTL fixes applied -> {dst}")
    for label, n in counts.items():
        if n:
            print(f"  {label}: {n}")
    for f, s in stats.items():
        print(f"  {f}: {s}")


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Make a .docx fully RTL-correct for Word.')
    ap.add_argument('docx', help='input .docx')
    ap.add_argument('-o', '--output', help='output path (default: fix in place)')
    ap.add_argument('--lang', default='he-IL', help='bidi language tag (default: he-IL)')
    ap.add_argument('--dry-run', action='store_true',
                    help='report what would change, per fix type, and write nothing')
    args = ap.parse_args()

    src = Path(args.docx)
    if not src.exists():
        sys.exit(f"not found: {src}")
    dst = Path(args.output) if args.output else src
    fix_docx(src, dst, args.lang, dry_run=args.dry_run)
