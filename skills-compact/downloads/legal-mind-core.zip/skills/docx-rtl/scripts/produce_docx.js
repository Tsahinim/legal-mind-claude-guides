#!/usr/bin/env node
// produce_docx.js - one-call MD -> Word RTL production wrapper (part of the docx-rtl skill).
// Runs internally: md_to_docx.js -> fix_rtl.py -> qc_docx.py, and prints one
// consolidated report so a single Bash call replaces 3-5.
//
// Usage:   node scripts/produce_docx.js input.md output.docx
// Exit:    0 all passed | 1 md_to_docx failed | 2 no Python / fix_rtl failed | 3 QC gate failed | 64 usage
//
// Note: office/validate.py is intentionally NOT run here - per the skill's validation
// policy it is required only after hand-editing raw XML, never after a docx-js build.
const path = require('path');
const fs = require('fs');
const { spawnSync } = require('child_process');

const args = process.argv.slice(2).filter(a => a !== '--');
if (args.includes('--help') || args.includes('-h')) {
  console.log('Usage: node produce_docx.js input.md output.docx');
  console.log('Runs md_to_docx.js, then fix_rtl.py, then the qc_docx.py delivery gate, in one call.');
  console.log('Exit codes: 0 ok | 1 convert failed | 2 no Python or fix_rtl failed | 3 QC gate failed | 64 usage');
  process.exit(0);
}
if (args.length < 2) {
  console.error('usage: node produce_docx.js input.md output.docx  (see --help)');
  process.exit(64);
}
const [input, output] = args;
if (!fs.existsSync(input)) {
  console.error('input not found: ' + input);
  process.exit(64);
}

const here = __dirname;
const report = [];

// Find a Python interpreter instead of guessing one name per platform. A wrong
// guess makes spawnSync fail with ENOENT: status is null and both streams are
// empty, so the old report was a bare "[FAIL] fix_rtl" with no reason at all.
// Order matters on Windows: "python3" there is usually the Microsoft Store
// execution-alias stub, so the real interpreter is tried first.
function findPython() {
  const candidates = process.platform === 'win32'
    ? [['python', []], ['py', ['-3']], ['python3', []]]
    : [['python3', []], ['python', []], ['py', ['-3']]];
  for (const [cmd, pre] of candidates) {
    const r = spawnSync(cmd, pre.concat(['--version']), { encoding: 'utf8' });
    if (!r.error && r.status === 0) return { cmd, pre };
  }
  return null;
}

const python = findPython();
if (!python) {
  console.log('[FAIL] python - no Python 3 interpreter found (tried python, py -3, python3).');
  console.log('Python is required for fix_rtl.py and qc_docx.py. Install Python 3, or fall back to');
  console.log('tier B of the production ladder: node md_to_docx.js, then node rtl_check.js.');
  process.exit(2);
}
const pyRun = args2 => [python.cmd, python.pre.concat(args2)];

function step(name, cmd, cmdArgs, failCode) {
  const r = spawnSync(cmd, cmdArgs, { encoding: 'utf8' });
  const out = ((r.stdout || '') + (r.stderr || '')).trim();
  const ok = !r.error && r.status === 0;
  const lastLine = r.error ? ('could not run "' + cmd + '": ' + r.error.message)
    : (out ? out.split('\n').filter(Boolean).slice(-1)[0] : '');
  report.push('[' + (ok ? 'PASS' : 'FAIL') + '] ' + name + (lastLine ? ' - ' + lastLine : ''));
  if (!ok) {
    console.log(report.join('\n'));
    if (out) console.log('--- ' + name + ' output ---\n' + out);
    process.exit(failCode);
  }
}

// 1. MD -> DOCX
step('md_to_docx', process.execPath, [path.join(here, 'md_to_docx.js'), input, output], 1);
// 2. mandatory RTL fix pass
step('fix_rtl', ...pyRun([path.join(here, 'fix_rtl.py'), output]), 2);
// 3. delivery QC gate - qc_docx.py, read-only. It inherits the three direction
//    checks this step used to run inline (sectPr bidi, no jc=right, A4) and adds
//    the skill's own QC checklist: forbidden dashes, curly quotes inside Hebrew,
//    literal bullets, duplicate styleId, headings without outlineLvl, markdown
//    left as text, and split clause citations.
step('qc_docx', ...pyRun([path.join(here, 'qc_docx.py'), output, '--quiet']), 3);

report.push('[DONE] ' + output + ' (' + fs.statSync(output).size + ' bytes)');
console.log(report.join('\n'));
