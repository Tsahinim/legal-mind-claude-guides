"""Accept all tracked changes in a DOCX file using LibreOffice.

Requires LibreOffice (soffice) to be installed.
"""

import argparse
import logging
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

from office.soffice import get_soffice_env

logger = logging.getLogger(__name__)

# Platform-computed profile dir. A hardcoded "/tmp/..." lands on C:\tmp on
# Windows while "file:///tmp/..." is not a valid Windows file URI, so the macro
# and LibreOffice end up pointing at two different places and nothing runs.
LIBREOFFICE_PROFILE = Path(tempfile.gettempdir()) / "libreoffice_docx_profile"
MACRO_DIR = LIBREOFFICE_PROFILE / "user" / "basic" / "Standard"


def _profile_uri() -> str:
    """file:// URI for the profile dir - file:///C:/... on Windows, file:///tmp/... on POSIX."""
    LIBREOFFICE_PROFILE.mkdir(parents=True, exist_ok=True)
    return LIBREOFFICE_PROFILE.resolve().as_uri()

ACCEPT_CHANGES_MACRO = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE script:module PUBLIC "-//OpenOffice.org//DTD OfficeDocument 1.0//EN" "module.dtd">
<script:module xmlns:script="http://openoffice.org/2000/script" script:name="Module1" script:language="StarBasic">
    Sub AcceptAllTrackedChanges()
        Dim document As Object
        Dim dispatcher As Object

        document = ThisComponent.CurrentController.Frame
        dispatcher = createUnoService("com.sun.star.frame.DispatchHelper")

        dispatcher.executeDispatch(document, ".uno:AcceptAllTrackedChanges", "", 0, Array())
        ThisComponent.store()
        ThisComponent.close(True)
    End Sub
</script:module>"""


def accept_changes(
    input_file: str,
    output_file: str,
) -> tuple[None, str]:
    input_path = Path(input_file)
    output_path = Path(output_file)

    if not input_path.exists():
        return None, f"Error: Input file not found: {input_file}"

    if not input_path.suffix.lower() == ".docx":
        return None, f"Error: Input file is not a DOCX file: {input_file}"

    if shutil.which("soffice") is None:
        return None, (
            "Error: LibreOffice (soffice) not found on PATH - accepting tracked "
            "changes needs it. Install LibreOffice, or accept the changes in Word "
            "manually; nothing was written."
        )

    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(input_path, output_path)
    except Exception as e:
        return None, f"Error: Failed to copy input file to output location: {e}"

    if not _setup_libreoffice_macro():
        return None, "Error: Failed to setup LibreOffice macro"

    cmd = [
        "soffice",
        "--headless",
        f"-env:UserInstallation={_profile_uri()}",
        "--norestore",
        "vnd.sun.star.script:Standard.Module1.AcceptAllTrackedChanges?language=Basic&location=application",
        str(output_path.absolute()),
    ]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
            env=get_soffice_env(),
        )
    except subprocess.TimeoutExpired:
        # LibreOffice often fails to exit after store()/close(), so a timeout is
        # USUALLY still a success - but a genuine hang (load failure, modal
        # dialog before the macro ran) also lands here. Verify instead of
        # assuming. (subprocess.run already killed and reaped the child.)
        if _tracked_changes_remain(output_path):
            return None, (
                f"Error: LibreOffice timed out and tracked changes remain in "
                f"{output_file} - accept them manually or re-run"
            )
        return (
            None,
            f"Successfully accepted all tracked changes: {input_file} -> {output_file}",
        )

    if result.returncode != 0:
        return None, f"Error: LibreOffice failed: {result.stderr}"

    if _tracked_changes_remain(output_path):
        return None, (
            f"Error: LibreOffice exited cleanly but tracked changes remain in "
            f"{output_file} (macro did not run?)"
        )

    return (
        None,
        f"Successfully accepted all tracked changes: {input_file} -> {output_file}",
    )


# Every revision element a "changes accepted" claim has to account for - not
# just ins/del: moves, formatting revisions and cell/section revisions all keep
# the document in a tracked state.
_REVISION_ELEMENTS = (
    "ins", "del", "moveFrom", "moveTo",
    "pPrChange", "rPrChange", "tblPrChange", "tblPrExChange",
    "tcPrChange", "trPrChange", "sectPrChange", "cellIns", "cellDel",
    "cellMerge", "customXmlInsRangeStart", "customXmlDelRangeStart",
)
_REVISION_RE = re.compile(
    r"<w:(?:" + "|".join(_REVISION_ELEMENTS) + r")[ />]"
)
_TRACKED_PARTS_RE = re.compile(
    r"^word/(document\d*|header\d*|footer\d*|footnotes|endnotes)\.xml$"
)


def _tracked_changes_remain(docx_path: Path) -> bool:
    """True if any body part still carries tracked-change markup, or tracking is still on."""
    try:
        with zipfile.ZipFile(docx_path) as zf:
            names = zf.namelist()
            for name in names:
                if not _TRACKED_PARTS_RE.match(name):
                    continue
                xml = zf.read(name).decode("utf-8", errors="ignore")
                if _REVISION_RE.search(xml):
                    return True
            if "word/settings.xml" in names:
                settings = zf.read("word/settings.xml").decode("utf-8", errors="ignore")
                if "<w:trackChanges" in settings:
                    return True
    except Exception:
        return True  # unreadable/half-written output - treat as failure
    return False


def _setup_libreoffice_macro() -> bool:
    macro_dir = MACRO_DIR
    macro_file = macro_dir / "Module1.xba"

    if macro_file.exists() and "AcceptAllTrackedChanges" in macro_file.read_text():
        return True

    if not macro_dir.exists():
        subprocess.run(
            [
                "soffice",
                "--headless",
                f"-env:UserInstallation={_profile_uri()}",
                "--terminate_after_init",
            ],
            capture_output=True,
            timeout=10,
            check=False,
            env=get_soffice_env(),
        )
        macro_dir.mkdir(parents=True, exist_ok=True)

    try:
        macro_file.write_text(ACCEPT_CHANGES_MACRO)
        return True
    except Exception as e:
        logger.warning(f"Failed to setup LibreOffice macro: {e}")
        return False


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Accept all tracked changes in a DOCX file"
    )
    parser.add_argument("input_file", help="Input DOCX file with tracked changes")
    parser.add_argument(
        "output_file", help="Output DOCX file (clean, no tracked changes)"
    )
    args = parser.parse_args()

    _, message = accept_changes(args.input_file, args.output_file)
    print(message)

    if "Error" in message:
        raise SystemExit(1)
