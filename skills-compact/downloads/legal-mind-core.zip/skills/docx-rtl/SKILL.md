---
name: docx-rtl
description: 'יצירה, קריאה, עריכה ותיקון של מסמכי וורד (.docx) בעברית ובכל שפת RTL, עם תבניות משפטיות מוכנות: הסכם, חוזה, נספח, מספור סעיפים רב-רמות ובאותיות עבריות, טקסט מעורב-כיוון (מספרים, ת.ז., גוש/חלקה, סכומים בתוך עברית), יישור דו-צדדי, מונחים מוגדרים, הפניות פנימיות, בלוק חתימות, טבלאות תשלומים עם תאים ממוזגים ועקוב אחר שינויים בעברית. השתמש כאשר מבוקשת הפקה או עריכה של קובץ וורד עברי בלי תרגום ובלי תמצות. טריגרים - תכין מסמך וורד, הסכם או נספח בוורד, מסמך וורד בעברית, תקן כיווניות, תקן RTL, ערוך את קובץ הוורד, טבלה בעברית בוורד, Word, docx בעברית. אל תשתמש כאשר מבוקש תקציר או תמצות של מסמך - לכך executive-summary אם הותקן בסביבתך, ו-docx-rtl משמש שם רק כשכבת הפקה לוורד הסופי; כאשר מבוקש תרגום, גם תרגום לוורד - לכך legal-translation אם הותקן בסביבתך; כאשר מסמך היעד אנגלי-דומיננטי - לכך docx-ltr אם הותקן בסביבתך. השפה הדומיננטית של המסמך מכריעה - עברית ל-docx-rtl, אנגלית ל-docx-ltr; עברית עם קטעי אנגלית נשארת docx-rtl.'
---

# Hebrew / RTL DOCX creation, editing, and analysis

> **סקיל קורא (שכבת הפקה):** סקיל שקורא ל-docx-rtl כשכבת הפקה בלבד - להפיק וורד מ-MD מוכן
> (מזכר, תקציר, דוח) - קורא **אך ורק** את `references/caller-entry.md` ולא את שאר הקובץ הזה.
> הזרימה שם: `node <נתיב-docx-rtl>/scripts/produce_docx.js "<קלט>.md" "<פלט>.docx"` בקריאה אחת, בנתיב מלא ומצוטט.

## Overview

A .docx file is a ZIP archive containing XML files. This skill produces **Word-correct Hebrew
RTL documents**. Two rules carry most of the weight - internalize them before anything else:

1. **Every build MUST end with the RTL validation step.** On the full path that step is
   `python <נתיב-docx-rtl>/scripts/fix_rtl.py "<פלט>.docx"` - it enforces every RTL rule below and is
   load-bearing for the Hebrew legal patterns, not optional. **החובה אינה נעלמת בסביבה
   שאין בה הרצת פייתון - היא עוברת למדרגה המתאימה ב-`## סולם ההפקה` שלהלן. חובה בכל
   מסלול שבו האימות בר-ביצוע; לעולם לא "מומלץ".**
2. **Never use `alignment: AlignmentType.RIGHT` on a bidi paragraph** - Word renders it
   physically LEFT. Omit `alignment` (default = physical right) or use CENTER / JUSTIFIED.

## התאמה לסביבה

זהה בשקט מה זמין לך והתאם. **אל תדבר עם עוה"ד על ממשקים**, ואל תשאל אותו שאלות טכניות על הסביבה.

**הכלל המחייב: זהה לפי יכולת שנבדקה, לא לפי שם מוצר.** אין לכתוב "ב-Claude Code" או "בצ'אט" כתנאי הסתעפות. הסביבות משתנות, שמות מוצרים משתנים, וסביבה חדשה שאינה מוכרת לך אינה נופלת לאף ענף ולכן מקבלת התנהגות אקראית. בדוק את היכולת עצמה: האם הכלי קיים ברשימת הכלים שלך, והאם הפקודה שהרצת החזירה מה שציפית.

**מה לבדוק, ומתי:** בדוק יכולת רק כשאתה עומד להשתמש בה, בקריאה אחת, ואל תפתח את הריצה בסדרת בדיקות. יכולת שנבדקה נשמרת לשאר הריצה ואינה נבדקת שוב.

| היכולת | איך בודקים | אין אותה |
|---|---|---|
| הרצת קוד | הרצה בפועל של פקודת גרסה קצרה של המפרש הנדרש | מסלול בלי הרצה, לפי הכלל שבבלוק 3 |
| כתיבת קבצים | קיום כלי כתיבה ברשימת הכלים | מוסרים את התוצר בגוף התשובה, בלי להבטיח קובץ |
| כלי חיצוני (המרה, דפדפן, ממיר מסמכים) | הרצה בפועל, ובדיקת קוד היציאה | נפילה מדורגת לפי סדר שנקבע בסקיל, ולעולם לא אלתור |
| סאב-אייג'נטים | קיום כלי שיגור הסוכנים ברשימת הכלים | ריצה ברצף באותו הקשר, לפי בלוק 4 |
| שאלה מובנית | קיום AskUserQuestion ברשימת הכלים | אותן אפשרויות כרשימה ממוספרת בהודעה אחת |
| קונקטור חיצוני | קיום כלי שסופו תואם את שם הפעולה הנדרשת, **בכל תחילית** | אומרים לעוה"ד מה חסר ואילו חלקים לא ירוצו |

**שלושה איסורים:**
1. **אל תניח שכלי חיצוני מותקן.** אין רשימה מובטחת של כלים בסביבות הענן, וכלי שהיה קיים אתמול עשוי להיעדר מחר. כלי שלא נבדק - כאילו אינו קיים.
2. **אל תסתמך על התקנת חבילות בזמן ריצה.** יציאת הרשת מוגבלת ואינה זהה בין סביבות. תלות חיונית נארזת בחבילה, או שהסקיל עובד בלעדיה.
3. **אל תניח מערכת קבצים שנשמרת בין ריצות.** קובץ שכתבת עשוי להיעלם בתום השיחה. כל קובץ עזר שהסקיל צריך חי בתוך החבילה, ולא נכתב "פעם אחת".

**מה נבדק בסקיל הזה בפועל, ומה תלוי בו.** ארבע יכולות בלבד מכריעות כאן, וכל אחת נבדקת רק ברגע שבו היא נדרשת:

| מה נבדק | בדיקה אחת | מה נופל בלעדיה |
|---|---|---|
| `python3 --version` | הרצת קוד בפייתון | `fix_rtl.py`, `office/validate.py`, `comment.py`, `accept_changes.py`, `office/unpack.py` ו-`office/pack.py` - כלומר האימות המכני וכל נתיב עריכת ה-XML |
| `node --version` + `require('docx')` | הרצת נוד וחבילת docx-js | בניית מסמך חדש, `md_to_docx.js` ו-`produce_docx.js` - כלומר הפקת ה-.docx כולה |
| `pandoc --version` | קריאה וחילוץ טקסט | חילוץ טקסט מקובץ קיים ובדיקה עצמית של תוצר; קריאה נופלת ל-unpack של ה-XML |
| `soffice --version` (דרך `office/soffice.py`) | LibreOffice | המרת `.doc`←`.docx`, קבלת שינויים עקובים והמרה ל-PDF/תמונות |

חבילת `docx` אינה מובטחת בשום סביבה, ו-`npm install` אינו מסלול שנסמכים עליו. `require('docx')` שנכשל הוא תשובת "אין נוד לצורך העניין", לא הזמנה להתקין.

## סולם ההפקה - שלוש מדרגות, לפי מה שנבדק

**חובת אימות ה-RTL אינה נעלמת בשום מדרגה. מה שמשתנה הוא שפת הביצוע, לא עצם החובה.** בחר מדרגה לפי היכולת שנבדקה בטבלה שלמעלה, ואל תרד מדרגה בלי בדיקה בפועל.

**מדרגה א - יש הרצת פייתון. המסלול המלא, ברירת המחדל.** עובדים בדיוק כמתואר בהמשך הקובץ, בלי שינוי: בנייה ב-docx-js, ואחריה תמיד `python <נתיב-docx-rtl>/scripts/fix_rtl.py "<פלט>.docx"`. הפקה מ-MD מוכן: `node <נתיב-docx-rtl>/scripts/produce_docx.js "<קלט>.md" "<פלט>.docx"`, שמריץ את ההמרה, את התיקון ואת בדיקת ה-RTL בקריאה אחת.

**מדרגה ב - אין פייתון אך יש נוד.** מפיקים את הקובץ ב-docx-js (`md_to_docx.js` או בנייה ישירה), ומבצעים את **מפרט בדיקת ה-RTL** שבמקטע `## Validation policy` בשפה הזמינה. **המימוש המוכן לכך נארז בחבילה ואין לכתוב אותו מחדש: `node <נתיב-docx-rtl>/scripts/rtl_check.js "<פלט>.docx"`** - ספריית נוד תקנית בלבד, בלי התקנה, קורא בלבד ולעולם אינו משנה את הקובץ, ומריץ את שבעת סעיפי המפרט כלשונם (קוד יציאה 0 עבר, 3 נכשל). זו בדיקה מכנית לכל דבר, ולכן במדרגה ב מדווחים `בוצע ונבדק` על שבעת הסעיפים - **לא** `בוצע ולא נבדק`. שני דגשים: מה ש-`fix_rtl.py` היה מתקן אוטומטית חייב להיכתב נכון בקוד הבנייה מלכתחילה (בעיקר `<w:bidi/>` ב-`sectPr`, שדוקס-ג'יי-אס משמיט - וזה בדיוק הסעיף ש-`rtl_check.js` יפיל), ומה שנשאר לא בדוק מדווח בשמו. נתיב עריכת ה-XML הידני (unpack/pack) **אינו זמין** במדרגה הזו ואין לאלתר לו תחליף.

**מדרגה ג - אין הרצה כלל. לא מוסרים קובץ .docx.** מוסרים את התוכן המלא כ-Markdown בגוף התשובה - כל הטקסט, הכותרות, המספור והטבלאות, בלי לקצר ובלי להסתפק בתמצית - ומצרפים את שורת "מה ירד" שבמקטע המסירה, בשורה אחת ובשפת העו"ד: שקובץ הוורד לא הופק, מדוע (אין בסביבה הזו הרצת קוד), ומה המשמעות המעשית עבורו - שהתוכן מוכן להעתקה לוורד, ושסימוני ה-RTL והמספור האוטומטי לא הוחלו ויצטרכו הגדרה במסמך אצלו. אין להבטיח קובץ שיגיע בהמשך.

**כלל אנטי-אלתור - חוצה מדרגות.** כשהמסלול המאושר אינו זמין:
1. **אין להרכיב docx ידנית** כ-ZIP של קובצי XML שנכתבו בהודעה או שוחזרו מהזיכרון. שלד OOXML תקין אינו דבר שמאלתרים.
2. **אין לייצר קובץ בשם `.docx` שאינו docx תקין** - לא HTML, לא RTF, לא Markdown ששונה שמו. סיומת אינה פורמט.
3. **אין להצהיר על אימות RTL שלא בוצע.** בדיקה שלא רצה אינה "עברה", ואין לכתוב שהקובץ "תוקן RTL" כש-`fix_rtl.py` לא רץ.
4. **אין להתקין חבילות** כדי לעקוף מסלול חסום, ואין לעבור לכלי חלופי שלא נבדק בפועל.

**תוצר Markdown מוצהר עדיף תמיד על קובץ בינארי לא מאומת.** קובץ וורד שבור שנמסר לעו"ד עולה לו יותר מטקסט שהוא מדביק בעצמו.

## בטיחות קובץ העו"ד

**קובץ שהעו"ד מסר לעולם אינו מתוקן במקום. תמיד פלט לקובץ חדש.** `fix_rtl.py`, `accept_changes.py` ונתיב ה-unpack/pack כותבים מעל הקובץ שהם מקבלים, ולכן סדר הפעולות המחייב הוא: העתק תחילה את קובץ המקור לשם חדש (`<שם>-מתוקן.docx`, `<שם>-v2.docx`), והרץ אך ורק על ההעתק. המקור נשאר בידי העו"ד בדיוק כפי שמסר אותו, גם אם הריצה נכשלה באמצע. הכלל חל על כל נתיבי העריכה - תיקון RTL, עריכת XML ידנית, הוספת הערות וקבלת שינויים עקובים - ומדווחים לעו"ד את שם קובץ הפלט החדש.

## Quick Reference - task router

Task-specific details live in `references/`. **Read the matching reference BEFORE starting the task** - do not work from memory. For the two large pattern files (`hebrew-legal-patterns.md`, `docx-js-widgets.md`) read **only the `###` sections of the components you need**, per the routing rules below:

| Task | Approach |
|------|----------|
| Read/analyze content | `pandoc` or unpack for raw XML - Read `references/conversion-and-validation.md` |
| Convert `.doc`→`.docx`, DOCX→images, accept tracked changes | Read `references/conversion-and-validation.md` |
| Create new document | `docx-js` - minimal skeleton below; anything beyond it: Read `references/docx-js-widgets.md` |
| **Fix/verify RTL (after every build - on every runnable path)** | `python <נתיב-docx-rtl>/scripts/fix_rtl.py "<פלט>.docx"` - see the RTL section below; אין פייתון: `node <נתיב-docx-rtl>/scripts/rtl_check.js "<פלט>.docx"` ו-`## סולם ההפקה` |
| **שער QA לפני מסירה** | `python <נתיב-docx-rtl>/scripts/qc_docx.py "<פלט>.docx"` - קורא בלבד; אוכף את צ'קליסט ה-QC של `references/hebrew-legal-patterns.md` (`produce_docx.js` מריץ אותו אוטומטית) |
| Page size (Hebrew/Israeli docs) | **A4** (11906 × 16838 DXA) - set explicitly (skeleton below) |
| RTL alignment | **Never `AlignmentType.RIGHT`** on bidi paragraphs; omit or JUSTIFY - see RTL section |
| Hebrew legal doc (agreement, numbering, tables, signatures) | Read `references/hebrew-legal-patterns.md` - quick index below |
| המרת MD משפטי ל-Word RTL | `node <נתיב-docx-rtl>/scripts/produce_docx.js "<קלט>.md" "<פלט>.docx"` - עוטף שמריץ md_to_docx + fix_rtl + בדיקת RTL בקריאה אחת (מספור אוטומטי, קישורים, טבלאות RTL, A4) - rules in `references/conversion-and-validation.md` |
| Edit existing document (unpack → edit XML → repack) | Read `references/editing-and-xml.md` |
| Tracked changes, comments, raw OOXML patterns | Read `references/editing-and-xml.md` |
| Dependencies / a required tool is missing | Read `references/conversion-and-validation.md` |

Explicit routing rules:

- **Before building an agreement or ANY Hebrew legal document** → open `references/hebrew-legal-patterns.md` and **read only the `###` sections for the components you actually need** (the quick index below maps them; each bullet = one section anchor). Two sections are always required regardless: **Hebrew punctuation** and the **RTL quality-control checklist**. Do not read the whole file for a document that uses two patterns.
- **Before using any docx-js feature beyond the skeleton below** (styles, lists, tables, images, footnotes, hyperlinks, tab stops, multi-column, TOC, headers/footers, landscape) → open `references/docx-js-widgets.md` and **read only the `###` section of the feature you need** (section names match the feature list above), plus the closing **Critical Rules for docx-js** section.
- **Before editing an existing .docx** (unpack/pack, find & replace, tracked changes, comments, XML schema order) → Read `references/editing-and-xml.md`.
- **Before any format conversion** (`.doc`→`.docx`, MD→Word, DOCX→PDF/images, accepting changes) and for dependency setup → Read `references/conversion-and-validation.md`.

## Validation policy

**כל בדיקה מכנית נכתבת בשלוש שכבות, בסדר הזה:**
1. **הסקריפט** - המימוש המהיר.
2. **מפרט הבדיקה** - כמה שורות טקסט ברמת דיוק שמאפשרת לבצע אותה מחדש בכל שפה: מה מנרמלים, מה הטווח הקביל, מה נחשב כשל.
3. **דגימה ידנית** - היקף נקוב לביצוע בעין כשאין הרצה כלל.

**הסקריפט הוא המימוש המהיר של הבדיקה, לא המימוש המחייב היחיד.** בסביבה שאין בה את שפת ההרצה שלו, מבצעים את אותו מפרט בשפה הזמינה; אין הרצה כלל - מבצעים את הדגימה הידנית ומדווחים על כך לפי בלוק 2. סקריפט שנכתב לחבילה משתמש בספרייה התקנית בלבד ואינו מתקין דבר.

### שלוש השכבות של בדיקת ה-RTL בסקיל הזה

**שכבה 1 - הסקריפט, בשני מימושים שוֹוֵי-מפרט:**
- **פייתון (מתקן ומאמת):** `python <נתיב-docx-rtl>/scripts/fix_rtl.py "<פלט>.docx"`, ובהפקה מ-MD מוכן `node <נתיב-docx-rtl>/scripts/produce_docx.js "<קלט>.md" "<פלט>.docx"` שכולל אותו.
- **נוד (קורא בלבד, לא מתקן):** `node <נתיב-docx-rtl>/scripts/rtl_check.js "<פלט>.docx"` - מריץ את שבעת הסעיפים שלמטה כלשונם ומחזיר 0 או 3. זהו המימוש של מדרגה ב.

שני המימושים משתמשים בספרייה התקנית בלבד ואינם מתקינים דבר. **אף אחד מהם אינו "המימוש המחייב היחיד"** - הקובע הוא המפרט; מימוש שאינו זמין בסביבה מוחלף במימוש השני או מבוצע מחדש בשפה הזמינה.

**שכבה 2 - מפרט הבדיקה.** ניתן לביצוע בכל שפה שיודעת לפתוח ZIP ולקרוא טקסט. קובץ ה-.docx הוא ZIP; הקבצים הנבדקים הם `word/document.xml`, `word/styles.xml`, `word/numbering.xml`, וכל `word/header*.xml` ו-`word/footer*.xml`. שבעה סעיפים, כל אחד בינארי - עבר או נכשל:

1. כל `<w:sectPr>` מכיל `<w:bidi/>`. חסר ולו באחד = כשל.
2. אין ולו מופע אחד של `w:jc w:val="right"` באף אחד מהקבצים הנבדקים. מופע אחד = כשל. זהו באג היישור הלוגי, והוא הכשל היקר ביותר.
3. כל `<w:p>` שיש בו טקסט עברי מכיל `<w:bidi/>` בתוך `<w:pPr>`. הטווח הקביל הוא 100%.
4. כל `<w:r>` שיש בו תו בטווח U+0590-U+05FF מכיל `<w:rtl/>`. ראן של מספרים או לטינית מכיל `<w:rtl w:val="false"/>` או שאין בו rtl כלל - שניהם קבילים. ראן עברי בלי `<w:rtl/>` = כשל. **חריג יחיד ומתועד:** ציטוט סעיף (`12(א)`, `3(2)`) הוא ראן LTR אחד שאות תת-הסעיף רוכבת בתוכו, ולכן `<w:rtl w:val="false"/>` בו הוא הנוסח הנכון - ראו `references/hebrew-legal-patterns.md`, Mixed-direction content. אין חריגים נוספים.
5. כל `<w:tbl>` מכיל `<w:bidiVisual/>` בתוך `<w:tblPr>`. חסר = כשל.
6. ב-`numbering.xml` אין `w:ind w:right=` ואין `lvlJc w:val="right"`. מופע = כשל.
7. `<w:pgSz>` הוא `w:w="11906" w:h="16838"` (A4). ערך אחר = כשל.

נרמול לפני ההשוואה: התעלם מרווחים בין תגיות ובתוכן, ומסדר התכונות בתוך תגית; השווה שמות תגיות ותכונות בלבד, בלי תלות בקיצור מרחב-השם (`w:` הוא הרווח). טקסט עברי מזוהה לפי טווח התווים, לא לפי מילון.

**שכבה 3 - דגימה ידנית**, כשאין הרצה כלל ולכן גם אין קובץ לבדוק. הדגימה חלה על ה-MD שנמסר, ומקיפה שלוש בדיקות טקסט בלבד: (א) אין קו אופקי שאינו `-` (U+002D) בשום מקום, כולל ציטוטי מקור; (ב) ציטוט חוק-שנה נשאר רצף עברי אחד (`התשכ"ט-1969`) ואין שורה שנפתחת במקף בהקשר כזה; (ג) כל מספר, ת.ז., גוש/חלקה וסכום מופיע בצורה שנקראת נכון בתוך המשפט העברי. שאר שבעת סעיפי המפרט אינם ניתנים לדגימה בעין בלי קובץ, והם מדווחים בשמם כ-`לא בוצע`.

> **נתיבי הרצה - כלל מחייב.** כל הפקודות בקובץ הזה נכתבות עם `<נתיב-docx-rtl>`, וזה אינו קישוט: הריצה מתבצעת מתיקיית התיק של העו"ד ולא מתיקיית הסקיל, ופקודה יחסית (`node scripts/...`) תיכשל שם ב-ENOENT. **אתר פעם אחת את תיקיית הסקיל** (חפש את `produce_docx.js` תחת תיקיות הסקילים שבסביבתך), שמור את הנתיב לשאר הריצה, והרץ תמיד בנתיב מלא ומצוטט. גם נתיבי הקלט והפלט מצוטטים - שמות תיקיות עבריים מכילים רווחים.

- `python <נתיב-docx-rtl>/scripts/fix_rtl.py "<פלט>.docx"` - **חובה אחרי כל בנייה או עריכה, בכל מסלול שבו הוא בר-ביצוע** (מדרגה א שבסולם ההפקה). It is fast and idempotent; always run it. אין פייתון - מריצים `node <נתיב-docx-rtl>/scripts/rtl_check.js "<פלט>.docx"` (מדרגה ב); אין הרצה כלל - מדרגה ג, ולא מוסרים קובץ.
- `node <נתיב-docx-rtl>/scripts/rtl_check.js "<פלט>.docx"` - מימוש שבעת סעיפי המפרט בנוד, קורא בלבד. ניתן להריץ גם במדרגה א כבדיקה חוזרת אחרי `fix_rtl.py`; הוא לעולם אינו מחליף אותו, כי הוא אינו מתקן דבר.
- `python <נתיב-docx-rtl>/scripts/qc_docx.py "<פלט>.docx"` - **שער המסירה, קורא בלבד ולעולם אינו משנה את הקובץ.** מריץ את שלוש בדיקות הכיוון (bidi ב-sectPr, אין jc/lvlJc right, A4) ומעליהן את צ'קליסט האיכות של הסקיל עצמו, שעד כה היה ידני: מקף ארוך (en/em-dash) ומקף עברי בכל טקסט, מרכאות מסולסלות לטיניות בתוך ראן עברי, תווי תבליט ליטרליים, `w:styleId` כפול ב-styles.xml, סגנון כותרת בלי `outlineLvl` או בלי `bidi`, מרקדאון שנשאר טקסט (`#`, `---`, `1.1`), וציטוט סעיף שנקרע לשני ראנים. `produce_docx.js` מריץ אותו אוטומטית כשלב 3. קוד יציאה 0 עבר, 3 נכשל. אין פייתון - מריצים `rtl_check.js` (מדרגה ב) ומדווחים ששער ה-QA לא רץ.
- `python <נתיב-docx-rtl>/scripts/office/validate.py "<פלט>.docx"` - run **ONLY when raw XML was hand-edited** (the unpack → edit XML → pack path). Do **NOT** run it after a plain docx-js or `md_to_docx.js` build: docx-js emits schema-valid XML, and `pack.py` already validates with auto-repair when repacking.
**מה עושים בכשל - חובה.** קוד יציאה שאינו `0` פירושו שאין תוצר: **אסור למסור את ה-.docx ואסור לדווח שהופק.** קרא את שורת ה-FAIL (שער ה-QA מדפיס את מזהה הבדיקה ואת הטקסט שנפסל), **תקן את המקור ולא את הקובץ** - כשל QA הוא כמעט תמיד פגם ב-MD או בקוד הבנייה - והרץ שוב. **תקרה: שתי איטרציות תיקון.** נכשל גם אז - עצור, מסור את התוכן כ-Markdown ועמו שורה אחת: `נכשל ולא תוקן: [שם הבדיקה ומה נמצא]`. אין לעקוף בדיקה, אין להשתיק אותה ואין להרכיב docx בדרך אחרת. כשל שמקורו בהיעדר פייתון אינו כשל תוכן אלא חוסר יכולת - יורדים למדרגה ב ומדווחים ש-`fix_rtl.py` ושער ה-QA לא רצו.

- Do **NOT** use a LibreOffice/soffice PDF render as an RTL QC step - it is not ground truth for RTL (fonts substitute silently, `jc="right"` renders physically); verify via the XML/grep QC checklist in `references/hebrew-legal-patterns.md` instead.

## Minimal docx-js skeleton (new Hebrew document)

תלות: חבילת `docx`. **`npm install -g docx` הוא הוראת הכנה לסביבה שהמשתמש שולט בה, ולא שלב בזרימת ההפקה** - `require('docx')` שנכשל הוא תשובת "אין נוד לצורך העניין" ומעביר לסולם ההפקה, לא הזמנה להתקין. For everything beyond this skeleton, Read `references/docx-js-widgets.md`.

```javascript
const { Document, Packer, Paragraph, TextRun, AlignmentType } = require('docx');
const fs = require('fs');

// Hebrew run (RTL) and embedded LTR run (numbers / Latin / IDs)
const heb = (t, x = {}) => new TextRun({ text: t, font: "David", size: 24, rightToLeft: true, ...x });
const ltr = (t, x = {}) => new TextRun({ text: t, font: "David", size: 24, rightToLeft: false, ...x });

const doc = new Document({
  styles: { default: { document: {
    run: { font: "David", size: 24, rightToLeft: true },
    paragraph: { bidirectional: true },  // NO alignment - bidi start = physical right
  } } },
  sections: [{
    properties: {
      bidi: true,  // docx-js silently drops this - fix_rtl.py injects it (see RTL section below)
      page: {
        size: { width: 11906, height: 16838 },  // A4 - Israeli standard
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
      },
    },
    children: [
      new Paragraph({ alignment: AlignmentType.JUSTIFIED, children: [
        heb("בהתאם לסעיף "), ltr("12(א)"), heb(" לחוק המקרקעין, התשכ״ט-1969."),
      ]}),
    ],
  }],
});
Packer.toBuffer(doc).then(buffer => fs.writeFileSync("doc.docx", buffer));
```

```bash
python <נתיב-docx-rtl>/scripts/fix_rtl.py "doc.docx"   # מדרגה א - חובה אחרי כל בנייה. אין פייתון: node <נתיב-docx-rtl>/scripts/rtl_check.js "doc.docx"
```

### RTL (Right-to-Left) Documents - Hebrew, Arabic, etc.

RTL requires configuration at **4 content levels** (document styles, paragraphs, runs, tables)
**plus section properties (`sectPr` bidi) and - for lists - the numbering levels**. Missing any
one causes partial or broken RTL rendering.

> ⚠️ **THE #1 RTL BUG - NEVER use `alignment: AlignmentType.RIGHT` on bidi paragraphs.**
> In OOXML, when a paragraph has `<w:bidi/>`, Word interprets `jc` values **logically**:
> `"right"` = logical END = **physical LEFT**. The result: the document looks perfect in
> LibreOffice (which interprets "right" physically) but renders **left-aligned in Microsoft Word**.
> The correct approach: **omit `alignment` entirely** - the default (logical start) is
> physical RIGHT in a bidi paragraph, in both Word and LibreOffice.
> `AlignmentType.CENTER` and `AlignmentType.JUSTIFIED` (`jc="both"`) are direction-neutral
> and safe. **Legal body text is normally JUSTIFIED** - use it freely.
> `AlignmentType.LEFT` shares the same trap in mirror image: Word may read it logically
> (= physical RIGHT) while LibreOffice reads it physically. For explicit physical-LEFT
> content in a bidi paragraph (e.g. amounts in table cells), use **`AlignmentType.END`**
> (`jc="end"`) - logical in every renderer, so it lands on the physical left consistently.

**Level 1 - Document styles (global defaults):**
```javascript
const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: "David", size: 24, rightToLeft: true },
        paragraph: { bidirectional: true }, // NO alignment - bidi start = physical right
      },
      // Heading1..Heading6, Title, ListParagraph and Hyperlink are BUILT-IN
      // docx-js styles - restyle them HERE, in their own slot:
      heading1: {
        run: { size: 36, bold: true, font: "David", rightToLeft: true },
        paragraph: { spacing: { before: 240, after: 120 }, bidirectional: true,
          outlineLevel: 0 } }, // NO alignment
      heading2: {
        run: { size: 30, bold: true, font: "David", rightToLeft: true },
        paragraph: { spacing: { before: 200, after: 100 }, bidirectional: true,
          outlineLevel: 1 } }, // NO alignment
    },
    paragraphStyles: [
      // ONLY for ids docx-js does not already define (e.g. "QuoteHeb").
    ]
  },
  // ...
});
```

> ⚠️ **Duplicate `w:styleId` - never re-declare a built-in id under `paragraphStyles`.**
> docx-js always writes its own `Heading1`-`Heading6`, `Title`, `ListParagraph` and
> `Hyperlink` into `styles.xml`. Declaring `{ id: "Heading1", ... }` in `paragraphStyles`
> does not replace the stock style - it appends a **second** `<w:style w:styleId="Heading1">`
> to the same file, and which of the two Word honours is undefined. The first casualty is
> `<w:outlineLvl>`: the stock style has none, so the navigation pane and the table of
> contents come out empty even though the heading still looks right on the page. Use the
> `styles.default.headingN` slot above; `paragraphStyles` is for new ids only.

**Level 2 - Every Paragraph:** `bidirectional: true` (and no `alignment: RIGHT` - omit it for right-start, or use CENTER / JUSTIFIED)
```javascript
new Paragraph({
  bidirectional: true,   // renders right-aligned in Word AND LibreOffice
  children: [/* ... */]
})
```

**Level 3 - Every TextRun:** `rightToLeft: true`
```javascript
new TextRun({ text: "טקסט בעברית", font: "David", size: 24, rightToLeft: true })
```

**Level 4 - Every Table:** `visuallyRightToLeft: true`
```javascript
new Table({
  visuallyRightToLeft: true, // Flips column order to RTL
  width: { size: 9026, type: WidthType.DXA },
  columnWidths: [3000, 3013, 3013],
  rows: [/* ... */]
})
```

**Section properties:** `bidi: true`
```javascript
sections: [{
  properties: {
    bidi: true,
    page: { /* ... */ }
  },
  children: [/* ... */]
}]
```
> ⚠️ **docx-js BUG: `bidi: true` in section properties is silently ignored** - no
> `<w:bidi/>` is emitted into `<w:sectPr>`. It must be added by post-processing the XML.
> This is handled automatically by `scripts/fix_rtl.py` (see the mandatory post-build step below).

**Numbering (lists) in RTL:**
```javascript
numbering: {
  config: [{
    reference: "heb-numbers",
    levels: [{
      level: 0, format: LevelFormat.DECIMAL, text: "%1.",
      alignment: AlignmentType.LEFT,   // lvlJc - number alignment within its slot; Word-native RTL lists use LEFT
      style: {
        // CRITICAL: indent side must be `left`, NEVER `right`.
        // In a bidi paragraph, w:left = logical START = physical RIGHT.
        // Using `right` here pushes list numbers to the physical LEFT in Word.
        paragraph: { indent: { left: 720, hanging: 360 }, bidirectional: true },
        run: { rightToLeft: true },
      }
    }]
  }]
}
```

### Post-build step - `scripts/fix_rtl.py` (חובה בכל מסלול שבו הוא בר-ביצוע)

docx-js cannot produce fully Word-correct RTL on its own. **After every docx-js build, run:**

```bash
python <נתיב-docx-rtl>/scripts/fix_rtl.py "<פלט>.docx"
```

The script rewrites the XML inside the .docx in place and fixes, idempotently:
1. Strips `<w:jc w:val="right"/>` from all bidi paragraphs (document, headers, footers, styles) - the Word logical-alignment bug.
2. Inserts `<w:bidi/>` into `<w:sectPr>` (the docx-js bug above).
3. Adds `<w:bidi/>` to any paragraph missing it, and `<w:rtl/>` to any run missing it.
4. Adds `<w:bidiVisual/>` to any table missing it.
5. Converts list indents `w:ind w:right=` → `w:left=` and `lvlJc "right"` → `"left"` in numbering.xml.
6. Adds `<w:lang w:bidi="he-IL"/>` to run defaults in styles.xml.

Run it even if the build code followed all the rules. For the Hebrew legal patterns below it is
**load-bearing** - several pattern paragraphs rely on it (or on the Level-1 document default)
for their `<w:bidi/>` - not merely a verification pass.

> **אין פייתון בסביבה?** התיקונים 1-6 שלמעלה אינם מתבצעים לבד. במדרגה ב שבסולם ההפקה הם חייבים
> להיכתב נכון בקוד הבנייה מלכתחילה - בייחוד `<w:bidi/>` ב-`sectPr`, שדוקס-ג'יי-אס משמיט בשקט -
> ואז להיבדק לפי מפרט הבדיקה שב-`## Validation policy`. אין הרצה כלל - מדרגה ג: לא מוסרים .docx.

> ⚠️ **fix_rtl.py assumes an all-Hebrew body.** It adds `<w:bidi/>` to every paragraph and
> `<w:rtl/>` to every run containing RTL script. A run marked `rightToLeft: false` (the `ltr()`
> helper) emits `<w:rtl w:val="false"/>` and is preserved - that is what keeps mixed-direction
> content safe. But a **fully-LTR paragraph** (an English translation block, an address block)
> has no opt-out: it will be forced bidi. If the document contains intentional LTR paragraphs
> or sections, fix them manually after the pass instead of skipping it.

**Common RTL fonts:** David (Hebrew), Arial (universal), Tahoma (Hebrew/Arabic), Times New Roman (universal)

## Critical docx-js checklist (full rule list: `references/docx-js-widgets.md`)

1. A4 page size set explicitly (11906 × 16838 DXA); tables use `WidthType.DXA` only, with `columnWidths` AND per-cell `width` that sum to the table width.
2. Never `\n` (use separate Paragraphs); never unicode bullet characters (use `LevelFormat.BULLET`); `PageBreak` only inside a Paragraph; `ImageRun` requires `type`.
3. RTL at all 4 levels - document styles, every Paragraph (`bidirectional: true`), every TextRun (`rightToLeft: true`), every Table (`visuallyRightToLeft: true`) - plus `<w:bidi/>` in sectPr (fix_rtl.py injects it).
4. Alignment on bidi paragraphs: omit / CENTER / JUSTIFIED / END only - NEVER `AlignmentType.RIGHT` or `LEFT`.
5. Mixed direction: split runs - Hebrew `rightToLeft: true`; every number/ID/date/amount `rightToLeft: false`; indent side is `left` (never `right`); lvlJc LEFT.
6. ALWAYS finish with `python <נתיב-docx-rtl>/scripts/fix_rtl.py "<פלט>.docx"` - the safety net for every rule above. אין פייתון - מריצים `node <נתיב-docx-rtl>/scripts/rtl_check.js "<פלט>.docx"`, שהוא אותו מפרט בדיוק; אין הרצה כלל - לא מוסרים .docx (מדרגה ג).
7. **שורת "מה ירד" נמסרת עם הקובץ**, וקובץ שהעו"ד מסר לא תוקן במקום - הפלט הוא תמיד קובץ חדש.

## Hebrew legal quick index - `references/hebrew-legal-patterns.md`

Before drafting any הסכם / חוזה / נספח / מכתב משפטי, use this index as an **anchor map**: each bullet below is a `###` section in that file - read only the sections for the components your document uses, plus (always) **Hebrew punctuation** and the **RTL quality-control checklist**. Verified, Word-checked patterns:

- **`heb()` / `ltr()` helpers** - defined in the file's introduction, before the first `###` section below (not a section of its own) - David font for Hebrew legal documents; the base of every pattern.
- **Hebrew punctuation** - gershayim `״` for acronyms (ש״ח, ת״ז, עו״ד), geresh `׳` for single-letter abbreviations (מס׳, עמ׳), straight `"` for defined terms, plain hyphen `-` as the ONLY horizontal line (no maqaf `־`, no en-dash `–`, no em-dash `—`); currency, percent, ordinals, dual-calendar dates, כתיב מלא.
- **Mixed-direction content** - clause citations `12(א)`, גוש/חלקה, ת״ז, amounts, dates in `ltr()` runs; law-year citations (התשכ״ט-1969) stay in ONE Hebrew run; never start an `ltr()` run with a hyphen.
- **Defined terms (הגדרות)** - bold term, plain definition, justified paragraph.
- **Internal cross-references** - Bookmark + InternalHyperlink ("כאמור בסעיף … לעיל").
- **Multi-level & Hebrew-letter numbering** - 1. / 1.1. / 1.1.1., Hebrew letters א. ב. ג. (`LevelFormat.HEBREW1`), and the legal mix 1. → א. → ב. → 2.
- **Agreement opening** - centered title, dated preamble, parties block (בין / לבין, מצד אחד / מצד שני, להלן definitions).
- **Signature blocks (בלוק חתימות)** - borderless 2-column table with `visuallyRightToLeft: true` (first cell = physical RIGHT); never `TabStopPosition.MAX`.
- **Legal tables** - payment schedules, vertical/horizontal merges, repeating headers (`tableHeader: true`), amounts in `ltr()` runs with `AlignmentType.END`.
- **Hebrew page furniture** - footer "עמוד X מתוך Y", Hebrew footnotes, RTL bullet lists, Hebrew TOC, appendix (נספח) skeleton, amounts in words (סכום במילים).
- **Tracked changes in Hebrew** - `<w:ins>`/`<w:del>` with `<w:rtl/>`; the find & replace split-run trap.
- **Fonts & the LibreOffice-preview trap** - trust `<w:rFonts>` in the XML, not preview glyphs.
- **RTL quality-control checklist** - run it before delivering any Hebrew .docx.

## הפעלת סוכנים

**סוכנים מופעלים אוטומטית כשמתקיים סף, בלי לשאול את עוה"ד ובלי לבקש רשות.** עוה"ד ביקש תוצר, לא ניהול משאבים. ההחלטה על פיצול היא שלך.

**ספי הפעלה - די באחד מהם:**
- **שלוש תת-משימות עצמאיות ומעלה** שאינן תלויות זו בתוצאת זו (חיפוש לפי כמה שאלות, סקירה לפי כמה עדשות, חילוץ מכמה מסמכים) - סוכן לכל אחת, בשיגור אחד ובמקביל.
- **בקרה על תוצר שכבר נכתב** - סוכן בקרה נפרד שרואה את התוצר ולא את תהליך הכתיבה. מי שכתב אינו הבודק הטוב של עצמו.
- **חומר שאינו נכנס להקשר** - מסמך או אוסף מסמכים שקריאתם המלאה תשרוף את הריצה; סוכן קורא ומחזיר את הנדרש בלבד.

**מתי לא לפצל:** משימה יחידה וקצרה · תת-משימה שדורשת את המסמך המלא בתוך הפרומפט שלה (עלות ההעברה גדולה מהתועלת) · שלב שתלוי בתוצאת קודמו, שאינו מקביל אלא רציף.

**כללי הפעלה:**
- **מסור לכל סוכן את מה שהוא צריך במפורש** - הקטע הרלוונטי ולא המסמך כולו, שמות הכלים הקיימים בפועל בסשן, וכל מזהה סשן שנפתח בזרימה הראשית. סוכן אינו רואה את ההקשר שלך.
- **הגדר לו חוזה פלט** - מה בדיוק להחזיר ובאיזה מבנה. סוכן שמחזיר טקסט חופשי מחייב פרשנות, וזו נקודת כשל.
- **אין הרצה מקבילה בסביבה שאינה תומכת בה** - אז אותן תת-משימות רצות ברצף באותו הקשר, באותו סדר ובאותו חוזה פלט. **הליבה זהה; הפיצול הוא האצה בלבד ולא שינוי מתודולוגי.**
- **שקיפות בשורה אחת, רק כשרץ סוכן:** "רצו N סוכנים: [במה עסקו]". לא רץ סוכן - אין שורה, ואין הסבר על מה שלא קרה.

**היקף מצומצם בסקיל הזה.** docx-rtl אינו מפצל תת-משימות בדרך כלל: ההפקה עצמה היא שרשרת רציפה - המרה, תיקון, בדיקה - ואף שלב בה אינו מקבילי. **הסף היחיד שרלוונטי כאן הוא סף הבקרה**, ורק על מסמך ארוך שכבר נוצר (בערך מעל 15 עמודים או מעל 40 סעיפים): סוכן בקרה נפרד שקורא את התוצר ומחזיר ממצאים לפי צ'קליסט ה-QC של `references/hebrew-legal-patterns.md`. **אין לפצל את ההפקה עצמה לסוכנים** - לא בנייה, לא `fix_rtl.py` ולא עריכת XML; שיגור סוכן לבניית חלקי מסמך במקביל מייצר קבצים שאינם מתמזגים ומזמין בדיוק את האלתור שהסקיל אוסר.

## שאלות לעוה"ד

**שאלות לעוה"ד - חשוב לשאול, אסור להכביד.** שאלה מובנית עדיפה על ניחוש, אבל סקיל ששואל יותר מדי הופך למכשול ועוה"ד נוטש אותו.

**תקציב:** עד **שני סבבי שאלות** בכל ריצה, ועד **ארבע שאלות** בסבב. חורג מכך - אל תשאל: הכרע בעצמך לפי ברירת המחדל הסבירה, ורשום את ההכרעה בשורה אחת לצד התוצר ("הנחתי X; אמור לי אם לא"). עוה"ד מתקן טוב יותר משהוא מתאר.

**שלושה כללים:**
1. **שאלה שהתשובה לה כבר בקלט או בהקשר - אינה נשאלת.** קרא לפני שאתה שואל.
2. **שאל רק מה שמשנה את התוצר.** שאלה שכל תשובותיה מובילות לאותה פעולה היא בזבוז סבב.
3. **לכל שאלה אפשרויות מוכנות** ולא שדה פתוח, ותמיד עם ברירת מחדל מסומנת שאפשר פשוט לאשר.

**עדיפות:** כשיש יותר שאלות מהתקציב, שאל את אלה שהתשובה עליהן משנה את **מבנה** התוצר; מה שמשנה רק ניסוח - הכרע לבד.

בסקיל הזה התקציב כמעט תמיד אינו מנוצל. ברירות מחדל שאין לשאול עליהן: A4, גופן David 12, גוף מסמך מיושר דו-צדדית, מספור אוטומטי אמיתי, ושם קובץ פלט חדש הנגזר משם המקור. **הפרמטרים היחידים ששווים שאלה** הם אלה שמשנים את מבנה המסמך - סוג המסמך כשאינו עולה מהבקשה, ושיטת המספור כשיש שתיים סבירות (1./1.1. מול א./ב.). כשהסקיל נקרא כשכבת הפקה בידי סקיל אחר - **אין לשאול דבר**; השאלות באחריות הסקיל הקורא.

## מסירה

**שורת "מה ירד" - חובה בכל מסירה.** אם שכבה כלשהי לא רצה מחמת יכולת חסרה, אמור זאת לעוה"ד בשורה אחת, בשפתו ובלי ז'רגון טכני: מה לא בוצע, ומה המשמעות המעשית עבורו. שכבות שנספרות: שכבת הסוכנים, שער מכני, הפקת הקובץ, בדיקת הקובץ שהופק, ואימות מול מקור חיצוני.

**שלושה מצבי דיווח בלבד, ולעולם לא שניים:** `בוצע ונבדק` · `בוצע ולא נבדק` · `לא בוצע`. **האמצעי לעולם אינו נרשם כראשון.** בדיקה שלא רצה אינה "עברה", והיא מופיעה בשמה ולא נבלעת במספר. שורת סיכום בדיקות נכתבת בצורה "בוצעו N · לא ניתנות בסביבה זו: [שמות]" ולעולם לא כ-"N/N".

**אין לדווח על מה שלא נוצר.** קובץ, מסמך או תוצר שלא הופק בפועל אינו מדווח כאילו הופק, גם לא בלשון עתיד או בהנחה שהמשתמש יפיק אותו בעצמו.

**השכבות שנספרות בסקיל הזה, בשמן:** הפקת ה-.docx · הרצת `fix_rtl.py` · שבעת סעיפי מפרט בדיקת ה-RTL · שער ה-QA `qc_docx.py` · `office/validate.py` (רק בנתיב עריכת XML ידנית) · סוכן הבקרה על מסמך ארוך. **דוגמאות למסירה תקינה:** "הקובץ הופק ותיקון ה-RTL רץ; שבע בדיקות הכיווניות עברו" (מדרגה א) · "הקובץ הופק, ותיקון ה-RTL האוטומטי לא רץ בסביבה הזו - בדקתי את הכיווניות ידנית ועברה; שווה לפתוח בוורד ולוודא שהכל יושב ימין" (מדרגה ב) · "לא הפקתי קובץ וורד - אין בסביבה הזו הרצת קוד. הטקסט המלא כאן להעתקה לוורד; המספור והכיווניות יצטרכו הגדרה במסמך אצלך" (מדרגה ג).

## המשך מומלץ (שרשרת Legal Mind)

חל **רק כשהסקיל הופעל ישירות על ידי המשתמש**. כשסקיל אחר הפעיל את docx-rtl כשכבת הפקה (מזכר, תקציר, דוח) - אל תציע דבר; הצעות ההמשך באחריות הסקיל הקורא.

אחרי מסירת קובץ שנוצר ישירות - אם רלוונטי, הצעה אחת לכל היותר, בשורה אחת, הצעה בלבד ולעולם לא הפעלה אוטומטית, ורק אם הסקיל המוצע מותקן בסביבתך:
- נוצרה טיוטת חוזה או הסכם ← סקירת רד-פלגס על הטיוטה מנקודת מבט הצד שאתה מייצג, לאיתור חשיפות לפני שליחה (contract-risk-review).

גרסה 1.1 - 6.8.2026. גל א של סבב השדרוג: חמשת הבלוקים הקנוניים של החבילה (זיהוי סביבה לפי יכולת, שורת "מה ירד", שער מכני תלת-שכבתי, ספי הפעלת סוכנים, תקציב שאלות), שהוחלו גם בראש references/caller-entry.md כדי שכל סקיל קורא יירש אותם; הכלל המוחלט של fix_rtl.py הוחלף בסולם שלוש מדרגות לפי יכולת שנבדקה; כלל אנטי-אלתור שאוסר להרכיב docx ידנית או להצהיר על אימות RTL שלא בוצע; וכלל שקובץ שהעו"ד מסר אינו מתוקן במקום.
גרסה 1.2 - 6.8.2026. גל ב של סבב השדרוג, הגל שנוגע בקוד: נוסף `scripts/rtl_check.js` - מימוש שבעת סעיפי מפרט בדיקת ה-RTL בנוד, ספרייה תקנית בלבד וקורא בלבד, כך שמדרגה ב חדלה להיות בדיקה ידנית (שבעת הסעיפים אומתו בהרצה, כל אחד מול קלט שנכשל בו); ב-`md_to_docx.js` תוקנו שישה באגי המרה - `paragraphStyles` שקונן בטעות בתוך `styles.default` ולכן נזרק, פיצול ציטוט סעיף `12(א)` וציטוט חוק-שנה לשני ראנים, `---`/`####`/`1.1`/`1)` שנכתבו כטקסט ליטרלי במקום כמספור אוטומטי אמיתי, כותרות H1/H3 שלא עברו פרסור inline, זיהוי RTL שכיסה עברית בלבד ולכן בלע ערבית לראן LTR, וכותרת תחתונה "עמוד X מתוך Y" שנעדרה; ב-`accept_changes.py` תוקן נתיב `/tmp` קשיח ששבר את קבלת השינויים ב-Windows ובדיקת "כל השינויים התקבלו" הורחבה למשפחת רכיבי הרוויזיה כולה ולכל חלקי הגוף; ב-`office/soffice.py` נחסמה בדיקת `AF_UNIX` שהפילה את הקורא ב-Windows; פקודות ההרצה נכתבו מחדש עם נתיב מלא ומצוטט; ותווי en-dash/em-dash נוקו מהערות הקוד.
גרסה 1.3 - 6.8.2026. גל ג של סבב השדרוג, גל האיכות: נוסף `scripts/qc_docx.py` - שער המסירה, קורא בלבד ובספרייה תקנית בלבד, שאוכף מכנית את צ'קליסט ה-QC שהיה ידני (מקף ארוך ומקף עברי בכל טקסט, מרכאות מסולסלות בתוך ראן עברי, תווי תבליט ליטרליים, `w:styleId` כפול, כותרת בלי `outlineLvl` או `bidi`, מרקדאון שנשאר טקסט, וציטוט סעיף שנקרע לשני ראנים) ויורש את שלוש בדיקות הכיוון שהעוטף הריץ עד כה בשורה, והוא כעת שלב 3 של `produce_docx.js`; תוקן `w:styleId` כפול ב-styles.xml - `Heading1` עד `Heading4` הוגדרו פעמיים כי `paragraphStyles` חזר על מזהים מובנים של docx-js, ולכן `outlineLvl` (חלונית הניווט ותוכן העניינים) היה תלוי בהתנהגות לא-מוגדרת; איתור מפרש הפייתון ב-`produce_docx.js` נעשה לפי בדיקה בפועל (`python`, `py -3`, `python3`) ושגיאת הרצה מודפסת בשמה במקום `[FAIL]` ריק; נוסף `--dry-run` ל-`fix_rtl.py` עם מניין תיקונים לכל סוג, ומסלול תיקון קובץ קיים נכתב מחדש עם `-o` לקובץ חדש; `office/unpack.py` מסרב לתיקיית יעד לא ריקה (`--force` כחריג מפורש) כדי שלא ייארזו שרידים ממסמך של לקוח קודם, ו-`office/pack.py` מחזיר שגיאה כש-`--original` אינו קיים במקום לדלג על הוולידציה בשקט; ובדרך נסגר קריסת `UnicodeEncodeError` שהפילה את מסלול ה-pack/validate בקונסולת Windows. בשער האימות של הגל נתפסה ותוקנה חסימת שווא ב-C3 של `qc_docx.py`: כותרת ממוספרת (`## 2. התמורה` - צורת ההסכם העברי הרווחת) נכתבת כפסקת כותרת בלי `w:numPr`, ולכן נתפסה כמרקדאון שדלף והפילה את המסירה בקוד יציאה 3; פסקאות בסגנון כותרת הוצאו מענף הפריט הממוספר בלבד, ומרקדאון שדלף בגוף המסמך (`1.`, `## `, `---`) עדיין נכשל.
גרסת חבילה: legal-mind-core 1.4.0
