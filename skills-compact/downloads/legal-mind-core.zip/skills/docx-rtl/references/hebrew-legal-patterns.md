# Hebrew Legal Document Patterns (RTL) - verified patterns for agreements, numbering, tables, signatures, punctuation, QC (part of the docx-rtl skill)

## Hebrew Legal Document Patterns (RTL)

Verified, ready-to-use patterns for the documents Hebrew-language lawyers produce most:
agreements (הסכמים), appendices (נספחים), and letters. Every code sample below was
rendered and checked against Word-target XML. The patterns assume the **Level-1 document
default** (`paragraph: { bidirectional: true }`, see the RTL section) is in place, and the
mandatory `scripts/fix_rtl.py` pass supplies any missing `<w:bidi/>`/`<w:rtl/>` - several
pattern paragraphs below omit `bidirectional: true` and depend on this. Two helpers are used
throughout (the font is deliberately **David** for Hebrew legal documents, overriding the
generic Arial default above - change it in one place here if the client requires another):

```javascript
// Hebrew run (RTL) and embedded LTR run (numbers / Latin / IDs)
const heb = (t, x = {}) => new TextRun({ text: t, font: "David", size: 24, rightToLeft: true, ...x });
const ltr = (t, x = {}) => new TextRun({ text: t, font: "David", size: 24, rightToLeft: false, ...x });
```

### Hebrew punctuation - מרכאות, גרשיים, מקף (get these right)

Hebrew has its own punctuation. Using the Latin equivalents makes the text look foreign and,
for the **directional** Latin marks, actually renders them on the wrong side in RTL. Use one
consistent set:

| Purpose | Correct mark | Codepoint | Example | NEVER use |
|---------|-------------|-----------|---------|-----------|
| Quotation / defined term | straight `"` (non-directional, RTL-safe) | U+0022 | `"הנכס"`, `"המוכר"` | Latin curly `“ ” ‘ ’` (U+201C/D, U+2018/9) - directional, flip in RTL |
| Acronym / ראשי-תיבות | gershayim `״` **before the last letter** | U+05F4 | `ש״ח`, `ת״ז`, `עו״ד`, `ד״ר`, `התשכ״ט` | straight `"` (Word/autocorrect may turn it into a directional curly quote) |
| Single-letter abbreviation | geresh `׳` **after the letter** | U+05F3 | `מס׳`, `עמ׳`, `ס׳`, `ר׳` | straight `'` (apostrophe) |
| Compound connector / מקף | plain ASCII hyphen `-` | U+002D | `תת-חלקה`, `על-פי`, `בין-לאומי`, `אי-עמידה`, `דו-צדדי`, `בלתי-חוזר` | maqaf `־` (U+05BE) - client standard: the plain hyphen is the ONLY horizontal line in the document |
| Term-definition / separator / range dash | plain ASCII hyphen `-` - spaced for separation (`"הנכס" - דירה`), closed for ranges (`ס׳ 6-7`) | U+002D | `"הנכס" - דירה בת 4 חדרים`, `פס׳ 102-103` | en-dash `–` (U+2013) and em-dash `—` (U+2014) - both FORBIDDEN anywhere in the document |

**The plain hyphen is the only horizontal line in the document - no en-dash, no em-dash, no maqaf.** Two bidi notes about it:
1. **Law-year citation** - `חוק המקרקעין, התשכ״ט-1969`: the connector between the Hebrew year
   and the Gregorian year is a plain hyphen, and the whole token stays in **one Hebrew run** -
   `heb("... התשכ״ט-1969")`. Bare digits flanked by Hebrew render correctly under bidi. Do
   **NOT** split the year out as `ltr("-1969")` - a hyphen leading a forced-LTR run detaches
   to the far left of the citation.
2. Any hyphen **inside an `ltr()` run** (phone numbers, IDs, ranges like `03-1234567`) - it is
   LTR content and a maqaf would be wrong there.

**Currency:** in legal prose prefer `ש״ח` (gershayim) after the amount. Keep the amount itself
in an `ltr()` run so digits and thousands-separators read correctly: `ltr("2,450,000"), heb(" ש״ח")`.
If a template requires the shekel sign, keep `₪` adjacent to the number - `ltr("2,450,000 ₪")` -
never separated from it across a bidi boundary (₪ is bidi-class ET and detaches easily).

**Percent:** the number precedes the sign (`15%`) and the pair is one LTR run: `ltr("15%")` -
same principle (% is also bidi-class ET; split from its digits it can render as `%15`).

**Ordinals & dates:** prefer spelled-out ordinals for clause/appendix references (`הראשון`,
`השני`, `השלישית`) - correct legal register, no bidi risk. Israeli dates are day-first and ride
in their own `ltr()` run (`ltr("15.7.2026")`); for a dual-calendar date the Hebrew date stays in
a Hebrew run: `heb("כ״ז בתמוז התשפ״ו (")`, `ltr("15.7.2026")`, `heb(")")` - supply the
Hebrew-calendar date yourself; nothing here computes it.

**Spelling:** generated legal Hebrew is unvocalized - no nikud (vowel points) - in standard
כתיב מלא spelling.

> ⚠️ These marks are single Unicode characters - type them directly in the string, e.g.
> `heb("תת-חלקה")`, `heb("מס׳")`, `heb("ש״ח")`. Do **not** feed Hebrew text through the
> Latin "smart quotes" conversion (see *Editing Existing Documents* in `references/editing-and-xml.md`) - that step is for embedded
> **English** only.

### Mixed-direction content - numbers, English, IDs, currency inside Hebrew

The #1 source of "the numbers jumped around" bugs. A Hebrew paragraph routinely embeds
LTR content: clause citations, years, גוש/חלקה, ת״ז, amounts, dates, English names.
**Split into separate runs** - Hebrew stays `rightToLeft: true`; any run that is purely
digits/punctuation/Latin and should read left-to-right internally gets `rightToLeft: false`:

```javascript
new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { line: 360, lineRule: "auto" }, children: [
  heb("בהתאם לסעיף "), ltr("12(א)"), heb(" לחוק המקרקעין, התשכ״ט-1969"),
  heb(", בנכס הידוע כגוש "), ltr("6941"), heb(" חלקה "), ltr("25"), heb(" תת-חלקה "), ltr("3"),
  heb(", בתמורה לסך "), ltr("2,450,000"), heb(" ש״ח, לרוכש, ת״ז "), ltr("012345678"), heb("."),
]})
```

Give `rightToLeft: false` to: clause citations (`12(א)` - the one place a single Hebrew
sub-clause letter rides inside the number's LTR run; **never** put multi-word Hebrew in
`ltr()`), formatted amounts (`2,450,000`), IDs (`012345678`), dates (`31.12.2026`), and even
short bare numbers inside Hebrew (`"בת "`, `ltr("4")`, `" חדרים"`) - the `ltr()` run is the
safe choice for a number. Two things stay **inside the Hebrew run** instead: (1) a law-year
citation is one Hebrew token - `heb("לחוק המקרקעין, התשכ״ט-1969")`; splitting it as
`ltr("-1969")` detaches the hyphen to the far left; (2) more generally, never **start** an
`ltr()` run with a hyphen/dash. `spacing: { line: 360 }` gives 1.5 line spacing
(240 single / 360 = 1.5 / 480 double).

### Defined terms (הגדרות)

Bold the term, plain the definition, paragraph justified:

```javascript
new Paragraph({ alignment: AlignmentType.JUSTIFIED, children: [
  heb('"הנכס"', { bold: true }),   // straight quotes - non-directional, RTL-safe (see Hebrew punctuation above)
  heb(" - דירה בת "), ltr("4"), heb(" חדרים ברחוב הרצל "), ltr("15"), heb(", אשדוד."),
]})
```

### Internal cross-references ("כאמור בסעיף … לעיל")

Bookmark the target clause; link to it. Works in RTL:

```javascript
// target clause:
new Paragraph({ numbering: { reference: "heb-legal-mix", level: 0 },
  children: [ new Bookmark({ id: "buyerObligations", children: [heb("התחייבויות הקונה:")] }) ] })
// reference elsewhere:
new Paragraph({ alignment: AlignmentType.JUSTIFIED, children: [
  heb("כאמור ב"),
  new InternalHyperlink({ anchor: "buyerObligations",
    children: [heb("סעיף התחייבויות הקונה", { color: "0000FF", underline: {} })] }),
  heb(" לעיל, יחולו על הקונה מלוא החיובים הכספיים."),
]})
```

### Multi-level and Hebrew-letter numbering

**Multi-level hierarchical (1. / 1.1. / 1.1.1.)** - one config, multiple `levels`. `%1` = level-0
counter, `%2` = level-1, etc. Sub-levels restart under each parent automatically. Every level
needs the RTL treatment: `lvlJc` LEFT, indent side `left`, `rightToLeft: true` in the run.

```javascript
numbering: { config: [{
  reference: "legal-multilevel",
  levels: [
    { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 720, hanging: 360 }, bidirectional: true }, run: { rightToLeft: true } } },
    { level: 1, format: LevelFormat.DECIMAL, text: "%1.%2.", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 1440, hanging: 480 }, bidirectional: true }, run: { rightToLeft: true } } },
    { level: 2, format: LevelFormat.DECIMAL, text: "%1.%2.%3.", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 2160, hanging: 600 }, bidirectional: true }, run: { rightToLeft: true } } },
  ],
}] }
```

**Hebrew-letter numbering (א. ב. ג.)** - use `LevelFormat.HEBREW1` (matches Word's built-in
Hebrew list; `HEBREW2` also exists - identical for the first ~10 items, differs for higher
counts). Everything else is identical to a decimal RTL list:

```javascript
{ reference: "heb-letters",
  levels: [{ level: 0, format: LevelFormat.HEBREW1, text: "%1.", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 720, hanging: 360 }, bidirectional: true }, run: { rightToLeft: true } } }] }
```

**Legal mixed structure - numbered clause + lettered sub-clause (1. → א. → ב. → 2.)** - the
exact pattern for a מכר-קבלן agreement. DECIMAL at level 0, HEBREW1 at level 1, with
`text: "%2."` at level 1 (the letter only). Sub-letters restart under each numbered clause:

```javascript
{ reference: "heb-legal-mix",
  levels: [
    { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 720, hanging: 360 }, bidirectional: true }, run: { rightToLeft: true } } },
    { level: 1, format: LevelFormat.HEBREW1, text: "%2.", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 1440, hanging: 480 }, bidirectional: true }, run: { rightToLeft: true } } },
  ] }
```

Style note: the `א.` marker matches Word's native Hebrew list. If the drafter wants markers to
match the `12(א)` citation form, level 1 can use `text: "(%2)"` - a style choice; visually
verify parenthesized markers in Word (parentheses are bidi-neutral and can flip).

### Agreement opening - title, preamble, parties (כותרת, מבוא וצדדים)

The standard top-of-agreement skeleton - centered title, dated preamble, and the two-party
block ending `מצד אחד` / `מצד שני` with `(להלן: ...)` defined terms:

```javascript
// Title - CENTER is direction-neutral and safe
new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER,
  children: [heb("הסכם מכר", { bold: true, size: 32 })] }),
// Preamble - date digits ride in ltr() runs
new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, children: [
  heb("שנערך ונחתם בתל אביב ביום "), ltr("15"), heb(" בחודש יולי שנת "), ltr("2026"),
]}),
// Parties - each party paragraph JUSTIFIED; role tags on their own centered lines
new Paragraph({ bidirectional: true, alignment: AlignmentType.JUSTIFIED, children: [
  heb("בין: ", { bold: true }), heb("ישראל ישראלי, ת״ז "), ltr("012345678"),
  heb(", מרחוב הרצל "), ltr("15"), heb(", אשדוד (להלן: "), heb('"המוכר"', { bold: true }), heb(")"),
]}),
new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, children: [heb("מצד אחד;")] }),
new Paragraph({ bidirectional: true, alignment: AlignmentType.JUSTIFIED, children: [
  heb("לבין: ", { bold: true }), heb("פלונית אלמונית, ת״ז "), ltr("087654321"),
  heb(", מרחוב ביאליק "), ltr("7"), heb(", חולון (להלן: "), heb('"הקונה"', { bold: true }), heb(")"),
]}),
new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, children: [heb("מצד שני;")] }),
// Recitals lead-in
new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, children: [heb("הואיל:", { bold: true })] }),
```

### Signature blocks (בלוק חתימות)

The reliable pattern is a **borderless 2-column table** with `visuallyRightToLeft: true` - it
never wraps regardless of content length. Do **NOT** use `TabStopPosition.MAX`, which wraps
long signature lines onto a second line.

```javascript
const noB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: noB, bottom: noB, left: noB, right: noB, insideHorizontal: noB, insideVertical: noB };
new Table({
  visuallyRightToLeft: true, borders: noBorders,
  width: { size: 9026, type: WidthType.DXA }, columnWidths: [4513, 4513], // A4, 1" margins
  rows: [
    new TableRow({ children: [
      new TableCell({ borders: noBorders, margins: { top: 400, bottom: 0, left: 100, right: 100 },
        children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [heb("_____________________")] })] }),
      new TableCell({ borders: noBorders, margins: { top: 400, bottom: 0, left: 100, right: 100 },
        children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [heb("_____________________")] })] }),
    ]}),
    new TableRow({ children: [
      new TableCell({ borders: noBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [heb("המוכר", { bold: true })] })] }),
      new TableCell({ borders: noBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [heb("הקונה", { bold: true })] })] }),
    ]}),
  ],
})
```

With `visuallyRightToLeft: true`, the **first cell is physical RIGHT** - list the right-hand
party (e.g. המוכר) first. Table-free alternative: tab stops at **explicit CENTER positions**
(never MAX) - `tabStops: [{ type: TabStopType.CENTER, position: 2257 }, { type: TabStopType.CENTER, position: 6770 }]`
for the 9026-DXA A4 content width, each run preceded by a `\t`.

### Legal tables - payment schedules, merged cells, repeating headers

Beyond the base RTL table rule (`visuallyRightToLeft: true`), legal tables need:

- **Repeating header across pages:** `tableHeader: true` on the header `TableRow`.
- **Vertical cell merge:** `verticalMerge: VerticalMergeType.RESTART` on the top cell,
  `VerticalMergeType.CONTINUE` on each cell below (those rows still need the cell, with an
  empty `Paragraph`). Add `verticalAlign: VerticalAlign.CENTER` on the RESTART cell.
- **Horizontal merge:** `columnSpan: N` on the cell (omit the merged-away cells in that row).
- **Numbers/currency in a cell:** put the amount in an `ltr()` run and set the paragraph
  `alignment: AlignmentType.END` (= physical LEFT in a bidi paragraph, consistent in Word and
  LibreOffice; avoid `LEFT`, which Word may read logically as physical right); Hebrew
  descriptions stay default (physical right).

```javascript
new Table({
  visuallyRightToLeft: true,
  width: { size: 9026, type: WidthType.DXA }, columnWidths: [1400, 4226, 3400], // A4, 1" margins
  rows: [
    new TableRow({ tableHeader: true, children: [
      /* מס׳ | מועד התשלום | סכום (ש״ח) - bold, AlignmentType.CENTER, shaded fill "D5E8F0" */
    ]}),
    new TableRow({ children: [
      new TableCell({ /*...*/ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [ltr("1")] })] }),
      new TableCell({ /*...*/ children: [new Paragraph({ children: [heb("במועד חתימת ההסכם")] })] }),
      new TableCell({ /*...*/ children: [new Paragraph({ alignment: AlignmentType.END, children: [ltr("245,000")] })] }),
    ]}),
    new TableRow({ children: [   // vertical merge starts here (spans 2 rows)
      new TableCell({ verticalMerge: VerticalMergeType.RESTART, verticalAlign: VerticalAlign.CENTER, /*...*/
        children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [ltr("3")] })] }),
      new TableCell({ /*...*/ children: [new Paragraph({ children: [heb("במועד המסירה")] })] }),
      new TableCell({ /*...*/ children: [new Paragraph({ alignment: AlignmentType.END, children: [ltr("1,000,000")] })] }),
    ]}),
    new TableRow({ children: [
      new TableCell({ verticalMerge: VerticalMergeType.CONTINUE, /*...*/ children: [new Paragraph({ children: [heb("")] })] }),
      new TableCell({ /*...*/ children: [new Paragraph({ children: [heb("(תשלום מותנה)")] })] }),
      new TableCell({ /*...*/ children: [new Paragraph({ children: [heb("-")] })] }),
    ]}),
  ],
})
```

### Hebrew page furniture - footer page numbers, footnotes, bullets, TOC, appendices

**Footer with Hebrew page numbering ("עמוד X מתוך Y"):** the page-number fields are digits -
keep them in `rightToLeft: false` runs (fix_rtl.py preserves them via `<w:rtl w:val="false"/>`):

```javascript
footers: { default: new Footer({ children: [
  new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER, children: [
    heb("עמוד "),
    new TextRun({ children: [PageNumber.CURRENT], font: "David", size: 20, rightToLeft: false }),
    heb(" מתוך "),
    new TextRun({ children: [PageNumber.TOTAL_PAGES], font: "David", size: 20, rightToLeft: false }),
  ]}),
]}) }
```

**Hebrew footnotes** (legal citations belong here) - same heb()/ltr() split as body text:

```javascript
footnotes: {
  1: { children: [new Paragraph({ bidirectional: true, children: [
    heb("ראו ע״א "), ltr("6821/93"), heb(" בנק המזרחי נ׳ מגדל, פ״ד מט("), ltr("4"), heb(") "), ltr("221"), heb("."),
  ]})] },
},
// in the body: new FootnoteReferenceRun(1) - the reference numeral reads LTR on its own
```

**RTL bullet list** - mirror of the RTL numbered list (indent side `left`, `lvlJc` LEFT):

```javascript
{ reference: "heb-bullets",
  levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 720, hanging: 360 }, bidirectional: true }, run: { rightToLeft: true } } }] }
```

**Table of contents in Hebrew:** `new TableOfContents("תוכן עניינים", { hyperlink: true, headingStyleRange: "1-3" })`
- a block-level element, added directly to the section's `children` (never inside a Paragraph).
Entries inherit RTL from the heading styles (which must carry `bidirectional: true`). The field
renders **empty until Word updates fields** on open; the dot-leader/page-number side of the
built-in TOC styles is not adjusted by fix_rtl.py - verify in Word after updating the field.

**Appendix (נספח) skeleton** - page break + centered heading + cross-reference:

```javascript
new Paragraph({ children: [new PageBreak()] }),
new Paragraph({ bidirectional: true, alignment: AlignmentType.CENTER,
  children: [ new Bookmark({ id: "appendixA",
    children: [heb("נספח א׳ - לוח תשלומים", { bold: true, size: 28 })] }) ] }),
// referencing it from the body:
new InternalHyperlink({ anchor: "appendixA",
  children: [heb("כמפורט בנספח א׳ להסכם", { color: "0000FF", underline: {} })] })
```

**Amounts in words (סכום במילים):** figures in `ltr()`, the words are ordinary Hebrew -
`heb("בסך של "), ltr("2,450,000"), heb(" ש״ח (במילים: שני מיליון ארבע מאות וחמישים אלף שקלים חדשים)")`.

### Tracked changes in Hebrew (editing existing agreements)

When inserting `<w:ins>`/`<w:del>` runs with Hebrew text, give each run's `<w:rPr>` a
`<w:rtl/>` and copy the original run's `<w:rFonts>`. If you forget, the mandatory `fix_rtl.py`
pass injects `<w:rtl/>` into every ins/del run - it is the safety net, but include it for clarity:

```xml
<w:del w:id="201" w:author="Claude" w:date="2026-07-06T00:00:00Z">
  <w:r><w:rPr><w:rFonts w:ascii="David" w:cs="David"/><w:rtl/></w:rPr>
    <w:delText xml:space="preserve">מועד המסירה יהיה כמפורט בהסכם.</w:delText></w:r>
</w:del>
<w:ins w:id="202" w:author="Claude" w:date="2026-07-06T00:00:00Z">
  <w:r><w:rPr><w:rFonts w:ascii="David" w:cs="David"/><w:rtl/></w:rPr>
    <w:t xml:space="preserve">מועד המסירה יהיה בתוך תשעים יום.</w:t></w:r>
</w:ins>
```

Numbers inside a Hebrew tracked-change run follow the same mixed-direction rule: a pure-digit
segment can be its own run with `<w:rtl w:val="false"/>`.

### Find & replace in Hebrew documents - the split-run trap

Word and docx-js frequently split a single Hebrew word across multiple `<w:r>` runs, so a
naive search for "המוכר" in `document.xml` can miss it or match only part. Before find/replace:

1. `unpack.py` already **merges adjacent compatible runs** - rely on it (do not pass `--merge-runs false`).
2. Search the pretty-printed `<w:t>` text after merging. If a target still spans runs (because
   the runs have different formatting), edit each run, or replace the whole `<w:r>` sequence.
3. Never replace across a `<w:t>` boundary blindly - it corrupts the XML.

### Fonts & the LibreOffice-preview trap

> ⚠️ **A LibreOffice / PDF preview is NOT ground truth for an RTL document - not for fonts,
> not for alignment.** Common Hebrew fonts (David, Frank Ruehl, Narkisim) are usually **not
> installed** in the generation environment. LibreOffice silently substitutes a fallback, so
> the preview font looks different from what the attorney sees in Word (where David exists) -
> the `.docx` correctly stores `David`; trust the XML `<w:rFonts>`, not the preview glyphs.
> Likewise LibreOffice renders `jc="right"` *physically*, so broken RTL alignment can look fine
> in the preview while Word shows it left-aligned. Verify alignment/RTL via the XML rules above
> and `fix_rtl.py`; treat the preview as a rough layout check only.
> Safe font choices: **David** (classic legal), **Arial** / **Times New Roman** (universal),
> **Assistant** / **Rubik** / **Heebo** (modern - only if the recipient has them installed).

### RTL quality-control checklist - run before delivering any Hebrew .docx

> **Items 3, 4 and 9 below are enforced mechanically** by
> `python <נתיב-docx-rtl>/scripts/qc_docx.py "<פלט>.docx"` (read-only; `produce_docx.js`
> runs it as its third step). Run it and read its FAIL lines instead of grepping by hand.
> The remaining items are judgement calls and stay with you.

1. `python scripts/fix_rtl.py output.docx` was run (mandatory - the safety net for every RTL rule).
2. Only if raw XML was hand-edited (unpack → edit → pack path): `python scripts/office/validate.py output.docx` → "All validations PASSED". Not needed after a plain docx-js / md_to_docx build.
3. No stray right-alignment: unpack, then `grep -cE '<w:(jc|lvlJc) w:val="right"' word/document.xml word/styles.xml word/numbering.xml` → 0 on every file. (Target only `jc`/`lvlJc` - a plain `w:val="right"` grep false-positives on legitimate RIGHT tab stops.)
4. Every table has `<w:bidiVisual/>`; `<w:bidi/>` is present inside `<w:sectPr>`.
5. Mixed-direction runs: every number / ID / citation that should read LTR carries `rightToLeft: false`.
6. Body paragraphs justified (`jc="both"`), headings correct, numbering restarts as intended.
7. Font is a real Hebrew font in the XML (`<w:rFonts w:cs="David"/>`) - the PDF preview may substitute; check the XML, not the glyphs.
8. Signature block, defined terms, and cross-references render with the parties / letters on the correct side.
9. Hebrew punctuation: acronyms use gershayim `״` (ש״ח, ת״ז), single-letter abbreviations use geresh `׳` (מס׳), compounds and all dashes use the plain hyphen `-` (תת-חלקה) - no maqaf `־`, no en-dash `–`, no em-dash `—`; no Latin curly quotes `“ ” ‘ ’` inside Hebrew runs. **Enforced by `qc_docx.py` (checks B1/B2/B3), which is stricter and more precise than a grep: the dashes and the maqaf are forbidden in every run of the document with no exception, while a curly quote fails only in a run that contains a Hebrew character - an English-only run keeps its typographic quotes.** There is no "unless the doc has embedded English" escape hatch for the dashes.
