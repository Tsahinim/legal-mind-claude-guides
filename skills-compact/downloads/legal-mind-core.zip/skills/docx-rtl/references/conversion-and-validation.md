# Conversion, Reading & Setup - .doc conversion, text extraction, images, accepting changes, Markdown-to-Word converter, dependencies (part of the docx-rtl skill)

## Reading & Converting

### Converting .doc to .docx

Legacy `.doc` files must be converted before editing:

```bash
python scripts/office/soffice.py --headless --convert-to docx document.doc
```

### Reading Content

```bash
# Text extraction with tracked changes
pandoc --track-changes=all document.docx -o output.md

# Raw XML access
python scripts/office/unpack.py document.docx unpacked/
```

### Converting to Images

```bash
python scripts/office/soffice.py --headless --convert-to pdf document.docx
pdftoppm -jpeg -r 150 document.pdf page
```

### Accepting Tracked Changes

To produce a clean document with all tracked changes accepted (requires LibreOffice):

```bash
python scripts/accept_changes.py input.docx output.docx
```

---

### Converting Markdown to Word RTL with real automatic numbering (המרת MD ל-Word RTL עם מספור אוטומטי)

The bundled converter `scripts/md_to_docx.js` turns a Hebrew legal Markdown file (headings,
numbered points, bullet source lines, links, bold, blockquotes, tables) into a Word-correct RTL
document. **Use it for every MD→Word conversion instead of writing a one-off converter** -
one-off converters are how "numbers as plain text" bugs get shipped.

Preferred - one call that runs convert + fix_rtl + a light RTL validation and prints a
consolidated report (exit 0 = all passed):

```bash
node scripts/produce_docx.js input.md output.docx
```

Manual equivalent (only if the wrapper is unavailable):

```bash
node scripts/md_to_docx.js input.md output.docx
python scripts/fix_rtl.py output.docx        # חובה כל עוד יש פייתון; אין - ראה סולם ההפקה ב-SKILL.md
```

(`validate.py` is not needed here - the converter is a docx-js build. Run it only if you
subsequently hand-edit the raw XML via the unpack → pack path. The wrapper's validation
step is a light stdlib check - bidi in sectPr, no jc="right", A4 - not `validate.py`.)

The converter needs the `docx` package; a global install (`npm install -g docx`) is enough -
if the local `require('docx')` fails, the script falls back to the global npm root automatically.

Binding rules the converter implements (and that any MD→Word path MUST follow):

- **Real Word automatic numbering only - NEVER numbers as text.** A numbered point
  (`1. ...`) becomes a paragraph with `numbering: { reference, level }`, not a TextRun that
  starts with `"1. "`. Text numbers are fragile, don't renumber on edit, and never restart.
- **Restart per block via a separate reference.** Each logical block (under each new heading)
  gets its own dedicated `reference` (`pts0`, `pts1`, ...) so numbering restarts at 1 in every
  block. Shared reference = continuous numbering (1,2,3,4...); new reference = restart. This
  is the solution to "restart numbering between questions/blocks".
- **RTL numbering rules (binding):** `alignment: AlignmentType.LEFT` for `lvlJc`,
  `indent.left` (never `right`), `bidirectional: true` on the paragraph,
  `rightToLeft: true` on the run.
- **Sources as a real bullet list** (`LevelFormat.BULLET`) - never a hyphen/asterisk as text.
- **Mixed-direction content:** every number / date / case number / identifier that should
  read LTR gets its own run with `rightToLeft: false` (the script does this automatically by
  character-range classification).
- **Links:** `[text](url)` becomes an `ExternalHyperlink` wrapping the entire citation
  (including the bolded party names) - one anchor per source.
- **Markdown tables become a real `w:tbl`** - a header row + `|---|` separator block is parsed
  into a docx-js `Table` with `visuallyRightToLeft: true`, DXA dual widths (table 9026 =
  sum of `columnWidths` = each cell width), and a bold shaded header row. Never render table
  rows as paragraphs with pipe characters.
- **A4 page size** (11906×16838) for Israeli documents.
- **Mandatory finish:** `python scripts/fix_rtl.py output.docx` - חובה בכל מסלול שבו הוא בר-ביצוע.
  אין פייתון - מבצעים את מפרט בדיקת ה-RTL שב-`SKILL.md` (`## Validation policy`) בשפה הזמינה,
  ומדווחים `בוצע ולא נבדק` על מה שלא נבדק. אין הרצה כלל - לא מוסרים .docx.

Division of responsibility: `docx-rtl` owns the generic mechanism (`md_to_docx.js`,
`fix_rtl.py`, validation) and these rules; the calling skill (e.g. `nevo-legal-questions`)
owns *what* to convert and the content structure - it just calls `produce_docx.js` (or
`md_to_docx.js` then `fix_rtl.py`). A calling skill needs only
`references/caller-entry.md` - not this file.

---

## Dependencies & Setup

This skill is **self-contained** - every script it references ships inside its own `scripts/`
folder (`fix_rtl.py`, `office/unpack.py`, `office/pack.py`, `office/soffice.py`,
`office/validate.py`, `comment.py`, `accept_changes.py`, plus their `templates/`, `schemas/`,
and `validators/` support files). It does **not** depend on any other skill being present.

External tools required in the environment:

| Tool | Purpose | Install |
|------|---------|---------|
| **docx** (docx-js) | Create new documents | `npm install -g docx` |
| **pandoc** | Read / extract text, view tracked changes | system package (`apt install pandoc`) |
| **LibreOffice** | `.doc`→`.docx`, PDF conversion for preview | system package; auto-configured via `scripts/office/soffice.py` |
| **Poppler** | `pdftoppm` / `pdftotext` for image + text preview | system package (`apt install poppler-utils`) |
| **Python 3** | Runs all bundled `scripts/*.py` | preinstalled on most environments |

Only `docx` (via npm) and Python are strictly required to *create* Hebrew documents; the rest
are for reading, converting, and previewing.

**אין להניח שאחד מהכלים בטבלה מותקן, ואין להסתמך על התקנה בזמן ריצה.** בסביבה שהמשתמש שולט
בה, כלי חסר הוא הוראת הכנה חד-פעמית - להתקין ולהריץ שוב. בסביבת ענן, כלי שנכשל הוא עובדה
סופית: יורדים מדרגה לפי `## סולם ההפקה` שב-SKILL.md ומדווחים מה לא רץ, ולא מנסים להתקין,
לעקוף או לאלתר תחליף. LibreOffice, pandoc ו-poppler בפרט אינם מובטחים בשום סביבת ענן.
