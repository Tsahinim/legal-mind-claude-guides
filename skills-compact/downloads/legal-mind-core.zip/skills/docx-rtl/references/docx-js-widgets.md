# Creating New Documents with docx-js - full widget catalog: styles, lists, tables, images, footnotes, tab stops, columns, TOC, headers/footers (part of the docx-rtl skill)

## Creating New Documents

Generate .docx files with JavaScript, then validate. תלות: חבילת `docx`; `npm install -g docx` הוא הוראת הכנה לסביבה שהמשתמש שולט בה, לא שלב בזרימת ההפקה.

### Setup
```javascript
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun,
        Header, Footer, AlignmentType, PageOrientation, LevelFormat, ExternalHyperlink,
        InternalHyperlink, Bookmark, FootnoteReferenceRun, PositionalTab,
        PositionalTabAlignment, PositionalTabRelativeTo, PositionalTabLeader,
        TabStopType, TabStopPosition, Column, SectionType,
        TableOfContents, HeadingLevel, BorderStyle, WidthType, ShadingType,
        VerticalAlign, VerticalMergeType, PageNumber, PageBreak } = require('docx');

const fs = require('fs');

const doc = new Document({ sections: [{ children: [/* content */] }] });
Packer.toBuffer(doc).then(buffer => fs.writeFileSync("doc.docx", buffer));
```

### Validation
`validate.py` is **NOT needed after a plain docx-js build** - docx-js emits schema-valid XML.
Run it **only when raw XML was hand-edited** (the unpack → edit → pack path; `pack.py` already
validates with auto-repair on repack). `fix_rtl.py` remains mandatory after every build.
```bash
python scripts/office/validate.py doc.docx   # only after hand-editing raw XML
```

### Page Size

```javascript
// Hebrew / Israeli legal documents use A4 (which is also the docx-js default).
// Always set page size explicitly anyway for consistent results:
sections: [{
  properties: {
    page: {
      size: {
        width: 11906,   // A4: 210mm in DXA
        height: 16838   // A4: 297mm in DXA
      },
      margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } // 1 inch margins
    }
  },
  children: [/* content */]
}]
```

**Common page sizes (DXA units, 1440 DXA = 1 inch):**

| Paper | Width | Height | Content Width (1" margins) |
|-------|-------|--------|---------------------------|
| A4 (Israeli/EU standard, docx-js default) | 11,906 | 16,838 | 9,026 |
| US Letter (US documents only) | 12,240 | 15,840 | 9,360 |

**Landscape orientation:** docx-js swaps width/height internally, so pass portrait dimensions and let it handle the swap:
```javascript
size: {
  width: 11906,   // Pass SHORT edge as width (A4)
  height: 16838,  // Pass LONG edge as height
  orientation: PageOrientation.LANDSCAPE  // docx-js swaps them in the XML
},
// Content width = 15840 - left margin - right margin (uses the long edge)
```

### Styles (Override Built-in Headings)

Use Arial as the default font (universally supported). Keep titles black for readability.

```javascript
const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 24 } } }, // 12pt default
    paragraphStyles: [
      // IMPORTANT: Use exact IDs to override built-in styles
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: "Arial" },
        paragraph: { spacing: { before: 240, after: 240 }, outlineLevel: 0 } }, // outlineLevel required for TOC
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: "Arial" },
        paragraph: { spacing: { before: 180, after: 180 }, outlineLevel: 1 } },
    ]
  },
  sections: [{
    children: [
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Title")] }),
    ]
  }]
});
```

### Lists (NEVER use unicode bullets)

```javascript
// ❌ WRONG - never manually insert bullet characters
new Paragraph({ children: [new TextRun("• Item")] })  // BAD
new Paragraph({ children: [new TextRun("\u2022 Item")] })  // BAD

// ✅ CORRECT - use numbering config with LevelFormat.BULLET
const doc = new Document({
  numbering: {
    config: [
      { reference: "bullets",
        levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "numbers",
        levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ]
  },
  sections: [{
    children: [
      new Paragraph({ numbering: { reference: "bullets", level: 0 },
        children: [new TextRun("Bullet item")] }),
      new Paragraph({ numbering: { reference: "numbers", level: 0 },
        children: [new TextRun("Numbered item")] }),
    ]
  }]
});

// ⚠️ Each reference creates INDEPENDENT numbering
// Same reference = continues (1,2,3 then 4,5,6)
// Different reference = restarts (1,2,3 then 1,2,3)
```

### Tables

**CRITICAL: Tables need dual widths** - set both `columnWidths` on the table AND `width` on each cell. Without both, tables render incorrectly on some platforms.

```javascript
// CRITICAL: Always set table width for consistent rendering
// CRITICAL: Use ShadingType.CLEAR (not SOLID) to prevent black backgrounds
const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };

new Table({
  width: { size: 9026, type: WidthType.DXA }, // Always use DXA (percentages break in Google Docs)
  columnWidths: [4513, 4513], // Must sum to table width (DXA: 1440 = 1 inch)
  rows: [
    new TableRow({
      children: [
        new TableCell({
          borders,
          width: { size: 4513, type: WidthType.DXA }, // Also set on each cell
          shading: { fill: "D5E8F0", type: ShadingType.CLEAR }, // CLEAR not SOLID
          margins: { top: 80, bottom: 80, left: 120, right: 120 }, // Cell padding (internal, not added to width)
          children: [new Paragraph({ children: [new TextRun("Cell")] })]
        })
      ]
    })
  ]
})
```

**Table width calculation:**

Always use `WidthType.DXA` - `WidthType.PERCENTAGE` breaks in Google Docs.

```javascript
// Table width = sum of columnWidths = content width
// A4 with 1" margins: 11906 - 2880 = 9026 DXA (US Letter: 12240 - 2880 = 9360)
width: { size: 9026, type: WidthType.DXA },
columnWidths: [7000, 2026]  // Must sum to table width
```

**Width rules:**
- **Always use `WidthType.DXA`** - never `WidthType.PERCENTAGE` (incompatible with Google Docs)
- Table width must equal the sum of `columnWidths`
- Cell `width` must match corresponding `columnWidth`
- Cell `margins` are internal padding - they reduce content area, not add to cell width
- For full-width tables: use content width (page width minus left and right margins)

### Images

```javascript
// CRITICAL: type parameter is REQUIRED
new Paragraph({
  children: [new ImageRun({
    type: "png", // Required: png, jpg, gif, bmp. (svg additionally REQUIRES a raster fallback:
                 //   { type: "svg", data: svgBuf, fallback: { type: "png", data: pngBuf } })
    data: fs.readFileSync("image.png"),
    transformation: { width: 200, height: 150 },
    altText: { title: "Title", description: "Desc", name: "Name" } // only 'name' is required
  })]
})
```

### Page Breaks

```javascript
// CRITICAL: PageBreak must be inside a Paragraph
new Paragraph({ children: [new PageBreak()] })

// Or use pageBreakBefore
new Paragraph({ pageBreakBefore: true, children: [new TextRun("New page")] })
```

### Hyperlinks

```javascript
// External link
new Paragraph({
  children: [new ExternalHyperlink({
    children: [new TextRun({ text: "Click here", style: "Hyperlink" })],
    link: "https://example.com",
  })]
})

// Internal link (bookmark + reference)
// 1. Create bookmark at destination
new Paragraph({ heading: HeadingLevel.HEADING_1, children: [
  new Bookmark({ id: "chapter1", children: [new TextRun("Chapter 1")] }),
]})
// 2. Link to it
new Paragraph({ children: [new InternalHyperlink({
  children: [new TextRun({ text: "See Chapter 1", style: "Hyperlink" })],
  anchor: "chapter1",
})]})
```

### Footnotes

```javascript
const doc = new Document({
  footnotes: {
    1: { children: [new Paragraph("Source: Annual Report 2024")] },
    2: { children: [new Paragraph("See appendix for methodology")] },
  },
  sections: [{
    children: [new Paragraph({
      children: [
        new TextRun("Revenue grew 15%"),
        new FootnoteReferenceRun(1),
        new TextRun(" using adjusted metrics"),
        new FootnoteReferenceRun(2),
      ],
    })]
  }]
});
```

### Tab Stops

```javascript
// Right-align text on same line (e.g., date opposite a title)
new Paragraph({
  children: [
    new TextRun("Company Name"),
    new TextRun("\tJanuary 2025"),
  ],
  tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
})

// Dot leader (e.g., TOC-style)
new Paragraph({
  children: [
    new TextRun("Introduction"),
    new TextRun({ children: [
      new PositionalTab({
        alignment: PositionalTabAlignment.RIGHT,
        relativeTo: PositionalTabRelativeTo.MARGIN,
        leader: PositionalTabLeader.DOT,
      }),
      "3",
    ]}),
  ],
})
```

### Multi-Column Layouts

```javascript
// Equal-width columns
sections: [{
  properties: {
    column: {
      count: 2,          // number of columns
      space: 720,        // gap between columns in DXA (720 = 0.5 inch)
      equalWidth: true,
      separate: true,    // vertical line between columns
    },
  },
  children: [/* content flows naturally across columns */]
}]

// Custom-width columns (equalWidth must be false)
sections: [{
  properties: {
    column: {
      equalWidth: false,
      children: [
        new Column({ width: 5400, space: 720 }),
        new Column({ width: 3240 }),
      ],
    },
  },
  children: [/* content */]
}]
```

Force a column break with a new section using `type: SectionType.NEXT_COLUMN`.

### Table of Contents

```javascript
// CRITICAL: Headings must use HeadingLevel ONLY - no custom styles
new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" })
```

### Headers/Footers

```javascript
sections: [{
  properties: {
    page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } // 1440 = 1 inch
  },
  headers: {
    default: new Header({ children: [new Paragraph({ children: [new TextRun("Header")] })] })
  },
  footers: {
    default: new Footer({ children: [new Paragraph({
      children: [new TextRun("Page "), new TextRun({ children: [PageNumber.CURRENT] })]
    })] })
  },
  children: [/* content */]
}]
```

---

### Critical Rules for docx-js

- **Set page size explicitly** - Hebrew/Israeli legal documents use A4 (11906 x 16838 DXA - also the docx-js default); US Letter (12240 x 15840) only for US documents
- **Landscape: pass portrait dimensions** - docx-js swaps width/height internally; pass short edge as `width`, long edge as `height`, and set `orientation: PageOrientation.LANDSCAPE`
- **Never use `\n`** - use separate Paragraph elements
- **Never use unicode bullets** - use `LevelFormat.BULLET` with numbering config
- **PageBreak must be in Paragraph** - standalone creates invalid XML
- **ImageRun requires `type`** - always specify png/jpg/etc
- **Always set table `width` with DXA** - never use `WidthType.PERCENTAGE` (breaks in Google Docs)
- **Tables need dual widths** - `columnWidths` array AND cell `width`, both must match
- **Table width = sum of columnWidths** - for DXA, ensure they add up exactly
- **Always add cell margins** - use `margins: { top: 80, bottom: 80, left: 120, right: 120 }` for readable padding
- **Use `ShadingType.CLEAR`** - never SOLID for table shading
- **Never use tables as dividers/rules** - cells have minimum height and render as empty boxes (including in headers/footers); use `border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "2E75B6", space: 1 } }` on a Paragraph instead. For two-column footers, use tab stops (see Tab Stops section), not tables
- **TOC requires HeadingLevel only** - no custom styles on heading paragraphs
- **Override built-in styles** - use exact IDs: "Heading1", "Heading2", etc.
- **Include `outlineLevel`** - required for TOC (0 for H1, 1 for H2, etc.)
- **RTL requires ALL 4 levels** - document styles (`rightToLeft: true` + `bidirectional: true`), every Paragraph (`bidirectional: true`), every TextRun (`rightToLeft: true`), and every Table (`visuallyRightToLeft: true`). Missing any level causes broken RTL.
- **RTL alignment: NEVER `AlignmentType.RIGHT` on bidi paragraphs** - with `<w:bidi/>`, Word reads `jc="right"` as logical end = physical LEFT. Omit `alignment` (bidi default start = physical right); CENTER is safe. LibreOffice renders `jc="right"` physically, so a LibreOffice/PDF preview can look correct while Word is broken - never trust a LibreOffice preview alone for RTL alignment.
- **RTL section properties** - `bidi: true` in section `properties` is REQUIRED but docx-js silently drops it; `scripts/fix_rtl.py` injects `<w:bidi/>` into sectPr.
- **RTL indents: side is `left`, never `right`** - in bidi paragraphs `w:left` = logical start = physical right. This applies to paragraph indents AND numbering-level indents.
- **RTL numbering** - list levels need `bidirectional: true` in paragraph style AND `rightToLeft: true` in run style; `alignment` (lvlJc) should be LEFT.
- **RTL heading styles** - must include `rightToLeft: true` in run AND `bidirectional: true` in paragraph (no `alignment: RIGHT`).
- **RTL mixed-direction content** - split runs: Hebrew runs `rightToLeft: true`; any number, ID, citation, year, date, or amount that reads LTR gets its own run with `rightToLeft: false`. This is the #1 fix for numbers rendering in the wrong place.
- **RTL justified body text** - `AlignmentType.JUSTIFIED` (`jc="both"`) is direction-neutral and is the normal choice for legal paragraphs. Safe: omit / CENTER / JUSTIFIED / END (explicit physical-left). Unsafe: RIGHT and LEFT (legacy physical names Word reads logically in bidi - opposite side vs. LibreOffice).
- **RTL multi-level & Hebrew letters** - multi-level lists use `%1.%2.%3.` in `text`; Hebrew-letter lists use `LevelFormat.HEBREW1` (א. ב. ג.). Mixed legal numbering (number → letter) = DECIMAL level 0 + HEBREW1 level 1 with `text: "%2."`. All follow the same RTL list rules (lvlJc LEFT, indent `left`, `rightToLeft` run).
- **RTL signature blocks** - use a borderless table with `visuallyRightToLeft: true` (first cell = physical right); never `TabStopPosition.MAX` (it wraps long lines). Tab-stop alternative uses explicit CENTER positions.
- **RTL table merges** - vertical merge = `VerticalMergeType.RESTART` then `CONTINUE` (continue rows still need the cell); horizontal = `columnSpan`. Repeating header = `tableHeader: true`. Amounts in cells: `ltr()` run + `AlignmentType.END` (not LEFT).
- **Preview is not ground truth** - LibreOffice substitutes missing Hebrew fonts and renders `jc="right"` physically; verify fonts/alignment in the XML, not the PDF glyphs.
- **ALWAYS run `python scripts/fix_rtl.py output.docx` after building** - it is the safety net for every rule above.
