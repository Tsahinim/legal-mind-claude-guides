# Editing Existing Documents & OOXML Reference - unpack/edit/pack, tracked changes, comments, schema order, images-in-XML (part of the docx-rtl skill)

## Editing Existing Documents

**Follow all 3 steps in order.**

### Step 1: Unpack
```bash
python <נתיב-docx-rtl>/scripts/office/unpack.py "document.docx" "unpacked-<שם התיק>/"
```
Extracts XML, pretty-prints, merges adjacent runs, and converts smart quotes to XML entities (`&#x201C;` etc.) so they survive editing. Use `--merge-runs false` to skip run merging.

**A non-empty target directory is refused.** Extraction overlays the archive on whatever is already there, and `pack.py` then zips the whole directory - so a reused `unpacked/` can carry XML, images or relationships from a previous client's document into this one. Use a per-document directory name; `--force` erases the directory first and is the deliberate exception, never the habit.

### Step 2: Edit XML

Edit files in `unpacked/word/`. See XML Reference below for patterns.

**Use "Claude" as the author** for tracked changes and comments, unless the user explicitly requests use of a different name.

**Use the Edit tool directly for string replacement. Do not write Python scripts.** Scripts introduce unnecessary complexity. The Edit tool shows exactly what is being replaced.

**Quotes - Hebrew vs. English content (they are NOT the same):**

- **Hebrew text:** use the Hebrew marks from *Hebrew punctuation* in `references/hebrew-legal-patterns.md` - straight `"` for
  quotation/defined terms, gershayim `״` (U+05F4) for acronyms, geresh `׳` (U+05F3) for
  single-letter abbreviations, plain hyphen `-` for compounds and dashes. **NEVER** insert the Latin
  directional curly quotes below into Hebrew text - they are directional and render on the wrong
  side in RTL.
- **Embedded English only:** for apostrophes/quotes inside English runs, use XML entities to
  produce smart quotes (professional typography for LTR text):
```xml
<!-- LTR / English content only -->
<w:t>Here&#x2019;s a quote: &#x201C;Hello&#x201D;</w:t>
```
| Entity | Character | Use in |
|--------|-----------|--------|
| `&#x2018;` | ‘ (left single) | English only |
| `&#x2019;` | ’ (right single / apostrophe) | English only |
| `&#x201C;` | “ (left double) | English only |
| `&#x201D;` | ” (right double) | English only |

**Adding comments:** Use `comment.py`. The comment **text is the second positional argument** and is XML-escaped automatically (pass `--raw` only if the text is already escaped XML). The comment id is auto-assigned (max existing + 1) unless you pass `--id`:
```bash
python scripts/comment.py unpacked/ "Comment text with & and '"           # id auto-assigned
python scripts/comment.py unpacked/ "Reply text" --parent 0                # reply to comment 0
python scripts/comment.py unpacked/ "טקסט הערה בעברית" --author "עו״ד כהן"   # Hebrew text + custom author
python scripts/comment.py unpacked/ "Text" --id 0                          # force a specific id
```
Comment bodies are written RTL by default (`<w:bidi/>` + `<w:rtl/>` + David font - comments.xml
is NOT covered by fix_rtl.py, so this template is the only thing keeping Hebrew comments
right-aligned). For an English-only comment pass `--ltr`.
Then add markers to document.xml (see Comments in XML Reference).

### Step 3: Pack
```bash
python <נתיב-docx-rtl>/scripts/office/pack.py "unpacked-<שם התיק>/" "output.docx" --original "document.docx"
```
Validates with auto-repair, condenses XML, and creates DOCX. Use `--validate false` to skip.

**`--original` is the validation gate, and a wrong path is now an error, not a silent skip.** A path that does not exist stops the run before anything is written; omitting `--original` altogether packs the file but prints a warning that validation did not run. If you meant to pack without validation, say so with `--validate false`.

After packing, run the QA gate on the result - hand-edited XML is exactly where a stray `jc="right"` or a forbidden dash gets in:
```bash
python <נתיב-docx-rtl>/scripts/qc_docx.py "output.docx"
```

**Auto-repair will fix:**
- `durableId` >= 0x7FFFFFFF (regenerates valid ID)
- Missing `xml:space="preserve"` on `<w:t>` with whitespace

**Auto-repair won't fix:**
- Malformed XML, invalid element nesting, missing relationships, schema violations

### Common Pitfalls

- **Replace entire `<w:r>` elements**: When adding tracked changes, replace the whole `<w:r>...</w:r>` block with `<w:del>...<w:ins>...` as siblings. Don't inject tracked change tags inside a run.
- **Preserve `<w:rPr>` formatting**: Copy the original run's `<w:rPr>` block into your tracked change runs to maintain bold, font size, etc.

### Fixing RTL in Existing Documents

**Fast path** (an existing file always goes to a NEW output - never in place):

```bash
python <נתיב-docx-rtl>/scripts/fix_rtl.py "document.docx" --dry-run                 # what would change, per fix type
python <נתיב-docx-rtl>/scripts/fix_rtl.py "document.docx" -o "document-מתוקן.docx"  # the repair
python <נתיב-docx-rtl>/scripts/qc_docx.py "document-מתוקן.docx"                     # the QA gate, read-only
```

It applies all five fixes below, idempotently. **The bare in-place form (`fix_rtl.py document.docx`, no `-o`) is for the build path only** - a file this skill just generated. A file the lawyer supplied is never repaired in place: `--dry-run` first so you know the size of the change, then `-o` to a new name, and the original stays exactly as he sent it even if the run fails midway. Use the manual XML fixes below only when you need surgical control over part of a document.

When an existing DOCX has broken RTL (text aligned left, tables flipped), fix these things in the unpacked XML:

**Fix 1 - Remove `<w:jc w:val="right"/>` from bidi paragraphs** in `document.xml`, `styles.xml`, headers and footers. This is the most common cause of "RTL document renders left-aligned in Word": with `<w:bidi/>`, Word reads `jc="right"` as logical end = physical LEFT. A bidi paragraph with no `jc` is start-aligned = physical right. Keep `jc="center"` (direction-neutral).

**Fix 2 - Add `<w:rtl/>` to all runs** in `document.xml` and `styles.xml`:
```xml
<!-- Every <w:rPr> must contain <w:rtl/> -->
<w:r>
  <w:rPr>
    <w:rFonts w:ascii="David" w:cs="David"/>
    <w:rtl/>  <!-- ADD THIS -->
  </w:rPr>
  <w:t>טקסט בעברית</w:t>
</w:r>

<!-- Runs without <w:rPr> need one added -->
<w:r>
  <w:rPr><w:rtl/></w:rPr>  <!-- ADD THIS BLOCK -->
  <w:t>טקסט</w:t>
</w:r>
```

**Fix 3 - Add `<w:bidiVisual/>` to all tables** in `document.xml`:
```xml
<!-- CRITICAL: <w:bidiVisual/> must come BEFORE <w:tblW> (schema order) -->
<w:tblPr>
  <w:bidiVisual/>  <!-- ADD THIS - before tblW -->
  <w:tblW w:type="dxa" w:w="9026"/>
  <w:tblBorders>...</w:tblBorders>
</w:tblPr>
```

**Fix 4 - Verify `<w:bidi/>` in every paragraph** (pPr schema order: after pStyle/numPr, before spacing/ind/jc):
```xml
<w:pPr>
  <w:bidi/>  <!-- Add if missing -->
</w:pPr>
```

**Fix 5 - Add `<w:bidi/>` to `<w:sectPr>`** (schema order: after cols/titlePg, before rtlGutter/docGrid):
```xml
<w:sectPr>
  <w:pgSz .../>
  <w:pgMar .../>
  <w:bidi/>  <!-- ADD THIS - before docGrid -->
  <w:docGrid w:linePitch="360"/>
</w:sectPr>
```

**Fix 6 - Numbering indents** in `numbering.xml`: `w:ind w:right="X"` → `w:ind w:left="X"` and `<w:lvlJc w:val="right"/>` → `<w:lvlJc w:val="left"/>`.

---

## XML Reference

### Schema Compliance

- **Element order in `<w:pPr>`**: `<w:pStyle>`, `<w:numPr>`, `<w:bidi/>`, `<w:spacing>`, `<w:ind>`, `<w:jc>`, `<w:rPr>` last
- **Element order in `<w:tblPr>`**: `<w:tblStyle>`, `<w:tblpPr>`, `<w:tblOverlap>`, **then** `<w:bidiVisual/>`, then `<w:tblW>`, `<w:tblBorders>`, then rest - bidiVisual comes *after* tblStyle, *before* tblW
- **Element order in `<w:rPr>`**: `<w:rtl/>` has a FIXED slot - after `<w:vertAlign>`, **before** `<w:cs/>`, `<w:em>`, `<w:lang>`, `<w:eastAsianLayout>`, `<w:specVanish>`, `<w:oMath>`. Never append it after `<w:lang>` (out-of-order XML)
- **Whitespace**: Add `xml:space="preserve"` to `<w:t>` with leading/trailing spaces
- **RSIDs**: Must be 8-digit hex (e.g., `00AB1234`)

### Tracked Changes

**Insertion:**
```xml
<w:ins w:id="1" w:author="Claude" w:date="2025-01-01T00:00:00Z">
  <w:r><w:t>inserted text</w:t></w:r>
</w:ins>
```

**Deletion:**
```xml
<w:del w:id="2" w:author="Claude" w:date="2025-01-01T00:00:00Z">
  <w:r><w:delText>deleted text</w:delText></w:r>
</w:del>
```

**Inside `<w:del>`**: Use `<w:delText>` instead of `<w:t>`, and `<w:delInstrText>` instead of `<w:instrText>`.

**Minimal edits** - only mark what changes:
```xml
<!-- Change "30 days" to "60 days" -->
<w:r><w:t>The term is </w:t></w:r>
<w:del w:id="1" w:author="Claude" w:date="...">
  <w:r><w:delText>30</w:delText></w:r>
</w:del>
<w:ins w:id="2" w:author="Claude" w:date="...">
  <w:r><w:t>60</w:t></w:r>
</w:ins>
<w:r><w:t> days.</w:t></w:r>
```

**Deleting entire paragraphs/list items** - when removing ALL content from a paragraph, also mark the paragraph mark as deleted so it merges with the next paragraph. Add `<w:del/>` inside `<w:pPr><w:rPr>`:
```xml
<w:p>
  <w:pPr>
    <w:numPr>...</w:numPr>  <!-- list numbering if present -->
    <w:rPr>
      <w:del w:id="1" w:author="Claude" w:date="2025-01-01T00:00:00Z"/>
    </w:rPr>
  </w:pPr>
  <w:del w:id="2" w:author="Claude" w:date="2025-01-01T00:00:00Z">
    <w:r><w:delText>Entire paragraph content being deleted...</w:delText></w:r>
  </w:del>
</w:p>
```
Without the `<w:del/>` in `<w:pPr><w:rPr>`, accepting changes leaves an empty paragraph/list item.

**Rejecting another author's insertion** - nest deletion inside their insertion:
```xml
<w:ins w:author="Jane" w:id="5">
  <w:del w:author="Claude" w:id="10">
    <w:r><w:delText>their inserted text</w:delText></w:r>
  </w:del>
</w:ins>
```

**Restoring another author's deletion** - add insertion after (don't modify their deletion):
```xml
<w:del w:author="Jane" w:id="5">
  <w:r><w:delText>deleted text</w:delText></w:r>
</w:del>
<w:ins w:author="Claude" w:id="10">
  <w:r><w:t>deleted text</w:t></w:r>
</w:ins>
```

### Comments

After running `comment.py` (see Step 2), add markers to document.xml. For replies, use `--parent` flag and nest markers inside the parent's.

**CRITICAL: `<w:commentRangeStart>` and `<w:commentRangeEnd>` are siblings of `<w:r>`, never inside `<w:r>`.**

```xml
<!-- Comment markers are direct children of w:p, never inside w:r -->
<w:commentRangeStart w:id="0"/>
<w:del w:id="1" w:author="Claude" w:date="2025-01-01T00:00:00Z">
  <w:r><w:delText>deleted</w:delText></w:r>
</w:del>
<w:r><w:t> more text</w:t></w:r>
<w:commentRangeEnd w:id="0"/>
<w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr><w:commentReference w:id="0"/></w:r>

<!-- Comment 0 with reply 1 nested inside -->
<w:commentRangeStart w:id="0"/>
  <w:commentRangeStart w:id="1"/>
  <w:r><w:t>text</w:t></w:r>
  <w:commentRangeEnd w:id="1"/>
<w:commentRangeEnd w:id="0"/>
<w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr><w:commentReference w:id="0"/></w:r>
<w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr><w:commentReference w:id="1"/></w:r>
```

### Images

1. Add image file to `word/media/`
2. Add relationship to `word/_rels/document.xml.rels`:
```xml
<Relationship Id="rId5" Type=".../image" Target="media/image1.png"/>
```
3. Add content type to `[Content_Types].xml`:
```xml
<Default Extension="png" ContentType="image/png"/>
```
4. Reference in document.xml:
```xml
<w:drawing>
  <wp:inline>
    <wp:extent cx="914400" cy="914400"/>  <!-- EMUs: 914400 = 1 inch -->
    <a:graphic>
      <a:graphicData uri=".../picture">
        <pic:pic>
          <pic:blipFill><a:blip r:embed="rId5"/></pic:blipFill>
        </pic:pic>
      </a:graphicData>
    </a:graphic>
  </wp:inline>
</w:drawing>
```
